-- ============================================================
-- TinyCubs ERP — MySQL Database Schema
-- Usage: mysql -u root -p tinycubs_erp < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS tinycubs_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tinycubs_erp;

-- Users & Auth
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','sales','accounts','operations') DEFAULT 'sales',
    is_active TINYINT(1) DEFAULT 1,
    last_login_at TIMESTAMP NULL,
    remember_token VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE personal_access_tokens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tokenable_type VARCHAR(255) NOT NULL,
    tokenable_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    abilities TEXT,
    last_used_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_tokenable (tokenable_type, tokenable_id)
);

-- Customers
CREATE TABLE customers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(30),
    email VARCHAR(255),
    address TEXT,
    company VARCHAR(255),
    type ENUM('retail','wholesale','online') DEFAULT 'retail',
    woocommerce_id VARCHAR(50),
    total_purchases DECIMAL(12,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    INDEX idx_phone (phone),
    INDEX idx_email (email)
);

-- Product Categories
CREATE TABLE categories (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products / SKUs
CREATE TABLE products (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    sku VARCHAR(100) UNIQUE NOT NULL,
    size VARCHAR(20) NOT NULL,
    color VARCHAR(50) NOT NULL,
    color_hex VARCHAR(7),
    cost_price DECIMAL(10,2) DEFAULT 0,
    selling_price DECIMAL(10,2) DEFAULT 0,
    stock_qty INT DEFAULT 0,
    low_stock_threshold INT DEFAULT 10,
    barcode VARCHAR(255) UNIQUE,
    woocommerce_id VARCHAR(50),
    sync_to_woocommerce TINYINT(1) DEFAULT 1,
    sync_to_facebook TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    INDEX idx_sku (sku),
    INDEX idx_barcode (barcode),
    INDEX idx_stock (stock_qty),
    INDEX idx_wc (woocommerce_id)
);

-- Stock Movements (full audit trail)
CREATE TABLE stock_movements (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    type ENUM('in','out','adjustment','production','sale','return') NOT NULL,
    quantity INT NOT NULL,
    balance_after INT NOT NULL,
    reference VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_product_date (product_id, created_at)
);

-- Invoices & Quotations
CREATE TABLE invoices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    type ENUM('invoice','quotation') DEFAULT 'invoice',
    status ENUM('draft','sent','partial','paid','cancelled') DEFAULT 'draft',
    source ENUM('manual','woocommerce','facebook') DEFAULT 'manual',
    woocommerce_order_id VARCHAR(50),
    invoice_date DATE NOT NULL,
    due_date DATE,
    subtotal DECIMAL(12,2) DEFAULT 0,
    discount DECIMAL(12,2) DEFAULT 0,
    tax DECIMAL(12,2) DEFAULT 0,
    total DECIMAL(12,2) DEFAULT 0,
    amount_paid DECIMAL(12,2) DEFAULT 0,
    balance_due DECIMAL(12,2) DEFAULT 0,
    notes TEXT,
    terms TEXT,
    paid_at TIMESTAMP NULL,
    whatsapp_sent_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_status_date (status, invoice_date),
    INDEX idx_customer (customer_id),
    INDEX idx_wc_order (woocommerce_order_id)
);

-- Invoice Line Items
CREATE TABLE invoice_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id BIGINT UNSIGNED NOT NULL,
    product_id BIGINT UNSIGNED,
    description VARCHAR(500) NOT NULL,
    sku VARCHAR(100),
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- Payment Records
CREATE TABLE payments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    method ENUM('cash','bank_transfer','online','cheque') DEFAULT 'cash',
    reference VARCHAR(100),
    payment_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_invoice_date (invoice_id, payment_date)
);

-- Expenses
CREATE TABLE expenses (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    category ENUM('cost_of_goods','salaries','rent','utilities','marketing','transport','equipment','other') NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_method ENUM('cash','bank_transfer','online','cheque') DEFAULT 'cash',
    expense_date DATE NOT NULL,
    notes TEXT,
    receipt_path VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_category_date (category, expense_date)
);

-- Production Workers
CREATE TABLE workers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(30),
    specialty VARCHAR(100),
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Raw Materials
CREATE TABLE materials (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    unit VARCHAR(20) NOT NULL,
    stock_qty DECIMAL(10,2) DEFAULT 0,
    low_stock_threshold DECIMAL(10,2) DEFAULT 10,
    cost_per_unit DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Job Orders (Production)
CREATE TABLE job_orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_number VARCHAR(50) UNIQUE NOT NULL,
    invoice_id BIGINT UNSIGNED,
    worker_id BIGINT UNSIGNED,
    created_by BIGINT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status ENUM('pending','in_progress','qc_check','completed','cancelled') DEFAULT 'pending',
    quantity INT NOT NULL,
    due_date DATE,
    completed_date DATE,
    progress_pct TINYINT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
    FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_status_due (status, due_date)
);

-- Job Order Line Items
CREATE TABLE job_order_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_order_id BIGINT UNSIGNED NOT NULL,
    product_id BIGINT UNSIGNED,
    description VARCHAR(500) NOT NULL,
    quantity INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (job_order_id) REFERENCES job_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- Material Usage per Job
CREATE TABLE job_material_usage (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_order_id BIGINT UNSIGNED NOT NULL,
    material_id BIGINT UNSIGNED NOT NULL,
    quantity_used DECIMAL(10,2) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (job_order_id) REFERENCES job_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- System Settings (key-value store)
CREATE TABLE settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(255) UNIQUE NOT NULL,
    value TEXT,
    `group` VARCHAR(50) DEFAULT 'general',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_group (`group`)
);

-- ─── SEED DATA ──────────────────────────────────────────────

INSERT INTO users (name, email, phone, password, role) VALUES
('Admin User', 'admin@tinycubs.lk', '+94771000001', '$2y$12$eImiTXuWVxfM37uY4JANjOe5XtVc9B7VKbbcAGV..hashed..', 'admin'),
('Sanduni K.', 'sales@tinycubs.lk', '+94771000002', '$2y$12$eImiTXuWVxfM37uY4JANjOe5XtVc9B7VKbbcAGV..hashed..', 'sales'),
('Ruwani J.', 'accounts@tinycubs.lk', '+94771000003', '$2y$12$eImiTXuWVxfM37uY4JANjOe5XtVc9B7VKbbcAGV..hashed..', 'accounts'),
('Kasun P.', 'ops@tinycubs.lk', '+94771000004', '$2y$12$eImiTXuWVxfM37uY4JANjOe5XtVc9B7VKbbcAGV..hashed..', 'operations');

INSERT INTO categories (name, slug) VALUES
('T-Shirts', 't-shirts'),
('Baby Clothes', 'baby-clothes'),
('Kids Clothing', 'kids-clothing'),
('Rompers', 'rompers');

INSERT INTO settings (`key`, value, `group`) VALUES
('company_name', 'TinyCubs.lk', 'general'),
('company_phone', '+94771234567', 'general'),
('company_email', 'info@tinycubs.lk', 'general'),
('company_address', 'Colombo, Sri Lanka', 'general'),
('currency', 'LKR', 'general'),
('currency_symbol', 'Rs', 'general'),
('invoice_prefix', 'INV', 'invoice'),
('invoice_terms', 'Payment due within 14 days.', 'invoice'),
('low_stock_alert_email', 'admin@tinycubs.lk', 'general'),
('wc_sync_enabled', '0', 'integrations'),
('fb_sync_enabled', '0', 'integrations'),
('whatsapp_enabled', '0', 'integrations');
