<?php
// ============================================================
// TinyCubs ERP — Full Database Schema
// Run: php artisan migrate --seed
// ============================================================

// ─── 2024_01_01_000001_create_users_table.php ───────────────
Schema::create('users', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('email')->unique();
    $table->string('phone')->nullable();
    $table->string('password');
    $table->enum('role', ['admin', 'sales', 'accounts', 'operations'])->default('sales');
    $table->boolean('is_active')->default(true);
    $table->timestamp('last_login_at')->nullable();
    $table->rememberToken();
    $table->timestamps();
});

// ─── 2024_01_01_000002_create_customers_table.php ───────────
Schema::create('customers', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('phone')->nullable();
    $table->string('email')->nullable();
    $table->text('address')->nullable();
    $table->string('company')->nullable();
    $table->enum('type', ['retail', 'wholesale', 'online'])->default('retail');
    $table->string('woocommerce_id')->nullable(); // WC customer ID
    $table->decimal('total_purchases', 12, 2)->default(0);
    $table->timestamps();
    $table->softDeletes();
});

// ─── 2024_01_01_000003_create_categories_table.php ──────────
Schema::create('categories', function (Blueprint $table) {
    $table->id();
    $table->string('name'); // T-Shirts, Baby Clothes, Rompers, etc.
    $table->string('slug')->unique();
    $table->text('description')->nullable();
    $table->timestamps();
});

// ─── 2024_01_01_000004_create_products_table.php ────────────
Schema::create('products', function (Blueprint $table) {
    $table->id();
    $table->foreignId('category_id')->constrained();
    $table->string('name');
    $table->string('sku')->unique(); // TC-TSH-W-L format
    $table->string('size');          // S, M, L, XL, 2-3Y, 0-3M etc.
    $table->string('color');
    $table->string('color_hex')->nullable(); // #FFFFFF for display
    $table->decimal('cost_price', 10, 2)->default(0);
    $table->decimal('selling_price', 10, 2)->default(0);
    $table->integer('stock_qty')->default(0);
    $table->integer('low_stock_threshold')->default(10);
    $table->string('barcode')->unique()->nullable();
    $table->string('woocommerce_id')->nullable(); // WC product variation ID
    $table->boolean('sync_to_woocommerce')->default(true);
    $table->boolean('sync_to_facebook')->default(false);
    $table->boolean('is_active')->default(true);
    $table->text('notes')->nullable();
    $table->timestamps();
    $table->softDeletes();
    
    $table->index(['sku', 'barcode']);
    $table->index('woocommerce_id');
});

// ─── 2024_01_01_000005_create_stock_movements_table.php ─────
Schema::create('stock_movements', function (Blueprint $table) {
    $table->id();
    $table->foreignId('product_id')->constrained();
    $table->foreignId('user_id')->constrained();
    $table->enum('type', ['in', 'out', 'adjustment', 'production', 'sale', 'return']);
    $table->integer('quantity'); // positive = in, negative = out
    $table->integer('balance_after');
    $table->string('reference')->nullable(); // invoice no, job order no
    $table->text('notes')->nullable();
    $table->timestamps();
    
    $table->index(['product_id', 'created_at']);
});

// ─── 2024_01_01_000006_create_invoices_table.php ────────────
Schema::create('invoices', function (Blueprint $table) {
    $table->id();
    $table->string('invoice_number')->unique(); // INV-2024-001
    $table->foreignId('customer_id')->constrained();
    $table->foreignId('user_id')->constrained(); // created by
    $table->enum('type', ['invoice', 'quotation'])->default('invoice');
    $table->enum('status', ['draft', 'sent', 'partial', 'paid', 'cancelled'])->default('draft');
    $table->enum('source', ['manual', 'woocommerce', 'facebook'])->default('manual');
    $table->string('woocommerce_order_id')->nullable();
    $table->date('invoice_date');
    $table->date('due_date')->nullable();
    $table->decimal('subtotal', 12, 2)->default(0);
    $table->decimal('discount', 12, 2)->default(0);
    $table->decimal('tax', 12, 2)->default(0);
    $table->decimal('total', 12, 2)->default(0);
    $table->decimal('amount_paid', 12, 2)->default(0);
    $table->decimal('balance_due', 12, 2)->default(0);
    $table->text('notes')->nullable();
    $table->text('terms')->nullable();
    $table->timestamp('paid_at')->nullable();
    $table->timestamp('whatsapp_sent_at')->nullable();
    $table->timestamps();
    $table->softDeletes();
    
    $table->index(['status', 'invoice_date']);
    $table->index('customer_id');
});

// ─── 2024_01_01_000007_create_invoice_items_table.php ───────
Schema::create('invoice_items', function (Blueprint $table) {
    $table->id();
    $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
    $table->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
    $table->string('description');
    $table->string('sku')->nullable();
    $table->integer('quantity');
    $table->decimal('unit_price', 10, 2);
    $table->decimal('total', 10, 2);
    $table->timestamps();
});

// ─── 2024_01_01_000008_create_payments_table.php ────────────
Schema::create('payments', function (Blueprint $table) {
    $table->id();
    $table->foreignId('invoice_id')->constrained();
    $table->foreignId('user_id')->constrained();
    $table->decimal('amount', 12, 2);
    $table->enum('method', ['cash', 'bank_transfer', 'online', 'cheque'])->default('cash');
    $table->string('reference')->nullable(); // cheque no, transaction ID
    $table->date('payment_date');
    $table->text('notes')->nullable();
    $table->timestamps();
    
    $table->index(['invoice_id', 'payment_date']);
});

// ─── 2024_01_01_000009_create_expenses_table.php ────────────
Schema::create('expenses', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->string('title');
    $table->enum('category', [
        'cost_of_goods', 'salaries', 'rent', 'utilities',
        'marketing', 'transport', 'equipment', 'other'
    ]);
    $table->decimal('amount', 12, 2);
    $table->enum('payment_method', ['cash', 'bank_transfer', 'online', 'cheque'])->default('cash');
    $table->date('expense_date');
    $table->text('notes')->nullable();
    $table->string('receipt_path')->nullable();
    $table->timestamps();
    $table->softDeletes();
    
    $table->index(['category', 'expense_date']);
});

// ─── 2024_01_01_000010_create_workers_table.php ─────────────
Schema::create('workers', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('phone')->nullable();
    $table->string('specialty')->nullable(); // screen printing, sewing, etc.
    $table->boolean('is_active')->default(true);
    $table->timestamps();
});

// ─── 2024_01_01_000011_create_materials_table.php ───────────
Schema::create('materials', function (Blueprint $table) {
    $table->id();
    $table->string('name'); // Blank T-Shirts, Ink, Fabric etc.
    $table->string('unit'); // pcs, rolls, meters, kg
    $table->decimal('stock_qty', 10, 2)->default(0);
    $table->decimal('low_stock_threshold', 10, 2)->default(10);
    $table->decimal('cost_per_unit', 10, 2)->default(0);
    $table->timestamps();
});

// ─── 2024_01_01_000012_create_job_orders_table.php ──────────
Schema::create('job_orders', function (Blueprint $table) {
    $table->id();
    $table->string('job_number')->unique(); // J-2024-001
    $table->foreignId('invoice_id')->nullable()->constrained()->nullOnDelete();
    $table->foreignId('worker_id')->nullable()->constrained()->nullOnDelete();
    $table->foreignId('created_by')->constrained('users');
    $table->string('title');
    $table->text('description')->nullable();
    $table->enum('status', ['pending', 'in_progress', 'qc_check', 'completed', 'cancelled'])->default('pending');
    $table->integer('quantity');
    $table->date('due_date')->nullable();
    $table->date('completed_date')->nullable();
    $table->integer('progress_pct')->default(0); // 0-100
    $table->text('notes')->nullable();
    $table->timestamps();
    $table->softDeletes();
    
    $table->index(['status', 'due_date']);
});

// ─── 2024_01_01_000013_create_job_order_items_table.php ─────
Schema::create('job_order_items', function (Blueprint $table) {
    $table->id();
    $table->foreignId('job_order_id')->constrained()->cascadeOnDelete();
    $table->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
    $table->string('description');
    $table->integer('quantity');
    $table->timestamps();
});

// ─── 2024_01_01_000014_create_job_material_usage_table.php ──
Schema::create('job_material_usage', function (Blueprint $table) {
    $table->id();
    $table->foreignId('job_order_id')->constrained()->cascadeOnDelete();
    $table->foreignId('material_id')->constrained();
    $table->decimal('quantity_used', 10, 2);
    $table->text('notes')->nullable();
    $table->timestamps();
});

// ─── 2024_01_01_000015_create_settings_table.php ────────────
Schema::create('settings', function (Blueprint $table) {
    $table->id();
    $table->string('key')->unique();
    $table->text('value')->nullable();
    $table->string('group')->default('general'); // general, integrations, invoice
    $table->timestamps();
});
