<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #1a1a2e; background: #fff; }

  .header { background: #1a1a2e; color: white; padding: 24px 32px; display: flex; justify-content: space-between; }
  .logo { font-size: 22px; font-weight: bold; }
  .logo span { color: #e94560; }
  .invoice-meta { text-align: right; }
  .invoice-number { font-size: 20px; font-weight: bold; color: #e94560; }

  .body { padding: 24px 32px; }

  .addresses { display: flex; justify-content: space-between; margin-bottom: 24px; }
  .address-block h4 { font-size: 10px; text-transform: uppercase; color: #888; margin-bottom: 4px; letter-spacing: 1px; }
  .address-block p { font-size: 12px; line-height: 1.6; }

  .status-badge {
    display: inline-block;
    padding: 4px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
    margin-bottom: 20px;
  }
  .status-paid    { background: #d4edda; color: #155724; }
  .status-partial { background: #fff3cd; color: #856404; }
  .status-pending { background: #f8d7da; color: #721c24; }

  table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
  thead tr { background: #1a1a2e; color: white; }
  th { padding: 10px 12px; text-align: left; font-size: 11px; font-weight: normal; }
  th:last-child { text-align: right; }
  td { padding: 10px 12px; border-bottom: 1px solid #eee; }
  td:last-child { text-align: right; font-weight: 500; }
  tr:nth-child(even) td { background: #f9f9f9; }

  .totals { margin-left: auto; width: 260px; }
  .totals-row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #eee; font-size: 12px; }
  .totals-row.final { font-weight: bold; font-size: 14px; color: #1a1a2e; border-bottom: none; padding-top: 10px; }

  .payment-section { margin-top: 20px; padding-top: 16px; border-top: 1px solid #eee; }
  .payment-section h4 { font-size: 11px; text-transform: uppercase; color: #888; margin-bottom: 8px; }

  .balance-box { background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px; padding: 12px 16px; margin-top: 16px; }
  .balance-box.paid { background: #d4edda; border-color: #28a745; }

  .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #eee; display: flex; justify-content: space-between; color: #888; font-size: 10px; }
  .qr { text-align: center; }

  .watermark { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-30deg);
    font-size: 72px; color: rgba(40,167,69,0.08); font-weight: bold; white-space: nowrap; }
</style>
</head>
<body>

@if($invoice->status === 'paid')
<div class="watermark">PAID</div>
@endif

<!-- Header -->
<div class="header">
  <div>
    <div class="logo">Tiny<span>Cubs</span>.lk</div>
    <div style="font-size:11px;opacity:0.7;margin-top:4px;">{{ $settings['company_address'] ?? 'Colombo, Sri Lanka' }}</div>
    <div style="font-size:11px;opacity:0.7;">{{ $settings['company_phone'] ?? '' }}</div>
    <div style="font-size:11px;opacity:0.7;">{{ $settings['company_email'] ?? '' }}</div>
  </div>
  <div class="invoice-meta">
    <div class="invoice-number">{{ strtoupper($invoice->type) }} #{{ $invoice->invoice_number }}</div>
    <div style="margin-top:8px;font-size:11px;opacity:0.8;">Date: {{ $invoice->invoice_date->format('d M Y') }}</div>
    @if($invoice->due_date)
    <div style="font-size:11px;opacity:0.8;">Due: {{ $invoice->due_date->format('d M Y') }}</div>
    @endif
    @if($invoice->source === 'woocommerce')
    <div style="font-size:10px;opacity:0.6;margin-top:4px;">via WooCommerce</div>
    @endif
  </div>
</div>

<div class="body">

  <!-- Addresses -->
  <div class="addresses" style="margin-top:20px;">
    <div class="address-block">
      <h4>Bill To</h4>
      <p><strong>{{ $invoice->customer->name }}</strong></p>
      @if($invoice->customer->company)<p>{{ $invoice->customer->company }}</p>@endif
      @if($invoice->customer->phone)<p>{{ $invoice->customer->phone }}</p>@endif
      @if($invoice->customer->email)<p>{{ $invoice->customer->email }}</p>@endif
      @if($invoice->customer->address)<p>{{ $invoice->customer->address }}</p>@endif
    </div>
    <div class="address-block" style="text-align:right;">
      <h4>Payment Status</h4>
      @php
        $statusClass = match($invoice->status) {
          'paid'    => 'status-paid',
          'partial' => 'status-partial',
          default   => 'status-pending',
        };
        $statusLabel = match($invoice->status) {
          'paid'    => 'PAID IN FULL',
          'partial' => 'PARTIALLY PAID',
          'sent'    => 'PAYMENT DUE',
          'draft'   => 'DRAFT',
          default   => strtoupper($invoice->status),
        };
      @endphp
      <div><span class="status-badge {{ $statusClass }}">{{ $statusLabel }}</span></div>
    </div>
  </div>

  <!-- Items Table -->
  <table>
    <thead>
      <tr>
        <th width="40%">Description</th>
        <th width="15%">SKU</th>
        <th width="10%">Qty</th>
        <th width="15%">Unit Price</th>
        <th width="20%">Total</th>
      </tr>
    </thead>
    <tbody>
      @foreach($invoice->items as $item)
      <tr>
        <td>{{ $item->description }}</td>
        <td style="font-size:10px;color:#888;">{{ $item->sku ?? '—' }}</td>
        <td>{{ $item->quantity }}</td>
        <td>{{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($item->unit_price, 2) }}</td>
        <td>{{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($item->total, 2) }}</td>
      </tr>
      @endforeach
    </tbody>
  </table>

  <!-- Totals -->
  <div style="display:flex;justify-content:flex-end;">
    <div class="totals">
      <div class="totals-row"><span>Subtotal</span><span>{{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($invoice->subtotal, 2) }}</span></div>
      @if($invoice->discount > 0)
      <div class="totals-row" style="color:#e94560;"><span>Discount</span><span>- {{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($invoice->discount, 2) }}</span></div>
      @endif
      @if($invoice->tax > 0)
      <div class="totals-row"><span>Tax</span><span>{{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($invoice->tax, 2) }}</span></div>
      @endif
      <div class="totals-row final"><span>Total</span><span>{{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($invoice->total, 2) }}</span></div>
    </div>
  </div>

  <!-- Payments -->
  @if($invoice->payments->count() > 0)
  <div class="payment-section">
    <h4>Payment History</h4>
    <table>
      <thead>
        <tr>
          <th>Date</th><th>Method</th><th>Reference</th><th>Amount</th>
        </tr>
      </thead>
      <tbody>
        @foreach($invoice->payments as $payment)
        <tr>
          <td>{{ $payment->payment_date->format('d M Y') }}</td>
          <td>{{ str_replace('_', ' ', ucfirst($payment->method)) }}</td>
          <td>{{ $payment->reference ?? '—' }}</td>
          <td>{{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($payment->amount, 2) }}</td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  @endif

  <!-- Balance -->
  @if($invoice->balance_due > 0)
  <div class="balance-box">
    <strong>Balance Due: {{ $settings['currency_symbol'] ?? 'Rs' }} {{ number_format($invoice->balance_due, 2) }}</strong>
    @if($invoice->due_date)
    <span style="float:right;font-size:11px;color:#666;">Due by {{ $invoice->due_date->format('d M Y') }}</span>
    @endif
  </div>
  @else
  <div class="balance-box paid">
    <strong>✓ Fully Paid — Thank you!</strong>
    <span style="float:right;font-size:11px;">Paid on {{ $invoice->paid_at?->format('d M Y') }}</span>
  </div>
  @endif

  <!-- Notes & Terms -->
  @if($invoice->notes)
  <div style="margin-top:20px;">
    <h4 style="font-size:11px;color:#888;text-transform:uppercase;margin-bottom:4px;">Notes</h4>
    <p style="font-size:11px;color:#555;">{{ $invoice->notes }}</p>
  </div>
  @endif

  @if($invoice->terms)
  <div style="margin-top:12px;">
    <h4 style="font-size:11px;color:#888;text-transform:uppercase;margin-bottom:4px;">Terms & Conditions</h4>
    <p style="font-size:11px;color:#555;">{{ $invoice->terms }}</p>
  </div>
  @endif

  <!-- Footer -->
  <div class="footer">
    <div>
      <p>TinyCubs.lk &nbsp;·&nbsp; {{ $settings['company_phone'] ?? '' }} &nbsp;·&nbsp; www.tinycubs.lk</p>
      <p style="margin-top:2px;">Generated by TinyCubs ERP on {{ now()->format('d M Y, H:i') }}</p>
    </div>
    <div>Thank you for your business! 🧸</div>
  </div>

</div>
</body>
</html>
