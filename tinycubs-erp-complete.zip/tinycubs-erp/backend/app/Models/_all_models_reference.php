<?php
// ============================================================
// TinyCubs ERP — All Eloquent Models
// Each model is in its own file: app/Models/{Name}.php
// This file is a consolidated reference only.
// ============================================================

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

// ─── User ─────────────────────────────────────────────────────
class User extends Authenticatable {
    use HasApiTokens;
    protected $fillable = ['name','email','phone','password','role','is_active'];
    protected $hidden   = ['password','remember_token'];
    protected $casts    = ['is_active' => 'boolean', 'last_login_at' => 'datetime'];
}

// ─── Customer ─────────────────────────────────────────────────
class Customer extends Model {
    use SoftDeletes;
    protected $fillable = ['name','phone','email','address','company','type','woocommerce_id','total_purchases'];

    public function invoices() { return $this->hasMany(Invoice::class); }
    public function totalSpent() { return $this->invoices()->sum('amount_paid'); }
}

// ─── Category ─────────────────────────────────────────────────
class Category extends Model {
    protected $fillable = ['name','slug','description'];
    public function products() { return $this->hasMany(Product::class); }
}

// ─── Product ──────────────────────────────────────────────────
class Product extends Model {
    use SoftDeletes;
    protected $fillable = [
        'category_id','name','sku','size','color','color_hex',
        'cost_price','selling_price','stock_qty','low_stock_threshold',
        'barcode','woocommerce_id','sync_to_woocommerce','sync_to_facebook','is_active','notes'
    ];
    protected $casts = [
        'cost_price'          => 'decimal:2',
        'selling_price'       => 'decimal:2',
        'sync_to_woocommerce' => 'boolean',
        'sync_to_facebook'    => 'boolean',
        'is_active'           => 'boolean',
    ];

    public function category()   { return $this->belongsTo(Category::class); }
    public function movements()  { return $this->hasMany(StockMovement::class); }
    public function isLowStock() { return $this->stock_qty <= $this->low_stock_threshold; }
    public function stockValue() { return $this->stock_qty * $this->cost_price; }
}

// ─── StockMovement ────────────────────────────────────────────
class StockMovement extends Model {
    protected $fillable = ['product_id','user_id','type','quantity','balance_after','reference','notes'];

    public function product() { return $this->belongsTo(Product::class); }
    public function user()    { return $this->belongsTo(User::class); }
}

// ─── Invoice ──────────────────────────────────────────────────
class Invoice extends Model {
    use SoftDeletes;
    protected $fillable = [
        'invoice_number','customer_id','user_id','type','status','source',
        'woocommerce_order_id','invoice_date','due_date',
        'subtotal','discount','tax','total','amount_paid','balance_due',
        'notes','terms','paid_at','whatsapp_sent_at'
    ];
    protected $casts = [
        'invoice_date'     => 'date',
        'due_date'         => 'date',
        'paid_at'          => 'datetime',
        'whatsapp_sent_at' => 'datetime',
        'subtotal'         => 'decimal:2',
        'discount'         => 'decimal:2',
        'total'            => 'decimal:2',
        'amount_paid'      => 'decimal:2',
        'balance_due'      => 'decimal:2',
    ];

    public function customer()  { return $this->belongsTo(Customer::class); }
    public function user()      { return $this->belongsTo(User::class); }
    public function items()     { return $this->hasMany(InvoiceItem::class); }
    public function payments()  { return $this->hasMany(Payment::class); }

    // Auto-update balance after payment
    public function recalculate(): void {
        $paid = $this->payments()->sum('amount');
        $this->update([
            'amount_paid' => $paid,
            'balance_due' => max(0, $this->total - $paid),
            'status'      => $paid <= 0 ? 'sent'
                : ($paid >= $this->total ? 'paid' : 'partial'),
            'paid_at'     => $paid >= $this->total ? now() : null,
        ]);
        // Update customer total
        $this->customer->update([
            'total_purchases' => $this->customer->invoices()
                ->where('status', 'paid')->sum('total'),
        ]);
    }
}

// ─── InvoiceItem ──────────────────────────────────────────────
class InvoiceItem extends Model {
    protected $fillable = ['invoice_id','product_id','description','sku','quantity','unit_price','total'];
    protected $casts    = ['unit_price' => 'decimal:2', 'total' => 'decimal:2'];

    public function invoice() { return $this->belongsTo(Invoice::class); }
    public function product() { return $this->belongsTo(Product::class)->withTrashed(); }
}

// ─── Payment ──────────────────────────────────────────────────
class Payment extends Model {
    protected $fillable = ['invoice_id','user_id','amount','method','reference','payment_date','notes'];
    protected $casts    = ['payment_date' => 'date', 'amount' => 'decimal:2'];

    public function invoice() { return $this->belongsTo(Invoice::class); }
    public function user()    { return $this->belongsTo(User::class); }

    // After payment saved, recalculate invoice
    protected static function booted(): void {
        static::created(fn($p)  => $p->invoice->recalculate());
        static::deleted(fn($p)  => $p->invoice->recalculate());
    }
}

// ─── Expense ──────────────────────────────────────────────────
class Expense extends Model {
    use SoftDeletes;
    protected $fillable = ['user_id','title','category','amount','payment_method','expense_date','notes','receipt_path'];
    protected $casts    = ['expense_date' => 'date', 'amount' => 'decimal:2'];

    public function user() { return $this->belongsTo(User::class); }
}

// ─── Worker ───────────────────────────────────────────────────
class Worker extends Model {
    protected $fillable = ['name','phone','specialty','is_active'];
    protected $casts    = ['is_active' => 'boolean'];

    public function jobOrders() { return $this->hasMany(JobOrder::class); }
}

// ─── Material ─────────────────────────────────────────────────
class Material extends Model {
    protected $fillable = ['name','unit','stock_qty','low_stock_threshold','cost_per_unit'];
    protected $casts    = ['stock_qty' => 'decimal:2', 'cost_per_unit' => 'decimal:2'];
}

// ─── JobOrder ─────────────────────────────────────────────────
class JobOrder extends Model {
    use SoftDeletes;
    protected $fillable = [
        'job_number','invoice_id','worker_id','created_by',
        'title','description','status','quantity','due_date',
        'completed_date','progress_pct','notes'
    ];
    protected $casts = ['due_date' => 'date', 'completed_date' => 'date'];

    public function worker()        { return $this->belongsTo(Worker::class); }
    public function invoice()       { return $this->belongsTo(Invoice::class); }
    public function createdBy()     { return $this->belongsTo(User::class, 'created_by'); }
    public function items()         { return $this->hasMany(JobOrderItem::class); }
    public function materialUsage() { return $this->hasMany(JobMaterialUsage::class); }
}

// ─── JobOrderItem ─────────────────────────────────────────────
class JobOrderItem extends Model {
    protected $fillable = ['job_order_id','product_id','description','quantity'];
    public function product() { return $this->belongsTo(Product::class)->withTrashed(); }
}

// ─── JobMaterialUsage ─────────────────────────────────────────
class JobMaterialUsage extends Model {
    protected $fillable = ['job_order_id','material_id','quantity_used','notes'];
    protected $casts    = ['quantity_used' => 'decimal:2'];
    public function material() { return $this->belongsTo(Material::class); }
}

// ─── Setting ──────────────────────────────────────────────────
class Setting extends Model {
    protected $fillable = ['key','value','group'];

    public static function get(string $key, mixed $default = null): mixed {
        return static::where('key', $key)->value('value') ?? $default;
    }
}
