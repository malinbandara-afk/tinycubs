<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Invoice;
use App\Models\Customer;
use App\Models\InvoiceItem;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WooCommerceService
{
    private string $baseUrl;
    private string $consumerKey;
    private string $consumerSecret;

    public function __construct()
    {
        $this->baseUrl        = config('services.woocommerce.base_url');
        $this->consumerKey    = config('services.woocommerce.consumer_key');
        $this->consumerSecret = config('services.woocommerce.consumer_secret');
    }

    // ─── HTTP Client ─────────────────────────────────────────
    private function client()
    {
        return Http::withBasicAuth($this->consumerKey, $this->consumerSecret)
                   ->acceptJson()
                   ->baseUrl($this->baseUrl);
    }

    // ─── Pull Orders from WooCommerce → ERP ──────────────────
    public function syncOrders(string $status = 'processing'): array
    {
        $imported = 0;
        $page     = 1;

        do {
            $response = $this->client()->get('/orders', [
                'status'   => $status,
                'per_page' => 50,
                'page'     => $page,
            ]);

            if (!$response->ok()) break;

            $orders = $response->json();

            foreach ($orders as $order) {
                // Skip already imported
                if (Invoice::where('woocommerce_order_id', $order['id'])->exists()) continue;

                $this->importOrder($order);
                $imported++;
            }

            $page++;
        } while (count($orders) === 50);

        return ['imported' => $imported];
    }

    private function importOrder(array $order): void
    {
        // Find or create customer
        $billing  = $order['billing'];
        $customer = Customer::firstOrCreate(
            ['email' => $billing['email']],
            [
                'name'            => trim($billing['first_name'] . ' ' . $billing['last_name']),
                'phone'           => $billing['phone'] ?? null,
                'address'         => "{$billing['address_1']}, {$billing['city']}",
                'type'            => 'online',
                'woocommerce_id'  => $order['customer_id'],
            ]
        );

        // Map WC payment method
        $methodMap = [
            'bacs'   => 'bank_transfer',
            'cod'    => 'cash',
            'stripe' => 'online',
            'paypal' => 'online',
        ];
        $payMethod = $methodMap[$order['payment_method']] ?? 'online';

        $total = (float) $order['total'];

        $invoice = Invoice::create([
            'invoice_number'       => 'WC-' . $order['number'],
            'customer_id'          => $customer->id,
            'user_id'              => 1, // system user
            'type'                 => 'invoice',
            'status'               => $order['status'] === 'completed' ? 'paid' : 'sent',
            'source'               => 'woocommerce',
            'woocommerce_order_id' => $order['id'],
            'invoice_date'         => now()->toDateString(),
            'subtotal'             => (float) $order['subtotal'],
            'discount'             => (float) $order['discount_total'],
            'total'                => $total,
            'amount_paid'          => $order['status'] === 'completed' ? $total : 0,
            'balance_due'          => $order['status'] === 'completed' ? 0 : $total,
            'paid_at'              => $order['status'] === 'completed' ? now() : null,
        ]);

        foreach ($order['line_items'] as $item) {
            $product = Product::where('woocommerce_id', $item['variation_id'] ?: $item['product_id'])->first();

            InvoiceItem::create([
                'invoice_id'  => $invoice->id,
                'product_id'  => $product?->id,
                'description' => $item['name'],
                'sku'         => $item['sku'] ?? $product?->sku,
                'quantity'    => $item['quantity'],
                'unit_price'  => (float) $item['price'],
                'total'       => (float) $item['total'],
            ]);

            // Deduct stock if product matched
            if ($product) {
                app(StockService::class)->deduct(
                    $product->id,
                    $item['quantity'],
                    'sale',
                    $invoice->invoice_number
                );
            }
        }

        Log::info("WC Order #{$order['id']} imported as {$invoice->invoice_number}");
    }

    // ─── Push Stock from ERP → WooCommerce ───────────────────
    public function pushStock(Product $product): bool
    {
        if (!$product->woocommerce_id) return false;

        $response = $this->client()->put("/products/{$product->woocommerce_id}", [
            'stock_quantity' => $product->stock_qty,
            'manage_stock'   => true,
            'stock_status'   => $product->stock_qty > 0 ? 'instock' : 'outofstock',
        ]);

        if (!$response->ok()) {
            Log::error("WC stock push failed for {$product->sku}", $response->json());
            return false;
        }

        return true;
    }

    // ─── Push Product Catalog ERP → WooCommerce ──────────────
    public function pushProduct(Product $product): bool
    {
        $data = [
            'name'           => $product->name,
            'sku'            => $product->sku,
            'regular_price'  => (string) $product->selling_price,
            'stock_quantity' => $product->stock_qty,
            'manage_stock'   => true,
            'attributes'     => [
                ['name' => 'Size', 'options' => [$product->size], 'visible' => true],
                ['name' => 'Color', 'options' => [$product->color], 'visible' => true],
            ],
        ];

        if ($product->woocommerce_id) {
            $response = $this->client()->put("/products/{$product->woocommerce_id}", $data);
        } else {
            $response = $this->client()->post('/products', $data);
            if ($response->ok()) {
                $product->update(['woocommerce_id' => $response->json('id')]);
            }
        }

        return $response->ok();
    }

    // ─── Check Connection ─────────────────────────────────────
    public function testConnection(): array
    {
        try {
            $response = $this->client()->get('/system_status');
            return [
                'connected' => $response->ok(),
                'store'     => $response->json('environment.site_url') ?? null,
            ];
        } catch (\Throwable $e) {
            return ['connected' => false, 'error' => $e->getMessage()];
        }
    }
}
