<?php

namespace App\Services;

use App\Models\Invoice;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client as TwilioClient;

class WhatsAppService
{
    // ─── Send Invoice via WhatsApp ────────────────────────────
    public function sendInvoice(Invoice $invoice): array
    {
        $customer = $invoice->customer;
        $phone    = $this->normalizePhone($customer->phone);

        if (!$phone) {
            return ['success' => false, 'message' => 'Customer has no phone number.'];
        }

        $currency = setting('currency_symbol', 'Rs');
        $message  = $this->buildInvoiceMessage($invoice, $currency);

        $result = match (config('services.whatsapp.provider', 'twilio')) {
            'meta'   => $this->sendViaMeta($phone, $message),
            default  => $this->sendViaTwilio($phone, $message),
        };

        if ($result['success']) {
            $invoice->update(['whatsapp_sent_at' => now()]);
        }

        return $result;
    }

    // ─── Message Template ─────────────────────────────────────
    private function buildInvoiceMessage(Invoice $invoice, string $currency): string
    {
        $items = $invoice->items->map(fn($i) =>
            "• {$i->description} × {$i->quantity} = {$currency} " . number_format($i->total, 2)
        )->join("\n");

        $status = match ($invoice->status) {
            'paid'    => '✅ FULLY PAID',
            'partial' => "⚠️ PARTIAL — Balance: {$currency} " . number_format($invoice->balance_due, 2),
            default   => "❗ PAYMENT DUE: {$currency} " . number_format($invoice->balance_due, 2),
        };

        return <<<MSG
        🧸 *TinyCubs.lk* — Invoice

        Invoice No: *{$invoice->invoice_number}*
        Date: {$invoice->invoice_date->format('d M Y')}
        Customer: {$invoice->customer->name}

        *Items:*
        {$items}

        ─────────────────
        Subtotal: {$currency} {$invoice->subtotal}
        Discount: {$currency} {$invoice->discount}
        *Total: {$currency} {$invoice->total}*

        {$status}

        Thank you for shopping with TinyCubs! 🎉
        www.tinycubs.lk
        MSG;
    }

    // ─── Send via Twilio WhatsApp ─────────────────────────────
    private function sendViaTwilio(string $phone, string $message): array
    {
        try {
            $twilio = new TwilioClient(
                config('services.twilio.account_sid'),
                config('services.twilio.auth_token')
            );

            $twilio->messages->create("whatsapp:{$phone}", [
                'from' => config('services.twilio.whatsapp_from'),
                'body' => $message,
            ]);

            return ['success' => true, 'provider' => 'twilio'];
        } catch (\Throwable $e) {
            Log::error('WhatsApp Twilio error: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // ─── Send via Meta Cloud API ──────────────────────────────
    private function sendViaMeta(string $phone, string $message): array
    {
        $token   = config('services.meta.whatsapp_token');
        $phoneId = config('services.meta.whatsapp_phone_id');

        // Remove leading +
        $to = ltrim($phone, '+');

        $response = Http::withToken($token)
            ->post("https://graph.facebook.com/v18.0/{$phoneId}/messages", [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'text',
                'text'              => ['body' => $message],
            ]);

        if ($response->ok()) {
            return ['success' => true, 'provider' => 'meta'];
        }

        Log::error('WhatsApp Meta error', $response->json());
        return ['success' => false, 'message' => $response->json('error.message')];
    }

    // ─── Normalize phone to E.164 for Sri Lanka ───────────────
    private function normalizePhone(?string $phone): ?string
    {
        if (!$phone) return null;

        $digits = preg_replace('/\D/', '', $phone);

        // 0771234567 → +94771234567
        if (strlen($digits) === 10 && str_starts_with($digits, '0')) {
            return '+94' . substr($digits, 1);
        }

        // 94771234567 → +94771234567
        if (strlen($digits) === 11 && str_starts_with($digits, '94')) {
            return '+' . $digits;
        }

        // Already has country code
        if (str_starts_with($phone, '+')) {
            return $phone;
        }

        return null;
    }
}
