<?php

namespace App\Services;

use App\Models\Product;
use App\Models\StockMovement;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class StockService
{
    public function deduct(int $productId, int $qty, string $type, string $reference = ''): StockMovement
    {
        return $this->move($productId, -$qty, $type, $reference);
    }

    public function add(int $productId, int $qty, string $type = 'in', string $reference = ''): StockMovement
    {
        return $this->move($productId, $qty, $type, $reference);
    }

    public function move(int $productId, int $qty, string $type, string $reference = '', string $notes = ''): StockMovement
    {
        $product = Product::lockForUpdate()->findOrFail($productId);

        $newBalance = $product->stock_qty + $qty;

        if ($newBalance < 0) {
            Log::warning("Stock would go negative for SKU {$product->sku}: {$product->stock_qty} + {$qty}");
            // Allow but clamp at 0 for partial fulfilments
            $newBalance = 0;
        }

        $product->update(['stock_qty' => $newBalance]);

        $movement = StockMovement::create([
            'product_id'    => $productId,
            'user_id'       => auth()->id() ?? 1,
            'type'          => $type,
            'quantity'      => $qty,
            'balance_after' => $newBalance,
            'reference'     => $reference,
            'notes'         => $notes,
        ]);

        // Check low stock threshold
        if ($newBalance <= $product->low_stock_threshold && $newBalance > 0) {
            $this->alertLowStock($product, $newBalance);
        }

        // Sync to WooCommerce if enabled
        if ($product->sync_to_woocommerce && $product->woocommerce_id && setting('wc_sync_enabled') === '1') {
            dispatch(fn() => app(WooCommerceService::class)->pushStock($product))->afterResponse();
        }

        return $movement;
    }

    private function alertLowStock(Product $product, int $balance): void
    {
        $cacheKey = "low_stock_alert_{$product->id}";

        // Only alert once per hour per product
        if (cache()->has($cacheKey)) return;

        cache()->put($cacheKey, true, 3600);

        $email = setting('low_stock_alert_email');
        if ($email) {
            Log::info("Low stock alert: {$product->sku} has {$balance} units left.");
            // Mail::to($email)->send(new \App\Mail\LowStockAlert($product, $balance));
        }
    }

    public function getMovements(int $productId, int $days = 30): \Illuminate\Database\Eloquent\Collection
    {
        return StockMovement::where('product_id', $productId)
            ->where('created_at', '>=', now()->subDays($days))
            ->with('user')
            ->latest()
            ->get();
    }
}
