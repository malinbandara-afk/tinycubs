<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Expense;
use App\Models\Product;
use App\Models\JobOrder;
use App\Models\Payment;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(): JsonResponse
    {
        $today     = now()->toDateString();
        $monthStart= now()->startOfMonth()->toDateString();

        // ── Today's stats ────────────────────────────────────
        $todayRevenue = Invoice::whereDate('invoice_date', $today)
            ->where('type', 'invoice')
            ->whereNotIn('status', ['draft', 'cancelled'])
            ->sum('amount_paid');

        $todayOrders = Invoice::whereDate('invoice_date', $today)
            ->where('type', 'invoice')
            ->whereNotIn('status', ['draft', 'cancelled'])
            ->count();

        $todayExpenses = Expense::whereDate('expense_date', $today)->sum('amount');

        // ── Cash in hand (all time cash payments - expenses paid in cash) ──
        $cashIn  = Payment::where('method', 'cash')
            ->whereMonth('payment_date', now()->month)
            ->sum('amount');
        $cashOut = Expense::where('payment_method', 'cash')
            ->whereMonth('expense_date', now()->month)
            ->sum('amount');
        $cashInHand = $cashIn - $cashOut;

        // ── Outstanding ───────────────────────────────────────
        $outstanding = Invoice::whereIn('status', ['sent', 'partial'])
            ->where('type', 'invoice')
            ->sum('balance_due');

        $outstandingCount = Invoice::whereIn('status', ['sent', 'partial'])
            ->where('type', 'invoice')
            ->count();

        // ── Month revenue ─────────────────────────────────────
        $monthRevenue = Invoice::where('type', 'invoice')
            ->whereNotIn('status', ['draft', 'cancelled'])
            ->whereBetween('invoice_date', [$monthStart, $today])
            ->sum('amount_paid');

        // ── Production ────────────────────────────────────────
        $jobsPending    = JobOrder::where('status', 'pending')->count();
        $jobsInProgress = JobOrder::where('status', 'in_progress')->count();
        $jobsCompleted  = JobOrder::whereMonth('updated_at', now()->month)
            ->where('status', 'completed')->count();

        // ── Low stock ─────────────────────────────────────────
        $lowStock = Product::where('is_active', true)
            ->whereColumn('stock_qty', '<=', 'low_stock_threshold')
            ->where('stock_qty', '>', 0)
            ->with('category')
            ->orderBy('stock_qty')
            ->limit(5)
            ->get(['id', 'name', 'sku', 'size', 'color', 'stock_qty', 'low_stock_threshold', 'category_id']);

        $outOfStock = Product::where('is_active', true)
            ->where('stock_qty', '<=', 0)->count();

        // ── Recent activity ───────────────────────────────────
        $recentInvoices = Invoice::with('customer')
            ->whereNotIn('status', ['draft'])
            ->latest()
            ->limit(5)
            ->get(['id', 'invoice_number', 'customer_id', 'total', 'status', 'source', 'created_at']);

        // ── Expense breakdown this month ──────────────────────
        $expenseBreakdown = Expense::whereBetween('expense_date', [$monthStart, $today])
            ->select('category', DB::raw('SUM(amount) as total'))
            ->groupBy('category')
            ->pluck('total', 'category');

        // ── Payment methods this month ────────────────────────
        $paymentMethods = Payment::whereMonth('payment_date', now()->month)
            ->select('method', DB::raw('SUM(amount) as total'))
            ->groupBy('method')
            ->pluck('total', 'method');

        return response()->json([
            'today' => [
                'revenue'   => $todayRevenue,
                'orders'    => $todayOrders,
                'expenses'  => $todayExpenses,
            ],
            'month' => [
                'revenue'   => $monthRevenue,
            ],
            'cash_in_hand'       => max(0, $cashInHand),
            'outstanding'        => $outstanding,
            'outstanding_count'  => $outstandingCount,
            'production' => [
                'pending'     => $jobsPending,
                'in_progress' => $jobsInProgress,
                'completed'   => $jobsCompleted,
            ],
            'low_stock'          => $lowStock,
            'out_of_stock_count' => $outOfStock,
            'recent_invoices'    => $recentInvoices,
            'expense_breakdown'  => $expenseBreakdown,
            'payment_methods'    => $paymentMethods,
        ]);
    }

    public function salesChart(string $period = 'monthly'): JsonResponse
    {
        $data = match ($period) {
            'daily' => $this->dailyChart(),
            'weekly'=> $this->weeklyChart(),
            default => $this->monthlyChart(),
        };

        return response()->json($data);
    }

    private function monthlyChart(): array
    {
        return Invoice::where('type', 'invoice')
            ->whereNotIn('status', ['draft', 'cancelled'])
            ->where('invoice_date', '>=', now()->subMonths(6)->startOfMonth())
            ->select(
                DB::raw("DATE_FORMAT(invoice_date, '%Y-%m') as period"),
                DB::raw('SUM(total) as revenue'),
                DB::raw('SUM(amount_paid) as collected'),
                DB::raw('COUNT(*) as orders')
            )
            ->groupBy('period')
            ->orderBy('period')
            ->get()
            ->toArray();
    }

    private function dailyChart(): array
    {
        return Invoice::where('type', 'invoice')
            ->whereNotIn('status', ['draft', 'cancelled'])
            ->where('invoice_date', '>=', now()->subDays(30))
            ->select(
                DB::raw("DATE(invoice_date) as period"),
                DB::raw('SUM(total) as revenue'),
                DB::raw('COUNT(*) as orders')
            )
            ->groupBy('period')
            ->orderBy('period')
            ->get()
            ->toArray();
    }

    private function weeklyChart(): array
    {
        return Invoice::where('type', 'invoice')
            ->whereNotIn('status', ['draft', 'cancelled'])
            ->where('invoice_date', '>=', now()->subWeeks(12))
            ->select(
                DB::raw("YEARWEEK(invoice_date, 1) as period"),
                DB::raw('SUM(total) as revenue'),
                DB::raw('COUNT(*) as orders')
            )
            ->groupBy('period')
            ->orderBy('period')
            ->get()
            ->toArray();
    }
}
