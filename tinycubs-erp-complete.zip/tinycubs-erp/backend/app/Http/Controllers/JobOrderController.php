<?php

namespace App\Http\Controllers;

use App\Models\JobOrder;
use App\Models\Material;
use App\Models\JobMaterialUsage;
use App\Services\StockService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class JobOrderController extends Controller
{
    public function __construct(private StockService $stockService) {}

    public function index(Request $request): JsonResponse
    {
        $jobs = JobOrder::with(['worker', 'items.product', 'invoice.customer', 'createdBy'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->worker_id, fn($q) => $q->where('worker_id', $request->worker_id))
            ->latest()
            ->paginate($request->per_page ?? 20);

        return response()->json($jobs);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'worker_id'   => 'nullable|exists:workers,id',
            'invoice_id'  => 'nullable|exists:invoices,id',
            'quantity'    => 'required|integer|min:1',
            'due_date'    => 'nullable|date',
            'notes'       => 'nullable|string',
            'items'       => 'nullable|array',
            'items.*.product_id'  => 'nullable|exists:products,id',
            'items.*.description' => 'required|string',
            'items.*.quantity'    => 'required|integer|min:1',
        ]);

        $job = JobOrder::create([
            ...$validated,
            'job_number' => $this->generateJobNumber(),
            'created_by' => auth()->id(),
            'status'     => 'pending',
        ]);

        if (!empty($validated['items'])) {
            foreach ($validated['items'] as $item) {
                $job->items()->create($item);
            }
        }

        return response()->json($job->load(['worker', 'items.product']), 201);
    }

    public function show(JobOrder $jobOrder): JsonResponse
    {
        return response()->json(
            $jobOrder->load(['worker', 'items.product', 'materialUsage.material', 'invoice.customer', 'createdBy'])
        );
    }

    public function update(Request $request, JobOrder $jobOrder): JsonResponse
    {
        $jobOrder->update($request->only([
            'title', 'description', 'worker_id', 'due_date', 'notes', 'quantity'
        ]));
        return response()->json($jobOrder->fresh(['worker', 'items']));
    }

    public function destroy(JobOrder $jobOrder): JsonResponse
    {
        if (in_array($jobOrder->status, ['in_progress', 'completed'])) {
            return response()->json(['message' => 'Cannot delete an active or completed job.'], 422);
        }
        $jobOrder->delete();
        return response()->json(['message' => 'Job order deleted.']);
    }

    public function updateStatus(Request $request, JobOrder $jobOrder): JsonResponse
    {
        $request->validate([
            'status' => 'required|in:pending,in_progress,qc_check,completed,cancelled',
        ]);

        $oldStatus = $jobOrder->status;
        $newStatus = $request->status;

        $jobOrder->update([
            'status'         => $newStatus,
            'completed_date' => $newStatus === 'completed' ? now()->toDateString() : $jobOrder->completed_date,
            'progress_pct'   => match ($newStatus) {
                'pending'     => 0,
                'in_progress' => max($jobOrder->progress_pct, 10),
                'qc_check'    => 90,
                'completed'   => 100,
                'cancelled'   => $jobOrder->progress_pct,
            },
        ]);

        // When completed: add finished products to inventory
        if ($newStatus === 'completed' && $oldStatus !== 'completed') {
            foreach ($jobOrder->items as $item) {
                if ($item->product_id) {
                    $this->stockService->add(
                        $item->product_id,
                        $item->quantity,
                        'production',
                        $jobOrder->job_number
                    );
                }
            }
        }

        return response()->json($jobOrder->fresh(['worker', 'items']));
    }

    public function updateProgress(Request $request, JobOrder $jobOrder): JsonResponse
    {
        $request->validate(['progress' => 'required|integer|min:0|max:100']);
        $jobOrder->update(['progress_pct' => $request->progress]);
        return response()->json(['progress_pct' => $request->progress]);
    }

    public function addMaterial(Request $request, JobOrder $jobOrder): JsonResponse
    {
        $request->validate([
            'material_id'   => 'required|exists:materials,id',
            'quantity_used' => 'required|numeric|min:0.01',
            'notes'         => 'nullable|string',
        ]);

        $material = Material::findOrFail($request->material_id);

        // Deduct from material stock
        $material->decrement('stock_qty', $request->quantity_used);

        $usage = JobMaterialUsage::create([
            'job_order_id'  => $jobOrder->id,
            'material_id'   => $request->material_id,
            'quantity_used' => $request->quantity_used,
            'notes'         => $request->notes,
        ]);

        return response()->json($usage->load('material'), 201);
    }

    private function generateJobNumber(): string
    {
        $year = now()->format('Y');
        $last = JobOrder::whereYear('created_at', $year)
            ->max(\Illuminate\Support\Facades\DB::raw(
                "CAST(SUBSTRING_INDEX(job_number, '-', -1) AS UNSIGNED)"
            ));
        return 'J-' . $year . '-' . str_pad(($last ?? 0) + 1, 4, '0', STR_PAD_LEFT);
    }
}
