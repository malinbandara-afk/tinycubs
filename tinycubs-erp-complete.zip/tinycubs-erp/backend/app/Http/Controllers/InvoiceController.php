<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Product;
use App\Models\Customer;
use App\Services\StockService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller
{
    public function __construct(private StockService $stockService) {}

    public function index(Request $request): JsonResponse
    {
        $query = Invoice::with(['customer', 'user', 'items.product'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->source, fn($q) => $q->where('source', $request->source))
            ->when($request->search, function ($q) use ($request) {
                $q->where(function ($inner) use ($request) {
                    $inner->where('invoice_number', 'like', "%{$request->search}%")
                          ->orWhereHas('customer', fn($c) => 
                              $c->where('name', 'like', "%{$request->search}%")
                               ->orWhere('phone', 'like', "%{$request->search}%")
                          );
                });
            })
            ->when($request->date_from, fn($q) => $q->whereDate('invoice_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('invoice_date', '<=', $request->date_to))
            ->latest('invoice_date')
            ->paginate($request->per_page ?? 20);

        return response()->json($query);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'customer_id'    => 'required|exists:customers,id',
            'type'           => 'in:invoice,quotation',
            'invoice_date'   => 'required|date',
            'due_date'       => 'nullable|date',
            'discount'       => 'numeric|min:0',
            'notes'          => 'nullable|string',
            'terms'          => 'nullable|string',
            'items'          => 'required|array|min:1',
            'items.*.product_id'   => 'nullable|exists:products,id',
            'items.*.description'  => 'required|string',
            'items.*.quantity'     => 'required|integer|min:1',
            'items.*.unit_price'   => 'required|numeric|min:0',
        ]);

        DB::beginTransaction();
        try {
            $subtotal = collect($validated['items'])->sum(fn($i) => $i['quantity'] * $i['unit_price']);
            $discount = $validated['discount'] ?? 0;
            $total    = $subtotal - $discount;

            $invoice = Invoice::create([
                'invoice_number' => $this->generateNumber($validated['type'] ?? 'invoice'),
                'customer_id'    => $validated['customer_id'],
                'user_id'        => auth()->id(),
                'type'           => $validated['type'] ?? 'invoice',
                'status'         => 'draft',
                'invoice_date'   => $validated['invoice_date'],
                'due_date'       => $validated['due_date'] ?? null,
                'subtotal'       => $subtotal,
                'discount'       => $discount,
                'total'          => $total,
                'balance_due'    => $total,
                'notes'          => $validated['notes'] ?? null,
                'terms'          => $validated['terms'] ?? setting('invoice_terms'),
            ]);

            foreach ($validated['items'] as $item) {
                $invoice->items()->create([
                    'product_id'  => $item['product_id'] ?? null,
                    'description' => $item['description'],
                    'sku'         => isset($item['product_id']) ? Product::find($item['product_id'])?->sku : null,
                    'quantity'    => $item['quantity'],
                    'unit_price'  => $item['unit_price'],
                    'total'       => $item['quantity'] * $item['unit_price'],
                ]);

                // Deduct stock when invoice (not quotation) is created
                if (($validated['type'] ?? 'invoice') === 'invoice' && isset($item['product_id'])) {
                    $this->stockService->deduct(
                        $item['product_id'],
                        $item['quantity'],
                        'sale',
                        $invoice->invoice_number
                    );
                }
            }

            DB::commit();
            return response()->json($invoice->load(['customer', 'items.product']), 201);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    public function show(Invoice $invoice): JsonResponse
    {
        return response()->json(
            $invoice->load(['customer', 'user', 'items.product', 'payments.user'])
        );
    }

    public function update(Request $request, Invoice $invoice): JsonResponse
    {
        $invoice->update($request->only(['status', 'due_date', 'notes', 'terms', 'discount']));
        $invoice->refresh();
        return response()->json($invoice->load(['customer', 'items']));
    }

    public function destroy(Invoice $invoice): JsonResponse
    {
        if ($invoice->status === 'paid') {
            return response()->json(['message' => 'Cannot delete a paid invoice.'], 422);
        }
        $invoice->delete();
        return response()->json(['message' => 'Deleted']);
    }

    // Generate PDF invoice
    public function pdf(Invoice $invoice)
    {
        $invoice->load(['customer', 'items.product', 'payments']);
        $settings = \App\Models\Setting::pluck('value', 'key');

        $pdf = Pdf::loadView('invoices.pdf', compact('invoice', 'settings'))
                  ->setPaper('a4', 'portrait');

        return $pdf->download("TinyCubs-{$invoice->invoice_number}.pdf");
    }

    // Convert quotation → invoice
    public function convertToInvoice(Invoice $invoice): JsonResponse
    {
        if ($invoice->type !== 'quotation') {
            return response()->json(['message' => 'Only quotations can be converted.'], 422);
        }
        $invoice->update([
            'type'           => 'invoice',
            'invoice_number' => $this->generateNumber('invoice'),
            'invoice_date'   => now()->toDateString(),
        ]);

        // Deduct stock now
        foreach ($invoice->items as $item) {
            if ($item->product_id) {
                $this->stockService->deduct($item->product_id, $item->quantity, 'sale', $invoice->invoice_number);
            }
        }

        return response()->json($invoice->fresh(['customer', 'items']));
    }

    private function generateNumber(string $type): string
    {
        $prefix = $type === 'quotation' ? 'QT' : (setting('invoice_prefix') ?? 'INV');
        $year   = now()->format('Y');
        $last   = Invoice::where('type', $type)
                         ->whereYear('created_at', $year)
                         ->max(DB::raw("CAST(SUBSTRING_INDEX(invoice_number, '-', -1) AS UNSIGNED)"));
        return "{$prefix}-{$year}-" . str_pad(($last ?? 0) + 1, 4, '0', STR_PAD_LEFT);
    }
}
