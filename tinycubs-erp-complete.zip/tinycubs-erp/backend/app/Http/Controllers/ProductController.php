<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Services\WooCommerceService;
use App\Services\StockService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    public function __construct(
        private WooCommerceService $wc,
        private StockService $stock
    ) {}

    public function index(Request $request): JsonResponse
    {
        $query = Product::with('category')
            ->when($request->category_id, fn($q) => $q->where('category_id', $request->category_id))
            ->when($request->size,         fn($q) => $q->where('size', $request->size))
            ->when($request->color,        fn($q) => $q->where('color', $request->color))
            ->when($request->search, fn($q) =>
                $q->where(fn($i) =>
                    $i->where('name', 'like', "%{$request->search}%")
                      ->orWhere('sku', 'like', "%{$request->search}%")
                      ->orWhere('barcode', 'like', "%{$request->search}%")
                )
            )
            ->when($request->low_stock, fn($q) =>
                $q->whereColumn('stock_qty', '<=', 'low_stock_threshold')
            )
            ->when($request->is_active !== null, fn($q) =>
                $q->where('is_active', filter_var($request->is_active, FILTER_VALIDATE_BOOLEAN))
            )
            ->orderBy('name');

        return response()->json(
            $request->paginate === 'false'
                ? $query->get()
                : $query->paginate($request->per_page ?? 25)
        );
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'category_id'        => 'required|exists:categories,id',
            'name'               => 'required|string|max:255',
            'size'               => 'required|string|max:20',
            'color'              => 'required|string|max:50',
            'color_hex'          => 'nullable|string|max:7',
            'cost_price'         => 'required|numeric|min:0',
            'selling_price'      => 'required|numeric|min:0',
            'initial_stock'      => 'nullable|integer|min:0',
            'low_stock_threshold'=> 'nullable|integer|min:1',
            'sync_to_woocommerce'=> 'boolean',
            'notes'              => 'nullable|string',
        ]);

        // Auto-generate SKU: TC-{CAT}-{COLOR}-{SIZE}
        $validated['sku']     = $this->generateSku($validated);
        $validated['barcode'] = $validated['sku'];
        $initialStock = $validated['initial_stock'] ?? 0;
        unset($validated['initial_stock']);

        $product = Product::create($validated);

        // Record initial stock movement
        if ($initialStock > 0) {
            $this->stock->add($product->id, $initialStock, 'in', 'Initial stock');
        }

        // Sync to WooCommerce
        if ($product->sync_to_woocommerce && setting('wc_sync_enabled') === '1') {
            dispatch(fn() => $this->wc->pushProduct($product))->afterResponse();
        }

        return response()->json($product->load('category'), 201);
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json($product->load('category'));
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'name'               => 'string|max:255',
            'selling_price'      => 'numeric|min:0',
            'cost_price'         => 'numeric|min:0',
            'low_stock_threshold'=> 'integer|min:1',
            'sync_to_woocommerce'=> 'boolean',
            'sync_to_facebook'   => 'boolean',
            'is_active'          => 'boolean',
            'notes'              => 'nullable|string',
        ]);

        $product->update($validated);

        if ($product->sync_to_woocommerce && setting('wc_sync_enabled') === '1') {
            dispatch(fn() => $this->wc->pushProduct($product->fresh()))->afterResponse();
        }

        return response()->json($product->fresh('category'));
    }

    public function destroy(Product $product): JsonResponse
    {
        if ($product->stock_qty > 0) {
            return response()->json([
                'message' => "Cannot delete — product still has {$product->stock_qty} units in stock."
            ], 422);
        }
        $product->delete();
        return response()->json(['message' => 'Product deleted.']);
    }

    public function findByBarcode(string $barcode): JsonResponse
    {
        $product = Product::where('barcode', $barcode)
                          ->orWhere('sku', $barcode)
                          ->with('category')
                          ->firstOrFail();

        return response()->json($product);
    }

    public function lowStock(): JsonResponse
    {
        $products = Product::where('is_active', true)
            ->where(fn($q) => $q->whereColumn('stock_qty', '<=', 'low_stock_threshold'))
            ->with('category')
            ->orderBy('stock_qty')
            ->get();

        return response()->json($products);
    }

    private function generateSku(array $data): string
    {
        // Map category names to codes
        $catCode = match (true) {
            str_contains(strtolower(\App\Models\Category::find($data['category_id'])?->slug ?? ''), 't-shirt') => 'TSH',
            str_contains(strtolower(\App\Models\Category::find($data['category_id'])?->slug ?? ''), 'romper')  => 'RMP',
            str_contains(strtolower(\App\Models\Category::find($data['category_id'])?->slug ?? ''), 'kid')     => 'KID',
            str_contains(strtolower(\App\Models\Category::find($data['category_id'])?->slug ?? ''), 'baby')    => 'BAB',
            default => 'ITM',
        };

        $colorCode = strtoupper(substr(preg_replace('/\s+/', '', $data['color']), 0, 3));
        $sizeCode  = strtoupper(str_replace([' ', '-'], '', $data['size']));

        $base = "TC-{$catCode}-{$colorCode}-{$sizeCode}";

        // Ensure uniqueness by appending number if needed
        $count = Product::where('sku', 'like', "{$base}%")->count();
        return $count > 0 ? "{$base}-" . ($count + 1) : $base;
    }
}
