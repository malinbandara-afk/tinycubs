<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Expense;
use App\Models\Product;
use App\Models\Payment;
use App\Models\JobOrder;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    // ─── Sales Report ─────────────────────────────────────────
    public function sales(Request $request)
    {
        $from = $request->date_from ?? now()->startOfMonth()->toDateString();
        $to   = $request->date_to   ?? now()->toDateString();

        $invoices = Invoice::with(['customer', 'items'])
            ->where('type', 'invoice')
            ->whereBetween('invoice_date', [$from, $to])
            ->whereNotIn('status', ['cancelled', 'draft'])
            ->latest('invoice_date')
            ->get();

        $data = [
            'period'            => compact('from', 'to'),
            'total_invoices'    => $invoices->count(),
            'total_revenue'     => $invoices->sum('total'),
            'total_collected'   => $invoices->sum('amount_paid'),
            'total_outstanding' => $invoices->sum('balance_due'),
            'by_status'         => $invoices->groupBy('status')->map->count(),
            'by_source'         => $invoices->groupBy('source')->map->sum('total'),
            'daily_breakdown'   => $invoices->groupBy(fn($i) => $i->invoice_date->format('Y-m-d'))
                                            ->map->sum('total'),
            'invoices'          => $invoices,
        ];

        if ($request->format === 'pdf') {
            $pdf = Pdf::loadView('reports.sales', compact('data'))->setPaper('a4');
            return $pdf->download("Sales-Report-{$from}-to-{$to}.pdf");
        }

        return response()->json($data);
    }

    // ─── Profit & Loss ────────────────────────────────────────
    public function profitLoss(Request $request)
    {
        $from  = $request->date_from ?? now()->startOfMonth()->toDateString();
        $to    = $request->date_to   ?? now()->toDateString();

        $revenue = Invoice::where('type', 'invoice')
            ->where('status', 'paid')
            ->whereBetween('invoice_date', [$from, $to])
            ->sum('total');

        $expenses = Expense::whereBetween('expense_date', [$from, $to])
            ->select('category', DB::raw('SUM(amount) as total'))
            ->groupBy('category')
            ->pluck('total', 'category')
            ->toArray();

        $totalExpenses = array_sum($expenses);
        $netProfit     = $revenue - $totalExpenses;

        $data = [
            'period'         => compact('from', 'to'),
            'revenue'        => $revenue,
            'expenses'       => $expenses,
            'total_expenses' => $totalExpenses,
            'net_profit'     => $netProfit,
            'margin_pct'     => $revenue > 0 ? round(($netProfit / $revenue) * 100, 1) : 0,
        ];

        if ($request->format === 'pdf') {
            $pdf = Pdf::loadView('reports.profit-loss', compact('data'))->setPaper('a4');
            return $pdf->download("PL-Report-{$from}-to-{$to}.pdf");
        }

        return response()->json($data);
    }

    // ─── Outstanding Payments ─────────────────────────────────
    public function outstanding(Request $request)
    {
        $invoices = Invoice::with('customer')
            ->whereIn('status', ['sent', 'partial'])
            ->where('type', 'invoice')
            ->orderBy('invoice_date')
            ->get()
            ->map(fn($inv) => [
                'invoice_number' => $inv->invoice_number,
                'customer'       => $inv->customer->name,
                'phone'          => $inv->customer->phone,
                'invoice_date'   => $inv->invoice_date->format('d M Y'),
                'due_date'       => $inv->due_date?->format('d M Y'),
                'total'          => $inv->total,
                'amount_paid'    => $inv->amount_paid,
                'balance_due'    => $inv->balance_due,
                'status'         => $inv->status,
                'days_overdue'   => $inv->due_date ? max(0, now()->diffInDays($inv->due_date, false) * -1) : null,
            ]);

        $data = [
            'invoices'          => $invoices,
            'total_outstanding' => $invoices->sum('balance_due'),
            'count'             => $invoices->count(),
        ];

        if ($request->format === 'pdf') {
            $pdf = Pdf::loadView('reports.outstanding', compact('data'))->setPaper('a4');
            return $pdf->download('Outstanding-Payments.pdf');
        }

        return response()->json($data);
    }

    // ─── Inventory Report ─────────────────────────────────────
    public function inventory(Request $request)
    {
        $products = Product::with('category')
            ->where('is_active', true)
            ->get()
            ->map(fn($p) => [
                'sku'        => $p->sku,
                'name'       => $p->name,
                'category'   => $p->category->name,
                'size'       => $p->size,
                'color'      => $p->color,
                'stock_qty'  => $p->stock_qty,
                'cost_price' => $p->cost_price,
                'stock_value'=> $p->stock_qty * $p->cost_price,
                'status'     => $p->stock_qty <= 0 ? 'Out of Stock'
                             : ($p->stock_qty <= $p->low_stock_threshold ? 'Low Stock' : 'In Stock'),
            ]);

        $data = [
            'products'     => $products,
            'total_skus'   => $products->count(),
            'total_value'  => $products->sum('stock_value'),
            'low_stock'    => $products->where('status', 'Low Stock')->count(),
            'out_of_stock' => $products->where('status', 'Out of Stock')->count(),
        ];

        if ($request->format === 'pdf') {
            $pdf = Pdf::loadView('reports.inventory', compact('data'))->setPaper('a4', 'landscape');
            return $pdf->download('Inventory-Report.pdf');
        }

        return response()->json($data);
    }

    // ─── Production Report ────────────────────────────────────
    public function production(Request $request)
    {
        $from = $request->date_from ?? now()->startOfMonth()->toDateString();
        $to   = $request->date_to   ?? now()->toDateString();

        $jobs = JobOrder::with(['worker', 'items', 'materialUsage.material'])
            ->whereBetween('created_at', [$from, $to])
            ->latest()
            ->get();

        $data = [
            'period'     => compact('from', 'to'),
            'jobs'       => $jobs,
            'by_status'  => $jobs->groupBy('status')->map->count(),
            'by_worker'  => $jobs->groupBy('worker.name')->map->count(),
            'total_units'=> $jobs->sum('quantity'),
        ];

        if ($request->format === 'pdf') {
            $pdf = Pdf::loadView('reports.production', compact('data'))->setPaper('a4');
            return $pdf->download("Production-Report-{$from}-to-{$to}.pdf");
        }

        return response()->json($data);
    }
}
