<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Milon\Barcode\DNS1D;
use Barryvdh\DomPDF\Facade\Pdf;

class BarcodeController extends Controller
{
    private DNS1D $barcode;

    public function __construct()
    {
        $this->barcode = new DNS1D();
    }

    // Generate & assign barcode to product
    public function generate(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
        ]);

        $product = Product::findOrFail($request->product_id);

        if (!$product->barcode) {
            // Format: TC-{CATEGORY}-{SIZE}-{COLOR}
            $product->update(['barcode' => $product->sku]);
        }

        $png = $this->barcode->getBarcodePNG($product->barcode, 'C128', 2, 60);

        return response()->json([
            'barcode'  => $product->barcode,
            'image_b64'=> $png,
            'product'  => $product->only(['id', 'name', 'sku', 'size', 'color', 'selling_price']),
        ]);
    }

    // Print barcode label(s) as PDF
    public function print(Product $product)
    {
        $barcode = $this->barcode->getBarcodePNG($product->barcode ?? $product->sku, 'C128', 2, 60);
        $settings = \App\Models\Setting::pluck('value', 'key');

        $pdf = Pdf::loadView('barcodes.label', compact('product', 'barcode', 'settings'))
                  ->setPaper([0, 0, 170, 90], 'landscape'); // 60mm x 30mm label

        return $pdf->download("barcode-{$product->sku}.pdf");
    }

    // Scan barcode → return product info
    public function scan(string $code)
    {
        $product = Product::where('barcode', $code)
                          ->orWhere('sku', $code)
                          ->with('category')
                          ->first();

        if (!$product) {
            return response()->json(['message' => 'Product not found for barcode: ' . $code], 404);
        }

        return response()->json([
            'product'  => $product,
            'in_stock' => $product->stock_qty,
            'status'   => $product->stock_qty > $product->low_stock_threshold
                ? 'good' : ($product->stock_qty > 0 ? 'low' : 'out_of_stock'),
        ]);
    }
}
