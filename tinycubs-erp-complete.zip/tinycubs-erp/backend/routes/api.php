<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\JobOrderController;
use App\Http\Controllers\BarcodeController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\WooCommerceController;
use App\Http\Controllers\WhatsAppController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\StockController;

// ─── Public Routes ───────────────────────────────────────────
Route::post('/login', [AuthController::class, 'login']);
Route::post('/webhook/woocommerce', [WooCommerceController::class, 'webhook']);

// ─── Protected Routes (Sanctum) ──────────────────────────────
Route::middleware('auth:sanctum')->group(function () {

    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::get('/dashboard/chart', [DashboardController::class, 'salesChart']);

    // Customers
    Route::apiResource('customers', CustomerController::class);
    Route::get('/customers/{customer}/invoices', [CustomerController::class, 'invoices']);

    // Products & Inventory
    Route::apiResource('products', ProductController::class);
    Route::get('/products/search/barcode/{barcode}', [ProductController::class, 'findByBarcode']);
    Route::get('/products/low-stock', [ProductController::class, 'lowStock']);
    Route::post('/products/{product}/stock', [StockController::class, 'adjust']);
    Route::get('/products/{product}/movements', [StockController::class, 'movements']);

    // Categories
    Route::apiResource('categories', \App\Http\Controllers\CategoryController::class);

    // Invoices
    Route::apiResource('invoices', InvoiceController::class);
    Route::get('/invoices/{invoice}/pdf', [InvoiceController::class, 'pdf']);
    Route::post('/invoices/{invoice}/send-whatsapp', [WhatsAppController::class, 'sendInvoice']);
    Route::post('/invoices/{invoice}/convert', [InvoiceController::class, 'convertToInvoice']); // quotation → invoice

    // Payments
    Route::post('/invoices/{invoice}/payments', [PaymentController::class, 'store']);
    Route::get('/invoices/{invoice}/payments', [PaymentController::class, 'index']);
    Route::delete('/payments/{payment}', [PaymentController::class, 'destroy']);

    // Expenses
    Route::apiResource('expenses', ExpenseController::class);

    // Production / Job Orders
    Route::apiResource('job-orders', JobOrderController::class);
    Route::patch('/job-orders/{jobOrder}/status', [JobOrderController::class, 'updateStatus']);
    Route::patch('/job-orders/{jobOrder}/progress', [JobOrderController::class, 'updateProgress']);
    Route::post('/job-orders/{jobOrder}/materials', [JobOrderController::class, 'addMaterial']);

    // Workers & Materials
    Route::apiResource('workers', \App\Http\Controllers\WorkerController::class);
    Route::apiResource('materials', \App\Http\Controllers\MaterialController::class);

    // Barcodes
    Route::post('/barcodes/generate', [BarcodeController::class, 'generate']);
    Route::get('/barcodes/{product}/print', [BarcodeController::class, 'print']);
    Route::get('/barcodes/scan/{code}', [BarcodeController::class, 'scan']);

    // Reports (all return PDF or JSON)
    Route::get('/reports/sales', [ReportController::class, 'sales']);
    Route::get('/reports/inventory', [ReportController::class, 'inventory']);
    Route::get('/reports/profit-loss', [ReportController::class, 'profitLoss']);
    Route::get('/reports/outstanding', [ReportController::class, 'outstanding']);
    Route::get('/reports/production', [ReportController::class, 'production']);

    // WooCommerce Sync
    Route::prefix('woocommerce')->group(function () {
        Route::get('/status', [WooCommerceController::class, 'status']);
        Route::post('/sync/products', [WooCommerceController::class, 'syncProducts']);
        Route::post('/sync/orders', [WooCommerceController::class, 'syncOrders']);
        Route::post('/sync/stock/{product}', [WooCommerceController::class, 'syncStock']);
    });

    // Users & Roles (admin only)
    Route::middleware('role:admin')->group(function () {
        Route::apiResource('users', UserController::class);
        Route::patch('/users/{user}/toggle', [UserController::class, 'toggle']);
        Route::get('/settings', [SettingsController::class, 'index']);
        Route::put('/settings', [SettingsController::class, 'update']);
    });
});
