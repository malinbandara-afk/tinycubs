// ============================================================
// Barcode.jsx
// ============================================================
import React, { useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { productsApi, barcodesApi, downloadBlob } from '../services/api';
import toast from 'react-hot-toast';

export function Barcode() {
  const [productId, setProductId] = useState('');
  const [scanned,   setScanned]   = useState(null);
  const [scanCode,  setScanCode]  = useState('');
  const [scanMode,  setScanMode]  = useState('sales');
  const scanRef = useRef();

  const { data: pData } = useQuery({ queryKey:['products-list'], queryFn:()=>productsApi.list({paginate:'false'}).then(r=>r.data) });
  const products = Array.isArray(pData)?pData:pData?.data??[];

  const selectedProduct = products.find(p=>p.id==productId);

  const handleScan = async (e) => {
    if (e.key === 'Enter' && scanCode) {
      try {
        const res = await barcodesApi.scan(scanCode);
        setScanned(res.data);
        toast.success(`Found: ${res.data.product.name}`);
      } catch { toast.error('Product not found for barcode: ' + scanCode); }
    }
  };

  const genBars = (code='TC-SKU') => {
    const seed = code.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
    return Array.from({length:32},(_,i)=>({ w:[1,2,3,1,2,1,2,3][( seed+i*7)%8], h:i%5===0?44:36 }));
  };

  const bars = genBars(selectedProduct?.sku||'TC-EXAMPLE');

  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:600,margin:0,letterSpacing:-0.5}}>Barcode Management</h1>
          <p style={{fontSize:12,color:'#8888aa',margin:'4px 0 0'}}>Generate, print & scan barcodes</p>
        </div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        {/* Generator */}
        <div style={crd}>
          <div style={hdr}>Generate Barcode Label</div>
          <div style={{padding:16}}>
            <div style={fg}>
              <label style={lbl}>Select Product</label>
              <select value={productId} onChange={e=>setProductId(e.target.value)} style={sel}>
                <option value="">— Choose product —</option>
                {products.map(p=><option key={p.id} value={p.id}>{p.name} — {p.size}/{p.color} (SKU: {p.sku})</option>)}
              </select>
            </div>
            {selectedProduct && (
              <>
                <div style={{background:'white',borderRadius:10,padding:'16px 20px',textAlign:'center',margin:'16px 0'}}>
                  <div style={{fontSize:11,color:'#1a1a2e',marginBottom:8,fontWeight:600}}>{selectedProduct.name}</div>
                  <div style={{display:'flex',gap:1,height:50,alignItems:'flex-end',justifyContent:'center',marginBottom:6}}>
                    {bars.map((b,i)=><div key={i} style={{width:b.w,background:'#1a1a2e',borderRadius:1,height:b.h}} />)}
                  </div>
                  <div style={{fontFamily:'monospace',fontSize:9,color:'#1a1a2e',letterSpacing:3}}>{selectedProduct.sku}</div>
                  <div style={{fontSize:9,color:'#666',marginTop:4}}>{selectedProduct.size} / {selectedProduct.color} · Rs {parseFloat(selectedProduct.selling_price).toLocaleString()}</div>
                </div>
                <div style={{display:'flex',gap:8}}>
                  <button onClick={async()=>{
                    try{const res=await barcodesApi.print(selectedProduct.id);downloadBlob(res,`barcode-${selectedProduct.sku}.pdf`);toast.success('Barcode PDF downloaded!');}catch{toast.error('Print failed');}
                  }} style={{...btnPri,flex:1}}>🖨 Print Label (PDF)</button>
                </div>
              </>
            )}
          </div>
        </div>
        {/* Scanner */}
        <div style={crd}>
          <div style={{...hdr,justifyContent:'space-between'}}>
            Scanner Mode
            <span style={{fontSize:11,background:'rgba(0,212,170,0.15)',color:'#00d4aa',padding:'2px 10px',borderRadius:10}}>Ready</span>
          </div>
          <div style={{padding:16}}>
            <div style={{border:'2px dashed rgba(255,255,255,0.1)',borderRadius:10,padding:24,textAlign:'center',marginBottom:16,cursor:'pointer'}} onClick={()=>scanRef.current?.focus()}>
              <div style={{fontSize:40,marginBottom:8}}>📷</div>
              <div style={{fontSize:13,fontWeight:500}}>Point scanner at barcode</div>
              <div style={{fontSize:11,color:'#8888aa',marginTop:4}}>or type code below and press Enter</div>
            </div>
            <input ref={scanRef} value={scanCode} onChange={e=>setScanCode(e.target.value)} onKeyDown={handleScan}
              placeholder="Scan or type barcode / SKU..." style={{...inp,textAlign:'center',marginBottom:14}} autoFocus />
            <div style={{marginBottom:14}}>
              <div style={{fontSize:11,fontWeight:500,marginBottom:8}}>Scan Mode</div>
              {['sales','stock_update','inventory_check'].map(m=>(
                <label key={m} style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer',fontSize:12,padding:'5px 0',color:scanMode===m?'#e94560':'#8888aa'}}>
                  <input type="radio" name="scanMode" checked={scanMode===m} onChange={()=>setScanMode(m)} style={{accentColor:'#e94560'}} />
                  {m.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase())}
                </label>
              ))}
            </div>
            {scanned && (
              <div style={{background:'rgba(84,160,255,0.08)',border:'1px solid rgba(84,160,255,0.2)',borderRadius:8,padding:12}}>
                <div style={{fontSize:10,color:'#8888aa',marginBottom:4,textTransform:'uppercase',letterSpacing:0.5}}>Last Scan Result</div>
                <div style={{fontFamily:'monospace',fontSize:13,marginBottom:2}}>{scanned.product.sku}</div>
                <div style={{fontSize:12}}>{scanned.product.name} — {scanned.product.size}/{scanned.product.color}</div>
                <div style={{fontSize:12,marginTop:4}}>
                  Stock: <strong style={{color:scanned.status==='good'?'#00d4aa':scanned.status==='low'?'#ffb347':'#ff4757'}}>{scanned.in_stock} units</strong>
                  &nbsp;·&nbsp; Price: Rs {parseFloat(scanned.product.selling_price).toLocaleString()}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Customers.jsx
// ============================================================
import { customersApi } from '../services/api';
import { useNavigate } from 'react-router-dom';

export function Customers() {
  const navigate  = useNavigate();
  const [search, setSearch] = useState('');
  const [page,   setPage]   = useState(1);
  const [modal,  setModal]  = useState(false);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey:['customers',search,page],
    queryFn:()=>customersApi.list({search,page,per_page:20}).then(r=>r.data),
  });
  const [form, setForm] = useState({name:'',phone:'',email:'',address:'',company:'',type:'retail'});
  const saveMut = useMutation({
    mutationFn:()=>customersApi.create(form),
    onSuccess:()=>{toast.success('Customer added!');qc.invalidateQueries({queryKey:['customers']});setModal(false);setForm({name:'',phone:'',email:'',address:'',company:'',type:'retail'});},
    onError:()=>toast.error('Failed to add customer'),
  });
  const customers = data?.data??[];
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:600,margin:0}}>Customers</h1>
          <p style={{fontSize:12,color:'#8888aa',margin:'4px 0 0'}}>{data?.total??0} total customers</p>
        </div>
        <button onClick={()=>setModal(true)} style={btnPri}>+ Add Customer</button>
      </div>
      <div style={{marginBottom:14}}>
        <input value={search} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Search name, phone, email..." style={{...inp,width:280}} />
      </div>
      <div style={crd}>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
            <thead><tr>{['Name','Phone','Email','Company','Type','Total Spent','Actions'].map(h=><th key={h} style={th}>{h}</th>)}</tr></thead>
            <tbody>
              {isLoading?<tr><td colSpan={7} style={{textAlign:'center',padding:28,color:'#8888aa'}}>Loading...</td></tr>
              :customers.length===0?<tr><td colSpan={7} style={{textAlign:'center',padding:28,color:'#8888aa'}}>No customers found</td></tr>
              :customers.map(c=>(
                <tr key={c.id}>
                  <td style={td}><div style={{fontWeight:500}}>{c.name}</div></td>
                  <td style={td}>{c.phone||'—'}</td>
                  <td style={td}>{c.email||'—'}</td>
                  <td style={td}>{c.company||'—'}</td>
                  <td style={td}><span style={{fontSize:10,background:'rgba(84,160,255,0.12)',color:'#54a0ff',padding:'2px 8px',borderRadius:10}}>{c.type}</span></td>
                  <td style={{...td,color:'#00d4aa',fontWeight:500}}>Rs {parseFloat(c.total_purchases||0).toLocaleString()}</td>
                  <td style={td}><button onClick={()=>navigate(`/sales?customer=${c.id}`)} style={btnSm}>View Orders</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {data?.last_page>1&&<div style={{padding:'12px 16px',borderTop:'1px solid rgba(255,255,255,0.06)',display:'flex',gap:8}}>
          <button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={page===1} style={btnSm}>← Prev</button>
          <span style={{fontSize:12,color:'#8888aa',alignSelf:'center'}}>Page {page} of {data.last_page}</span>
          <button onClick={()=>setPage(p=>p+1)} disabled={page===data.last_page} style={btnSm}>Next →</button>
        </div>}
      </div>
      {modal&&<div style={overlay}><div style={{...modalS,width:420}}>
        <h3 style={{margin:'0 0 16px',fontSize:15}}>Add Customer</h3>
        {[['name','Full Name *','text'],['phone','Phone','text'],['email','Email','email'],['company','Company','text'],['address','Address','text']].map(([k,l,t])=>(
          <div key={k} style={fg}><label style={lbl}>{l}</label><input type={t} value={form[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))} style={inp} required={k==='name'} /></div>
        ))}
        <div style={fg}><label style={lbl}>Type</label>
          <select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))} style={sel}>
            {['retail','wholesale','online'].map(t=><option key={t} value={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>)}
          </select>
        </div>
        <div style={{display:'flex',gap:8,marginTop:8}}>
          <button onClick={()=>setModal(false)} style={btnSec}>Cancel</button>
          <button onClick={()=>saveMut.mutate()} disabled={!form.name||saveMut.isPending} style={btnPri}>{saveMut.isPending?'Saving...':'Add Customer'}</button>
        </div>
      </div></div>}
    </div>
  );
}

// ============================================================
// Integrations.jsx
// ============================================================
import { wooApi } from '../services/api';

export function Integrations() {
  const [syncing, setSyncing] = useState('');
  const sync = async (key, fn, label) => {
    setSyncing(key);
    try { const r=await fn(); toast.success(`${label}: ${JSON.stringify(r.data)}`); }
    catch { toast.error(`${label} failed`); }
    finally { setSyncing(''); }
  };
  const integrations = [
    { icon:'🌐', name:'tinycubs.lk WordPress', sub:'Website connection', status:'connected', color:'#00d4aa' },
    { icon:'🛒', name:'WooCommerce Orders',     sub:'Auto-import orders → ERP', status:'connected', color:'#00d4aa' },
    { icon:'📦', name:'Stock Sync',             sub:'ERP stock → WooCommerce live', status:'connected', color:'#00d4aa' },
    { icon:'📘', name:'Facebook Page',          sub:'TinyCubs.lk Official', status:'connected', color:'#00d4aa' },
    { icon:'🛍', name:'Facebook Shop',          sub:'Product catalog sync', status:'pending', color:'#ffb347' },
    { icon:'💬', name:'WhatsApp Business',      sub:'Send invoices via WhatsApp', status:'connected', color:'#00d4aa' },
  ];
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:600,margin:0}}>Integrations</h1>
          <p style={{fontSize:12,color:'#8888aa',margin:'4px 0 0'}}>Website, WooCommerce & social media connections</p>
        </div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:20}}>
        {integrations.map(i=>(
          <div key={i.name} style={{background:'#1a1a2e',border:'1px solid rgba(255,255,255,0.07)',borderRadius:10,padding:16,display:'flex',alignItems:'center',gap:14}}>
            <span style={{fontSize:28}}>{i.icon}</span>
            <div style={{flex:1}}>
              <div style={{fontSize:13,fontWeight:500}}>{i.name}</div>
              <div style={{fontSize:11,color:'#8888aa',marginTop:2}}>{i.sub}</div>
              <div style={{fontSize:10,marginTop:4,color:i.color}}>● {i.status==='connected'?'Connected':'Needs setup'}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={crd}>
        <div style={hdr}>WooCommerce Actions</div>
        <div style={{padding:16,display:'flex',gap:10,flexWrap:'wrap'}}>
          <button onClick={()=>sync('orders',()=>wooApi.syncOrders(),'Sync Orders')} disabled={syncing==='orders'} style={btnPri}>
            {syncing==='orders'?'Syncing...':'⬇ Pull Orders from WooCommerce'}
          </button>
          <button onClick={()=>sync('products',()=>wooApi.syncProducts(),'Sync Products')} disabled={syncing==='products'} style={btnSec}>
            {syncing==='products'?'Syncing...':'⬆ Push Products to WooCommerce'}
          </button>
          <button onClick={()=>sync('status',()=>wooApi.status(),'Connection')} disabled={syncing==='status'} style={btnSec}>
            🔌 Test Connection
          </button>
        </div>
        <div style={{padding:'0 16px 16px'}}>
          <div style={{fontSize:11,color:'#8888aa'}}>Configure credentials in <code style={{background:'rgba(255,255,255,0.08)',padding:'1px 6px',borderRadius:4}}>.env</code> → WC_CONSUMER_KEY, WC_CONSUMER_SECRET, WC_BASE_URL</div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Users.jsx
// ============================================================
import { settingsApi } from '../services/api';
import api from '../services/api';

export function Users() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey:['users'], queryFn:()=>api.get('/users').then(r=>r.data) });
  const users = Array.isArray(data)?data:data?.data??[];
  const ROLES = { admin:'#e94560', sales:'#54a0ff', accounts:'#00d4aa', operations:'#ffb347' };
  const PERMS = {
    admin:      ['Dashboard','Sales','Inventory','Production','Accounting','Reports','Integrations','Users'],
    sales:      ['Dashboard','Sales','Customers'],
    accounts:   ['Dashboard','Accounting','Reports'],
    operations: ['Dashboard','Inventory','Production'],
  };
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:600,margin:0}}>Users & Roles</h1>
          <p style={{fontSize:12,color:'#8888aa',margin:'4px 0 0'}}>Access control for TinyCubs ERP</p>
        </div>
        <button onClick={()=>toast('Invite by creating user in backend seeder or admin panel.')} style={btnSec}>+ Invite User</button>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        <div style={crd}>
          <div style={hdr}>Team Members</div>
          <div style={{overflowX:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
              <thead><tr>{['User','Role','Status'].map(h=><th key={h} style={th}>{h}</th>)}</tr></thead>
              <tbody>
                {users.map(u=>(
                  <tr key={u.id}>
                    <td style={td}>
                      <div style={{display:'flex',alignItems:'center',gap:8}}>
                        <div style={{width:28,height:28,borderRadius:'50%',background:`${ROLES[u.role]||'#888'}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:600,color:ROLES[u.role]||'#888'}}>
                          {u.name.charAt(0)}
                        </div>
                        <div>
                          <div style={{fontSize:12}}>{u.name}</div>
                          <div style={{fontSize:10,color:'#8888aa'}}>{u.email}</div>
                        </div>
                      </div>
                    </td>
                    <td style={td}>
                      <span style={{padding:'2px 10px',borderRadius:20,fontSize:10,fontWeight:600,background:`${ROLES[u.role]||'#888'}22`,color:ROLES[u.role]||'#888'}}>
                        {u.role.charAt(0).toUpperCase()+u.role.slice(1)}
                      </span>
                    </td>
                    <td style={td}>
                      <span style={{fontSize:10,color:u.is_active?'#00d4aa':'#555',background:u.is_active?'rgba(0,212,170,0.1)':'rgba(255,255,255,0.05)',padding:'2px 8px',borderRadius:10}}>
                        {u.is_active?'Active':'Inactive'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div style={crd}>
          <div style={hdr}>Role Permissions</div>
          <div style={{overflowX:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
              <thead><tr><th style={th}>Module</th>{['Admin','Sales','Accounts','Ops'].map(r=><th key={r} style={{...th,textAlign:'center'}}>{r}</th>)}</tr></thead>
              <tbody>
                {['Dashboard','Sales','Customers','Inventory','Production','Accounting','Reports','Integrations','Users'].map(mod=>(
                  <tr key={mod}>
                    <td style={td}>{mod}</td>
                    {['admin','sales','accounts','operations'].map(role=>(
                      <td key={role} style={{...td,textAlign:'center'}}>
                        {PERMS[role].includes(mod) ? <span style={{color:'#00d4aa',fontSize:14}}>✓</span> : <span style={{color:'#333'}}>—</span>}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Dashboard.jsx  (live data version)
// ============================================================
import { dashboardApi } from '../services/api';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer } from 'recharts';

export function Dashboard() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({ queryKey:['dashboard'], queryFn:()=>dashboardApi.get().then(r=>r.data), refetchInterval:60000 });
  const { data: chart }     = useQuery({ queryKey:['chart'], queryFn:()=>dashboardApi.chart('monthly').then(r=>r.data) });

  const d = data || {};
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:600,margin:0,letterSpacing:-0.5}}>Dashboard</h1>
          <p style={{fontSize:12,color:'#8888aa',margin:'4px 0 0'}}>{new Date().toLocaleDateString('en-GB',{weekday:'long',year:'numeric',month:'long',day:'numeric'})} · TinyCubs.lk ERP</p>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button onClick={()=>navigate('/sales/new')} style={btnPri}>+ New Invoice</button>
        </div>
      </div>
      {/* Quick Actions */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:20}}>
        {[
          {icon:'🧾',label:'New Invoice',  path:'/sales/new'},
          {icon:'📦',label:'Add Stock',    path:'/inventory'},
          {icon:'🏭',label:'Job Order',    path:'/production/new'},
          {icon:'📊',label:'Reports',      path:'/reports'},
        ].map(a=>(
          <div key={a.label} onClick={()=>navigate(a.path)} style={{background:'#16213e',border:'1px solid rgba(255,255,255,0.08)',borderRadius:10,padding:'14px 10px',cursor:'pointer',textAlign:'center',transition:'border-color 0.15s'}}>
            <div style={{fontSize:22,marginBottom:6}}>{a.icon}</div>
            <div style={{fontSize:11,color:'#8888aa'}}>{a.label}</div>
          </div>
        ))}
      </div>
      {/* Stats */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14,marginBottom:20}}>
        {[
          {label:"Today's Revenue",  val:`Rs ${Math.round(d.today?.revenue||0).toLocaleString()}`,    color:'#e94560', border:'#e94560'},
          {label:'Orders Today',     val:d.today?.orders||0,                                          color:'#54a0ff', border:'#54a0ff'},
          {label:'Outstanding',      val:`Rs ${Math.round(d.outstanding||0).toLocaleString()}`,       color:'#ffb347', border:'#ffb347'},
          {label:'Cash in Hand',     val:`Rs ${Math.round(d.cash_in_hand||0).toLocaleString()}`,      color:'#00d4aa', border:'#00d4aa'},
        ].map(s=>(
          <div key={s.label} style={{background:'#16213e',border:'1px solid rgba(255,255,255,0.08)',borderTop:`3px solid ${s.border}`,borderRadius:12,padding:16}}>
            <div style={{fontSize:10,color:'#8888aa',marginBottom:6,textTransform:'uppercase',letterSpacing:0.5}}>{s.label}</div>
            <div style={{fontSize:22,fontWeight:700,color:s.color}}>{isLoading?'..':s.val}</div>
          </div>
        ))}
      </div>
      {/* Chart + Activity */}
      <div style={{display:'grid',gridTemplateColumns:'1.8fr 1fr',gap:16,marginBottom:16}}>
        <div style={crd}>
          <div style={hdr}>Monthly Revenue</div>
          <div style={{padding:16,height:200}}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart||[]} margin={{top:0,right:0,bottom:0,left:0}}>
                <XAxis dataKey="period" tick={{fill:'#555566',fontSize:10}} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{background:'#16213e',border:'1px solid rgba(255,255,255,0.1)',borderRadius:8,fontSize:12}} formatter={v=>`Rs ${Math.round(v).toLocaleString()}`} />
                <Bar dataKey="revenue" fill="#e94560" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div style={crd}>
          <div style={hdr}>Recent Activity</div>
          {(d.recent_invoices||[]).map(inv=>(
            <div key={inv.id} style={{display:'flex',gap:10,padding:'10px 16px',borderBottom:'1px solid rgba(255,255,255,0.04)',alignItems:'center'}}>
              <div style={{width:28,height:28,borderRadius:'50%',background:inv.status==='paid'?'rgba(0,212,170,0.2)':'rgba(255,179,71,0.2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,color:inv.status==='paid'?'#00d4aa':'#ffb347',flexShrink:0}}>
                {inv.status==='paid'?'✓':'⏳'}
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:12}}>Invoice #{inv.invoice_number}</div>
                <div style={{fontSize:10,color:'#8888aa'}}>{inv.customer?.name} · Rs {parseFloat(inv.total).toLocaleString()}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Low Stock + Production */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        <div style={crd}>
          <div style={{...hdr,color:'#ffb347'}}>⚠ Low Stock Alerts</div>
          {(d.low_stock||[]).map(p=>(
            <div key={p.id} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 16px',borderBottom:'1px solid rgba(255,255,255,0.04)'}}>
              <div style={{width:8,height:8,borderRadius:'50%',background:p.stock_qty<=3?'#ff4757':'#ffb347',flexShrink:0}} />
              <div style={{flex:1,fontSize:12}}>{p.name} ({p.size}/{p.color})</div>
              <span style={{fontSize:11,fontWeight:600,color:p.stock_qty<=3?'#ff4757':'#ffb347'}}>{p.stock_qty} left</span>
            </div>
          ))}
          {(!d.low_stock||d.low_stock.length===0) && <div style={{padding:16,fontSize:12,color:'#8888aa'}}>All stock levels healthy ✓</div>}
        </div>
        <div style={crd}>
          <div style={hdr}>Production Pipeline</div>
          <div style={{padding:16}}>
            {[
              {label:'Pending',     val:d.production?.pending||0,     color:'#ffb347'},
              {label:'In Progress', val:d.production?.in_progress||0, color:'#54a0ff'},
              {label:'Completed',   val:d.production?.completed||0,   color:'#00d4aa'},
            ].map(s=>(
              <div key={s.label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:'1px solid rgba(255,255,255,0.05)'}}>
                <span style={{fontSize:12}}>{s.label}</span>
                <span style={{fontSize:18,fontWeight:700,color:s.color}}>{s.val}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Shared styles used across all components above
const crd     = { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, overflow:'hidden' };
const hdr     = { padding:'12px 16px', borderBottom:'1px solid rgba(255,255,255,0.06)', fontSize:13, fontWeight:500, display:'flex', alignItems:'center', justifyContent:'space-between' };
const fg      = { marginBottom:12 };
const lbl     = { display:'block', fontSize:11, color:'#8888aa', marginBottom:4, fontWeight:500 };
const inp     = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%', boxSizing:'border-box' };
const sel     = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%' };
const th      = { padding:'9px 12px', textAlign:'left', fontSize:10, fontWeight:600, textTransform:'uppercase', letterSpacing:'0.8px', color:'#555566', borderBottom:'1px solid rgba(255,255,255,0.06)' };
const td      = { padding:'10px 12px', borderBottom:'1px solid rgba(255,255,255,0.04)', verticalAlign:'middle', fontSize:12 };
const btnPri  = { padding:'8px 16px', borderRadius:7, border:'none', background:'#e94560', color:'white', fontSize:12, fontWeight:500, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSec  = { padding:'8px 14px', borderRadius:7, background:'rgba(255,255,255,0.07)', color:'#e8e8f0', border:'1px solid rgba(255,255,255,0.1)', fontSize:12, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSm   = { padding:'4px 10px', borderRadius:6, background:'transparent', color:'#8888aa', border:'1px solid rgba(255,255,255,0.1)', fontSize:11, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const overlay = { position:'fixed', inset:0, background:'rgba(0,0,0,0.75)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:200 };
const modalS  = { background:'#16213e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:12, padding:24 };
