import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { productsApi } from '../services/api';
import toast from 'react-hot-toast';

const SIZES  = ['XS','S','M','L','XL','XXL','2-3Y','4-5Y','6-7Y','8-9Y','0-3M','3-6M','6-12M','12-18M'];
const COLORS = ['White','Black','Blue','Red','Yellow','Green','Pink','Grey','Navy','Orange','Purple','Multicolor'];
const COLOR_HEX = { White:'#f5f5f5', Black:'#222', Blue:'#4a9eff', Red:'#e74c3c', Yellow:'#f1c40f', Green:'#2ecc71', Pink:'#fd79a8', Grey:'#95a5a6', Navy:'#2c3e50', Orange:'#e67e22', Purple:'#9b59b6', Multicolor:'#fd79a8' };

export default function ProductForm() {
  const { id }   = useParams();
  const navigate = useNavigate();
  const qc       = useQueryClient();
  const isEdit   = Boolean(id);

  const [form, setForm] = useState({
    category_id: '', name: '', size: 'M', color: 'White',
    color_hex: '#f5f5f5', cost_price: '', selling_price: '',
    initial_stock: '', low_stock_threshold: 10,
    sync_to_woocommerce: true, sync_to_facebook: false,
    notes: '',
  });
  const [skuPreview, setSkuPreview] = useState('TC-...');

  const { data: categoriesData } = useQuery({
    queryKey: ['categories'],
    queryFn: () => import('../services/api').then(m => m.default.get('/categories?paginate=false')).then(r => r.data),
  });

  const { data: product } = useQuery({
    queryKey: ['product', id],
    queryFn: () => productsApi.get(id).then(r => r.data),
    enabled: isEdit,
  });

  const categories = Array.isArray(categoriesData) ? categoriesData : categoriesData?.data ?? [];

  useEffect(() => {
    if (product) {
      setForm({
        category_id: product.category_id, name: product.name,
        size: product.size, color: product.color, color_hex: product.color_hex || '#f5f5f5',
        cost_price: product.cost_price, selling_price: product.selling_price,
        initial_stock: '', low_stock_threshold: product.low_stock_threshold,
        sync_to_woocommerce: product.sync_to_woocommerce,
        sync_to_facebook: product.sync_to_facebook, notes: product.notes || '',
      });
      setSkuPreview(product.sku);
    }
  }, [product]);

  // Auto-update color hex and SKU preview
  useEffect(() => {
    if (form.color) setForm(f => ({ ...f, color_hex: COLOR_HEX[f.color] || f.color_hex }));
  }, [form.color]);

  useEffect(() => {
    const cat = categories.find(c => c.id == form.category_id);
    if (cat && form.size && form.color) {
      const catCode = cat.slug.includes('t-shirt') ? 'TSH'
        : cat.slug.includes('romper') ? 'RMP'
        : cat.slug.includes('baby')   ? 'BAB'
        : cat.slug.includes('kid')    ? 'KID' : 'ITM';
      const col  = form.color.toUpperCase().slice(0, 3);
      const size = form.size.replace(/\s|-/g, '').toUpperCase();
      setSkuPreview(`TC-${catCode}-${col}-${size}`);
    }
  }, [form.category_id, form.size, form.color, categories]);

  const margin = form.selling_price && form.cost_price
    ? ((form.selling_price - form.cost_price) / form.selling_price * 100).toFixed(1)
    : 0;

  const saveMut = useMutation({
    mutationFn: () => isEdit ? productsApi.update(id, form) : productsApi.create(form),
    onSuccess: (res) => {
      toast.success(isEdit ? 'Product updated!' : 'Product created!');
      qc.invalidateQueries({ queryKey: ['products'] });
      navigate('/inventory');
    },
    onError: (e) => toast.error(e.response?.data?.message || 'Save failed'),
  });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:600, margin:0 }}>{isEdit ? 'Edit Product' : 'Add New Product'}</h1>
          <p style={{ fontSize:12, color:'#8888aa', margin:'4px 0 0' }}>
            SKU preview: <span style={{ fontFamily:'monospace', color:'#54a0ff' }}>{skuPreview}</span>
          </p>
        </div>
        <button onClick={() => navigate('/inventory')} style={btnSec}>← Back</button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:16 }}>
        {/* Left */}
        <div>
          {/* Basic Info */}
          <div style={{ ...crd, marginBottom:16 }}>
            <div style={hdr}>Product Details</div>
            <div style={{ padding:16 }}>
              <div style={fr}>
                <div style={fg}>
                  <label style={lbl}>Category *</label>
                  <select value={form.category_id} onChange={e=>set('category_id',e.target.value)} required style={sel}>
                    <option value="">— Select category —</option>
                    {categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div style={fg}>
                  <label style={lbl}>Product Name *</label>
                  <input value={form.name} onChange={e=>set('name',e.target.value)} required placeholder="e.g. Custom Print T-Shirt" style={inp} />
                </div>
              </div>
              <div style={fr}>
                <div style={fg}>
                  <label style={lbl}>Size *</label>
                  <select value={form.size} onChange={e=>set('size',e.target.value)} style={sel}>
                    {SIZES.map(s=><option key={s}>{s}</option>)}
                  </select>
                </div>
                <div style={fg}>
                  <label style={lbl}>Color *</label>
                  <select value={form.color} onChange={e=>set('color',e.target.value)} style={sel}>
                    {COLORS.map(c=><option key={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div style={fg}>
                <label style={lbl}>Notes</label>
                <textarea value={form.notes} onChange={e=>set('notes',e.target.value)} rows={2} placeholder="Optional details..." style={{ ...inp, resize:'vertical' }} />
              </div>
            </div>
          </div>

          {/* Pricing */}
          <div style={{ ...crd, marginBottom:16 }}>
            <div style={hdr}>Pricing</div>
            <div style={{ padding:16 }}>
              <div style={fr}>
                <div style={fg}>
                  <label style={lbl}>Cost Price (Rs) *</label>
                  <input type="number" value={form.cost_price} min={0} step={0.01} onChange={e=>set('cost_price',e.target.value)} required placeholder="0.00" style={inp} />
                </div>
                <div style={fg}>
                  <label style={lbl}>Selling Price (Rs) *</label>
                  <input type="number" value={form.selling_price} min={0} step={0.01} onChange={e=>set('selling_price',e.target.value)} required placeholder="0.00" style={inp} />
                </div>
              </div>
              {margin > 0 && (
                <div style={{ background:'rgba(0,212,170,0.08)', border:'1px solid rgba(0,212,170,0.2)', borderRadius:8, padding:'10px 14px', fontSize:12 }}>
                  <span style={{ color:'#8888aa' }}>Gross Margin: </span>
                  <strong style={{ color:'#00d4aa' }}>{margin}%</strong>
                  <span style={{ color:'#8888aa', marginLeft:16 }}>Profit per unit: </span>
                  <strong style={{ color:'#00d4aa' }}>Rs {(form.selling_price - form.cost_price).toLocaleString()}</strong>
                </div>
              )}
            </div>
          </div>

          {/* Stock */}
          <div style={crd}>
            <div style={hdr}>Stock Settings</div>
            <div style={{ padding:16 }}>
              <div style={fr}>
                {!isEdit && (
                  <div style={fg}>
                    <label style={lbl}>Initial Stock Qty</label>
                    <input type="number" value={form.initial_stock} min={0} onChange={e=>set('initial_stock',e.target.value)} placeholder="0" style={inp} />
                  </div>
                )}
                <div style={fg}>
                  <label style={lbl}>Low Stock Alert Threshold</label>
                  <input type="number" value={form.low_stock_threshold} min={1} onChange={e=>set('low_stock_threshold',e.target.value)} style={inp} />
                </div>
              </div>
              {isEdit && (
                <div style={{ fontSize:12, color:'#8888aa' }}>
                  Current stock: <strong style={{ color:'#54a0ff', fontSize:15 }}>{product?.stock_qty}</strong>
                  {' '}— use the <em>± Stock</em> button on the inventory list to add/remove.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right */}
        <div>
          {/* Color preview */}
          <div style={{ ...crd, marginBottom:16 }}>
            <div style={hdr}>Color Preview</div>
            <div style={{ padding:16, display:'flex', alignItems:'center', gap:16 }}>
              <div style={{ width:60, height:60, borderRadius:12, background:form.color_hex, border:'2px solid rgba(255,255,255,0.15)', flexShrink:0 }} />
              <div>
                <div style={{ fontSize:14, fontWeight:500 }}>{form.color}</div>
                <div style={{ fontSize:11, color:'#8888aa', fontFamily:'monospace', marginTop:2 }}>{form.color_hex}</div>
                <div style={{ marginTop:8 }}>
                  <label style={{ ...lbl, marginBottom:4 }}>Custom hex:</label>
                  <input value={form.color_hex} onChange={e=>set('color_hex',e.target.value)} style={{ ...inp, width:120 }} />
                </div>
              </div>
            </div>
          </div>

          {/* Sync */}
          <div style={{ ...crd, marginBottom:16 }}>
            <div style={hdr}>Integrations</div>
            <div style={{ padding:16 }}>
              {[
                { key:'sync_to_woocommerce', label:'Sync to WooCommerce', sub:'tinycubs.lk product catalog', icon:'🛒' },
                { key:'sync_to_facebook',    label:'Sync to Facebook Shop', sub:'Facebook product catalog',   icon:'📘' },
              ].map(({ key, label, sub, icon }) => (
                <div key={key} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 0', borderBottom:'1px solid rgba(255,255,255,0.06)' }}>
                  <span style={{ fontSize:20 }}>{icon}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:12, fontWeight:500 }}>{label}</div>
                    <div style={{ fontSize:11, color:'#8888aa' }}>{sub}</div>
                  </div>
                  <div
                    onClick={() => set(key, !form[key])}
                    style={{
                      width:38, height:20, borderRadius:10, position:'relative', cursor:'pointer',
                      background: form[key] ? '#00d4aa' : 'rgba(255,255,255,0.15)',
                      transition:'background 0.2s',
                    }}
                  >
                    <div style={{
                      position:'absolute', width:16, height:16, background:'white', borderRadius:'50%',
                      top:2, left: form[key] ? 20 : 2, transition:'left 0.2s',
                    }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SKU preview card */}
          <div style={crd}>
            <div style={hdr}>Barcode Preview</div>
            <div style={{ padding:16, textAlign:'center' }}>
              <div style={{ background:'white', borderRadius:8, padding:'12px 16px', display:'inline-block' }}>
                <div style={{ display:'flex', gap:1, height:40, alignItems:'flex-end', justifyContent:'center', marginBottom:6 }}>
                  {Array.from({length:28}, (_,i) => (
                    <div key={i} style={{ width: i%3===0?3:i%2===0?2:1, background:'#1a1a2e', borderRadius:1, height: i%4===0?40:34 }} />
                  ))}
                </div>
                <div style={{ fontFamily:'monospace', fontSize:9, color:'#1a1a2e', letterSpacing:2 }}>{skuPreview}</div>
              </div>
              <div style={{ fontSize:11, color:'#8888aa', marginTop:8 }}>Generated automatically on save</div>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:20 }}>
        <button onClick={() => navigate('/inventory')} style={btnSec}>Cancel</button>
        <button onClick={() => saveMut.mutate()} disabled={saveMut.isPending} style={btnPri}>
          {saveMut.isPending ? 'Saving...' : isEdit ? 'Update Product' : 'Create Product'}
        </button>
      </div>
    </div>
  );
}

const crd  = { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, overflow:'hidden' };
const hdr  = { padding:'12px 16px', borderBottom:'1px solid rgba(255,255,255,0.06)', fontSize:13, fontWeight:500 };
const fg   = { marginBottom:12 };
const fr   = { display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:0 };
const lbl  = { display:'block', fontSize:11, color:'#8888aa', marginBottom:4, fontWeight:500 };
const inp  = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%', boxSizing:'border-box' };
const sel  = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%' };
const btnPri = { padding:'9px 20px', borderRadius:7, border:'none', background:'#e94560', color:'white', fontSize:12, fontWeight:500, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSec = { padding:'9px 16px', borderRadius:7, background:'rgba(255,255,255,0.07)', color:'#e8e8f0', border:'1px solid rgba(255,255,255,0.1)', fontSize:12, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
