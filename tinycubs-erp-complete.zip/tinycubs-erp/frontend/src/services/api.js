// TinyCubs ERP — Frontend API Service
// All backend calls go through here

import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL + '/api',
  headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
});

// Attach Sanctum token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('erp_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 → redirect to login
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('erp_token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ─── Auth ─────────────────────────────────────────────────────
export const authApi = {
  login:  (data) => api.post('/login', data),
  logout: ()     => api.post('/logout'),
  me:     ()     => api.get('/me'),
};

// ─── Dashboard ────────────────────────────────────────────────
export const dashboardApi = {
  get:   ()       => api.get('/dashboard'),
  chart: (period) => api.get('/dashboard/chart', { params: { period } }),
};

// ─── Customers ────────────────────────────────────────────────
export const customersApi = {
  list:     (params)         => api.get('/customers', { params }),
  get:      (id)             => api.get(`/customers/${id}`),
  create:   (data)           => api.post('/customers', data),
  update:   (id, data)       => api.put(`/customers/${id}`, data),
  delete:   (id)             => api.delete(`/customers/${id}`),
  invoices: (id)             => api.get(`/customers/${id}/invoices`),
};

// ─── Products / Inventory ─────────────────────────────────────
export const productsApi = {
  list:          (params)   => api.get('/products', { params }),
  get:           (id)       => api.get(`/products/${id}`),
  create:        (data)     => api.post('/products', data),
  update:        (id, data) => api.put(`/products/${id}`, data),
  delete:        (id)       => api.delete(`/products/${id}`),
  findByBarcode: (code)     => api.get(`/products/search/barcode/${code}`),
  lowStock:      ()         => api.get('/products/low-stock'),
  adjustStock:   (id, data) => api.post(`/products/${id}/stock`, data),
  movements:     (id)       => api.get(`/products/${id}/movements`),
};

// ─── Invoices ─────────────────────────────────────────────────
export const invoicesApi = {
  list:          (params)   => api.get('/invoices', { params }),
  get:           (id)       => api.get(`/invoices/${id}`),
  create:        (data)     => api.post('/invoices', data),
  update:        (id, data) => api.put(`/invoices/${id}`, data),
  delete:        (id)       => api.delete(`/invoices/${id}`),
  pdf:           (id)       => api.get(`/invoices/${id}/pdf`, { responseType: 'blob' }),
  sendWhatsApp:  (id)       => api.post(`/invoices/${id}/send-whatsapp`),
  convert:       (id)       => api.post(`/invoices/${id}/convert`),
  addPayment:    (id, data) => api.post(`/invoices/${id}/payments`, data),
  payments:      (id)       => api.get(`/invoices/${id}/payments`),
};

// ─── Expenses ─────────────────────────────────────────────────
export const expensesApi = {
  list:   (params)   => api.get('/expenses', { params }),
  create: (data)     => api.post('/expenses', data),
  update: (id, data) => api.put(`/expenses/${id}`, data),
  delete: (id)       => api.delete(`/expenses/${id}`),
};

// ─── Job Orders ───────────────────────────────────────────────
export const jobOrdersApi = {
  list:           (params)   => api.get('/job-orders', { params }),
  get:            (id)       => api.get(`/job-orders/${id}`),
  create:         (data)     => api.post('/job-orders', data),
  update:         (id, data) => api.put(`/job-orders/${id}`, data),
  updateStatus:   (id, data) => api.patch(`/job-orders/${id}/status`, data),
  updateProgress: (id, data) => api.patch(`/job-orders/${id}/progress`, data),
  addMaterial:    (id, data) => api.post(`/job-orders/${id}/materials`, data),
};

// ─── Barcodes ─────────────────────────────────────────────────
export const barcodesApi = {
  generate: (data) => api.post('/barcodes/generate', data),
  print:    (id)   => api.get(`/barcodes/${id}/print`, { responseType: 'blob' }),
  scan:     (code) => api.get(`/barcodes/scan/${code}`),
};

// ─── Reports ─────────────────────────────────────────────────
export const reportsApi = {
  sales:       (params) => api.get('/reports/sales', { params }),
  profitLoss:  (params) => api.get('/reports/profit-loss', { params }),
  outstanding: (params) => api.get('/reports/outstanding', { params }),
  inventory:   (params) => api.get('/reports/inventory', { params }),
  production:  (params) => api.get('/reports/production', { params }),

  // Download PDF helpers
  downloadSales:       (params) => api.get('/reports/sales', { params: { ...params, format: 'pdf' }, responseType: 'blob' }),
  downloadPL:          (params) => api.get('/reports/profit-loss', { params: { ...params, format: 'pdf' }, responseType: 'blob' }),
  downloadOutstanding: ()       => api.get('/reports/outstanding', { params: { format: 'pdf' }, responseType: 'blob' }),
  downloadInventory:   ()       => api.get('/reports/inventory', { params: { format: 'pdf' }, responseType: 'blob' }),
  downloadProduction:  (params) => api.get('/reports/production', { params: { ...params, format: 'pdf' }, responseType: 'blob' }),
};

// ─── WooCommerce ─────────────────────────────────────────────
export const wooApi = {
  status:       ()  => api.get('/woocommerce/status'),
  syncProducts: ()  => api.post('/woocommerce/sync/products'),
  syncOrders:   ()  => api.post('/woocommerce/sync/orders'),
};

// ─── Settings ─────────────────────────────────────────────────
export const settingsApi = {
  get:    () => api.get('/settings'),
  update: (data) => api.put('/settings', data),
};

// ─── Workers & Materials ──────────────────────────────────────
export const workersApi = {
  list:   () => api.get('/workers'),
  create: (data) => api.post('/workers', data),
};
export const materialsApi = {
  list:   () => api.get('/materials'),
  create: (data) => api.post('/materials', data),
};

// ─── Utility: download blob as file ──────────────────────────
export function downloadBlob(response, filename) {
  const url  = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href  = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

export default api;
