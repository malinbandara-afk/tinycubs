// TinyCubs ERP — Auth Store (Zustand)
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authApi } from '../services/api';

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user:  null,
      token: null,

      login: async (email, password) => {
        const res = await authApi.login({ email, password });
        const { token, user } = res.data;
        localStorage.setItem('erp_token', token);
        set({ user, token });
        return user;
      },

      logout: async () => {
        try { await authApi.logout(); } catch {}
        localStorage.removeItem('erp_token');
        set({ user: null, token: null });
      },

      fetchMe: async () => {
        const res = await authApi.me();
        set({ user: res.data });
      },

      // Role helpers
      isAdmin:      () => get().user?.role === 'admin',
      isSales:      () => ['admin', 'sales'].includes(get().user?.role),
      isAccounts:   () => ['admin', 'accounts'].includes(get().user?.role),
      isOperations: () => ['admin', 'operations'].includes(get().user?.role),

      can: (module) => {
        const role = get().user?.role;
        const permissions = {
          admin:      ['dashboard','sales','inventory','production','accounting','reports','integrations','users'],
          sales:      ['dashboard','sales'],
          accounts:   ['dashboard','accounting','reports'],
          operations: ['dashboard','inventory','production'],
        };
        return permissions[role]?.includes(module) ?? false;
      },
    }),
    {
      name:    'tinycubs-auth',
      partialize: (state) => ({ user: state.user, token: state.token }),
    }
  )
);
