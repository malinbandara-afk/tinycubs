# TinyCubs ERP — Deployment Guide
## Production Setup on Ubuntu VPS (DigitalOcean / Hostinger)

---

## STEP 1: Server Setup (Ubuntu 22.04)

```bash
# Update & install dependencies
sudo apt update && sudo apt upgrade -y
sudo apt install -y nginx mysql-server php8.2 php8.2-fpm php8.2-mysql \
  php8.2-mbstring php8.2-xml php8.2-curl php8.2-zip php8.2-gd \
  php8.2-bcmath composer nodejs npm git unzip certbot python3-certbot-nginx

# Configure MySQL
sudo mysql_secure_installation
sudo mysql -u root -p
> CREATE DATABASE tinycubs_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
> CREATE USER 'tinycubs'@'localhost' IDENTIFIED BY 'STRONG_PASSWORD_HERE';
> GRANT ALL PRIVILEGES ON tinycubs_erp.* TO 'tinycubs'@'localhost';
> FLUSH PRIVILEGES; EXIT;
```

---

## STEP 2: Deploy Backend (Laravel)

```bash
cd /var/www
sudo git clone https://github.com/YOUR_ORG/tinycubs-erp.git
sudo chown -R www-data:www-data tinycubs-erp
cd tinycubs-erp/backend

# Install PHP dependencies
composer install --no-dev --optimize-autoloader

# Configure environment
cp .env.example .env
nano .env   # Fill in DB_PASSWORD, WC keys, WhatsApp credentials

# Generate app key & migrate
php artisan key:generate
php artisan migrate --seed
php artisan storage:link
php artisan config:cache
php artisan route:cache

# Set permissions
sudo chmod -R 775 storage bootstrap/cache
sudo chown -R www-data:www-data storage bootstrap/cache
```

---

## STEP 3: Deploy Frontend (React)

```bash
cd /var/www/tinycubs-erp/frontend
npm install
cp .env.example .env
# Set VITE_API_URL=https://erp.tinycubs.lk
npm run build
# Output goes to dist/ — Nginx will serve this
```

---

## STEP 4: Nginx Configuration

```nginx
# /etc/nginx/sites-available/tinycubs-erp
server {
    listen 80;
    server_name erp.tinycubs.lk;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name erp.tinycubs.lk;

    ssl_certificate     /etc/letsencrypt/live/erp.tinycubs.lk/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/erp.tinycubs.lk/privkey.pem;

    # Frontend (React SPA)
    root /var/www/tinycubs-erp/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        root /var/www/tinycubs-erp/backend/public;
        try_files $uri $uri/ /index.php?$query_string;

        location ~ \.php$ {
            fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
            include fastcgi_params;
        }
    }

    # File uploads
    client_max_body_size 20M;
}
```

```bash
sudo ln -s /etc/nginx/sites-available/tinycubs-erp /etc/nginx/sites-enabled/
sudo certbot --nginx -d erp.tinycubs.lk
sudo nginx -t && sudo systemctl reload nginx
```

---

## STEP 5: Queue Worker (for WhatsApp & WooCommerce sync)

```bash
# /etc/supervisor/conf.d/tinycubs-queue.conf
[program:tinycubs-queue]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/tinycubs-erp/backend/artisan queue:work --sleep=3 --tries=3
autostart=true
autorestart=true
user=www-data
numprocs=2
stdout_logfile=/var/log/tinycubs-queue.log

# Then:
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start tinycubs-queue:*
```

---

## STEP 6: Scheduled Tasks (Stock alerts, WC sync)

```bash
# Add to crontab: sudo crontab -e -u www-data
* * * * * cd /var/www/tinycubs-erp/backend && php artisan schedule:run >> /dev/null 2>&1
```

---

## STEP 7: Backups

```bash
# Daily DB backup script: /home/ubuntu/backup.sh
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M)
BACKUP_DIR="/backups/tinycubs"
mkdir -p $BACKUP_DIR
mysqldump -u tinycubs -p'STRONG_PASSWORD' tinycubs_erp | gzip > "$BACKUP_DIR/db_$DATE.sql.gz"
# Keep last 30 days
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete

# Add to cron: 0 2 * * * /home/ubuntu/backup.sh
```

---

## STEP 8: WooCommerce Webhook Setup

In WordPress Admin → WooCommerce → Settings → Advanced → Webhooks:
- **Name**: ERP Order Sync
- **Status**: Active
- **Topic**: Order created
- **Delivery URL**: `https://erp.tinycubs.lk/api/webhook/woocommerce`
- **Secret**: (copy from your .env WC_WEBHOOK_SECRET)

Repeat for: Order updated, Order deleted

---

## DNS Setup

In your domain registrar (for tinycubs.lk):
```
A record:  erp.tinycubs.lk  → YOUR_SERVER_IP
A record:  tinycubs.lk       → YOUR_WORDPRESS_IP  (existing site)
```

---

## Default Credentials (change immediately after first login)

| Role       | Email                    | Password   |
|------------|--------------------------|------------|
| Admin      | admin@tinycubs.lk        | Admin@1234 |
| Sales      | sales@tinycubs.lk        | Sales@1234 |
| Accounts   | accounts@tinycubs.lk     | Accts@1234 |
| Operations | ops@tinycubs.lk          | Ops@12345  |

**⚠️ Change all passwords immediately after first login!**

---

## Estimated Monthly Costs (Sri Lanka)

| Service          | Cost        |
|------------------|-------------|
| DigitalOcean VPS ($12/mo) | ~Rs 3,800 |
| SSL (Let's Encrypt) | Free |
| WhatsApp (Twilio) | ~Rs 3-5 per message |
| Domain renewal   | ~Rs 3,000/year |
| **Total**        | **~Rs 4,000-5,000/mo** |
