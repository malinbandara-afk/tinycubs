import { create } from 'zustand';
import { authApi } from '../services/api';

export const useAuthStore = create((set, get) => ({
  user:  JSON.parse(localStorage.getItem('erp_user') || 'null'),
  token: localStorage.getItem('erp_token') || null,

  login: async (email, password) => {
    const res   = await authApi.login({ email, password });
    const { token, user } = res.data;
    localStorage.setItem('erp_token', token);
    localStorage.setItem('erp_user',  JSON.stringify(user));
    set({ user, token });
    return user;
  },

  logout: async () => {
    try { await authApi.logout(); } catch {}
    localStorage.removeItem('erp_token');
    localStorage.removeItem('erp_user');
    set({ user: null, token: null });
  },

  fetchMe: async () => {
    try {
      const res = await authApi.me();
      set({ user: res.data });
      localStorage.setItem('erp_user', JSON.stringify(res.data));
    } catch {}
  },

  isAdmin:      () => get().user?.role === 'admin',
  isSales:      () => ['admin','sales'].includes(get().user?.role),
  isAccounts:   () => ['admin','accounts'].includes(get().user?.role),
  isOperations: () => ['admin','operations'].includes(get().user?.role),

  can: (module) => {
    const role = get().user?.role;
    const perms = {
      admin:      ['dashboard','sales','inventory','production','accounting','reports','integrations','users'],
      sales:      ['dashboard','sales'],
      accounts:   ['dashboard','accounting','reports'],
      operations: ['dashboard','inventory','production'],
    };
    return perms[role]?.includes(module) ?? false;
  },
}));
