import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { jobOrdersApi } from '../services/api';
import toast from 'react-hot-toast';

const STATUSES = [
  { key:'pending',     label:'Pending',     color:'#ffb347', bg:'rgba(255,179,71,0.15)' },
  { key:'in_progress', label:'In Progress', color:'#54a0ff', bg:'rgba(84,160,255,0.15)' },
  { key:'qc_check',    label:'QC Check',    color:'#a29bfe', bg:'rgba(162,155,254,0.15)' },
  { key:'completed',   label:'Completed',   color:'#00d4aa', bg:'rgba(0,212,170,0.15)'  },
  { key:'cancelled',   label:'Cancelled',   color:'#636e72', bg:'rgba(99,110,114,0.15)' },
];

function StatusBadge({ status }) {
  const s = STATUSES.find(x => x.key === status) || STATUSES[0];
  return <span style={{ padding:'3px 10px', borderRadius:20, fontSize:10, fontWeight:600, color:s.color, background:s.bg }}>{s.label}</span>;
}

function ProgressBar({ pct, color='#54a0ff' }) {
  return (
    <div style={{ height:4, background:'rgba(255,255,255,0.08)', borderRadius:10, overflow:'hidden', marginTop:6 }}>
      <div style={{ height:'100%', width:`${pct}%`, background:color, borderRadius:10, transition:'width 0.4s' }} />
    </div>
  );
}

function JobCard({ job, onStatusChange, onProgressChange }) {
  const [prog, setProg] = useState(job.progress_pct);
  const s = STATUSES.find(x => x.key === job.status) || STATUSES[0];

  return (
    <div style={{ background:'#1a1a2e', border:`1px solid rgba(255,255,255,0.07)`, borderLeft:`3px solid ${s.color}`, borderRadius:8, padding:12, marginBottom:8 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
        <div>
          <div style={{ fontSize:12, fontWeight:500 }}>{job.title}</div>
          <div style={{ fontFamily:'monospace', fontSize:10, color:'#8888aa', marginTop:1 }}>{job.job_number}</div>
        </div>
        <StatusBadge status={job.status} />
      </div>
      {job.description && <div style={{ fontSize:11, color:'#8888aa', marginBottom:6 }}>{job.description}</div>}
      <div style={{ display:'flex', gap:16, fontSize:11, color:'#8888aa', marginBottom:8 }}>
        <span>Qty: <strong style={{ color:'#e8e8f0' }}>{job.quantity}</strong></span>
        {job.worker?.name && <span>Worker: <strong style={{ color:'#e8e8f0' }}>{job.worker.name}</strong></span>}
        {job.due_date && <span>Due: <strong style={{ color: new Date(job.due_date) < new Date() && job.status !== 'completed' ? '#ff4757' : '#e8e8f0' }}>{job.due_date}</strong></span>}
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ fontSize:10, color:'#8888aa' }}>Progress:</span>
        <input type="range" min={0} max={100} value={prog}
          onChange={e => setProg(parseInt(e.target.value))}
          onMouseUp={e => onProgressChange(job.id, parseInt(e.target.value))}
          style={{ flex:1, accentColor:s.color }}
        />
        <span style={{ fontSize:11, fontWeight:600, color:s.color, minWidth:30 }}>{prog}%</span>
      </div>
      <ProgressBar pct={prog} color={s.color} />
      <div style={{ display:'flex', gap:6, marginTop:10 }}>
        {STATUSES.filter(x=>!['cancelled'].includes(x.key)&&x.key!==job.status).slice(0,2).map(next=>(
          <button key={next.key} onClick={()=>onStatusChange(job.id,next.key)} style={{
            padding:'4px 10px', borderRadius:6, border:`1px solid ${next.color}40`,
            background:`${next.bg}`, color:next.color, fontSize:10, cursor:'pointer', fontFamily:"'Sora',sans-serif",
          }}>→ {next.label}</button>
        ))}
      </div>
    </div>
  );
}

export default function Production() {
  const navigate = useNavigate();
  const qc       = useQueryClient();
  const [view, setView]       = useState('list'); // list | kanban
  const [filter, setFilter]   = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['job-orders', filter],
    queryFn: () => jobOrdersApi.list({ status: filter || undefined, per_page: 50 }).then(r => r.data),
  });

  const statusMut = useMutation({
    mutationFn: ({ id, status }) => jobOrdersApi.updateStatus(id, { status }),
    onSuccess: () => { toast.success('Status updated!'); qc.invalidateQueries({ queryKey:['job-orders'] }); },
    onError:   () => toast.error('Update failed'),
  });

  const progressMut = useMutation({
    mutationFn: ({ id, progress }) => jobOrdersApi.updateProgress(id, { progress }),
    onSuccess: () => qc.invalidateQueries({ queryKey:['job-orders'] }),
  });

  const jobs = data?.data ?? [];

  const pipeline = STATUSES.slice(0,4).map(s => ({
    ...s,
    jobs: jobs.filter(j => j.status === s.key),
    count: jobs.filter(j => j.status === s.key).length,
  }));

  const statsRow = [
    { label:'Pending',     val:jobs.filter(j=>j.status==='pending').length,     color:'#ffb347' },
    { label:'In Progress', val:jobs.filter(j=>j.status==='in_progress').length, color:'#54a0ff' },
    { label:'QC Check',    val:jobs.filter(j=>j.status==='qc_check').length,    color:'#a29bfe' },
    { label:'Completed',   val:jobs.filter(j=>j.status==='completed').length,   color:'#00d4aa' },
  ];

  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:600, margin:0, letterSpacing:-0.5 }}>Production</h1>
          <p style={{ fontSize:12, color:'#8888aa', margin:'4px 0 0' }}>Job orders, workers & material tracking</p>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={()=>setView(v=>v==='list'?'kanban':'list')} style={btnSec}>
            {view==='list'?'⬛ Kanban':'☰ List'}
          </button>
          <button onClick={() => navigate('/production/new')} style={btnPri}>+ New Job Order</button>
        </div>
      </div>

      {/* Pipeline Stats */}
      <div style={{ display:'flex', gap:0, marginBottom:20, borderRadius:10, overflow:'hidden', border:'1px solid rgba(255,255,255,0.08)' }}>
        {statsRow.map((s,i) => (
          <div key={s.label} onClick={()=>setFilter(STATUSES[i].key===filter?'':STATUSES[i].key)} style={{
            flex:1, padding:'14px 10px', textAlign:'center',
            background: STATUSES[i].key===filter ? `${STATUSES[i].bg}` : '#16213e',
            borderLeft: i>0?'1px solid rgba(255,255,255,0.06)':'none',
            cursor:'pointer', transition:'background 0.15s',
          }}>
            <div style={{ fontSize:22, fontWeight:700, color:s.color }}>{s.val}</div>
            <div style={{ fontSize:10, color:'#8888aa', marginTop:2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Kanban View */}
      {view === 'kanban' ? (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
          {pipeline.map(col=>(
            <div key={col.key}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                <span style={{ fontSize:12, fontWeight:500, color:col.color }}>{col.label}</span>
                <span style={{ fontSize:11, background:col.bg, color:col.color, padding:'1px 8px', borderRadius:10 }}>{col.count}</span>
              </div>
              {isLoading ? (
                <div style={{ fontSize:12, color:'#8888aa', padding:12 }}>Loading...</div>
              ) : col.jobs.length === 0 ? (
                <div style={{ fontSize:11, color:'#555', textAlign:'center', padding:24, border:'1px dashed rgba(255,255,255,0.06)', borderRadius:8 }}>No jobs</div>
              ) : col.jobs.map(job=>(
                <JobCard key={job.id} job={job}
                  onStatusChange={(id,status)=>statusMut.mutate({id,status})}
                  onProgressChange={(id,progress)=>progressMut.mutate({id,progress})}
                />
              ))}
            </div>
          ))}
        </div>
      ) : (
        /* List View */
        <div style={card}>
          <div style={{ overflowX:'auto' }}>
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
              <thead>
                <tr>
                  {['Job #','Title','Worker','Qty','Due Date','Progress','Status','Actions'].map(h=>(
                    <th key={h} style={th}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={8} style={{ textAlign:'center', padding:32, color:'#8888aa' }}>Loading...</td></tr>
                ) : jobs.length === 0 ? (
                  <tr><td colSpan={8} style={{ textAlign:'center', padding:32, color:'#8888aa' }}>No job orders found</td></tr>
                ) : jobs.map(job=>(
                  <tr key={job.id}>
                    <td style={td}><span style={{ fontFamily:'monospace', fontSize:11, color:'#8888aa' }}>{job.job_number}</span></td>
                    <td style={td}>
                      <div style={{ fontWeight:500 }}>{job.title}</div>
                      {job.description && <div style={{ fontSize:10, color:'#8888aa' }}>{job.description.slice(0,50)}</div>}
                    </td>
                    <td style={td}>{job.worker?.name || <span style={{ color:'#555' }}>Unassigned</span>}</td>
                    <td style={td}>{job.quantity}</td>
                    <td style={td}>
                      {job.due_date ? (
                        <span style={{ color: new Date(job.due_date)<new Date()&&job.status!=='completed'?'#ff4757':'#e8e8f0' }}>
                          {job.due_date}
                        </span>
                      ) : '—'}
                    </td>
                    <td style={td}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, minWidth:100 }}>
                        <div style={{ flex:1, height:4, background:'rgba(255,255,255,0.08)', borderRadius:10, overflow:'hidden' }}>
                          <div style={{ height:'100%', width:`${job.progress_pct}%`, background: STATUSES.find(s=>s.key===job.status)?.color||'#54a0ff', borderRadius:10 }} />
                        </div>
                        <span style={{ fontSize:10, minWidth:28 }}>{job.progress_pct}%</span>
                      </div>
                    </td>
                    <td style={td}><StatusBadge status={job.status} /></td>
                    <td style={td}>
                      <div style={{ display:'flex', gap:4 }}>
                        <select
                          value={job.status}
                          onChange={e => statusMut.mutate({ id:job.id, status:e.target.value })}
                          style={{ ...selSm, width:110 }}
                        >
                          {STATUSES.map(s=><option key={s.key} value={s.key}>{s.label}</option>)}
                        </select>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

const card   = { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, overflow:'hidden' };
const th     = { padding:'9px 12px', textAlign:'left', fontSize:10, fontWeight:600, textTransform:'uppercase', letterSpacing:'0.8px', color:'#555566', borderBottom:'1px solid rgba(255,255,255,0.06)' };
const td     = { padding:'10px 12px', borderBottom:'1px solid rgba(255,255,255,0.04)', verticalAlign:'middle', fontSize:12 };
const btnPri = { padding:'8px 16px', borderRadius:7, border:'none', background:'#e94560', color:'white', fontSize:12, fontWeight:500, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSec = { padding:'8px 14px', borderRadius:7, background:'rgba(255,255,255,0.07)', color:'#e8e8f0', border:'1px solid rgba(255,255,255,0.1)', fontSize:12, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const selSm  = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:6, color:'#e8e8f0', padding:'4px 8px', fontSize:11, fontFamily:"'Sora',sans-serif", outline:'none' };
