import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { reportsApi, downloadBlob } from '../services/api';
import toast from 'react-hot-toast';

const thisMonth = () => {
  const now = new Date();
  return {
    from: new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0,10),
    to:   now.toISOString().slice(0,10),
  };
};

function ReportCard({ icon, title, desc, onPdf, onPrint, loading }) {
  return (
    <div style={{ background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.07)', borderRadius:10, padding:16, display:'flex', alignItems:'center', gap:14, transition:'border-color 0.15s' }}>
      <div style={{ fontSize:28 }}>{icon}</div>
      <div style={{ flex:1 }}>
        <div style={{ fontSize:13, fontWeight:500 }}>{title}</div>
        <div style={{ fontSize:11, color:'#8888aa', marginTop:2 }}>{desc}</div>
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
        <button onClick={onPdf} disabled={loading} style={btnPdf}>{loading?'..':'📄 PDF'}</button>
        <button onClick={onPrint} style={btnPrint}>🖨 Print</button>
      </div>
    </div>
  );
}

function StatRow({ label, value, sub, color='#e8e8f0' }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 0', borderBottom:'1px solid rgba(255,255,255,0.05)' }}>
      <div>
        <div style={{ fontSize:12 }}>{label}</div>
        {sub && <div style={{ fontSize:10, color:'#8888aa' }}>{sub}</div>}
      </div>
      <div style={{ fontSize:13, fontWeight:600, color }}>{value}</div>
    </div>
  );
}

export default function Reports() {
  const [dates, setDates] = useState(thisMonth());
  const [loading, setLoading] = useState('');

  const { data: sales }  = useQuery({ queryKey:['rpt-sales',dates], queryFn:()=>reportsApi.sales(dates).then(r=>r.data) });
  const { data: pl }     = useQuery({ queryKey:['rpt-pl',dates],    queryFn:()=>reportsApi.profitLoss(dates).then(r=>r.data) });
  const { data: outst }  = useQuery({ queryKey:['rpt-out'],         queryFn:()=>reportsApi.outstanding({}).then(r=>r.data) });
  const { data: inv }    = useQuery({ queryKey:['rpt-inv'],         queryFn:()=>reportsApi.inventory({}).then(r=>r.data) });
  const { data: prod }   = useQuery({ queryKey:['rpt-prod',dates],  queryFn:()=>reportsApi.production(dates).then(r=>r.data) });

  const download = async (key, fn, filename) => {
    setLoading(key);
    try {
      const res = await fn();
      downloadBlob(res, filename);
      toast.success(`${filename} downloaded!`);
    } catch { toast.error('Download failed — check server'); }
    finally { setLoading(''); }
  };

  const printPage = (content) => {
    const w = window.open('', '_blank');
    w.document.write(`<html><head><title>TinyCubs Report</title><style>body{font-family:Arial;font-size:12px;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:6px;text-align:left}th{background:#f5f5f5}</style></head><body>${content}</body></html>`);
    w.document.close();
    w.print();
  };

  const buildSalesHtml = () => `
    <h2>TinyCubs.lk — Sales Report</h2>
    <p>Period: ${dates.from} to ${dates.to}</p>
    <p><strong>Total Invoices:</strong> ${sales?.total_invoices ?? 0} &nbsp;&nbsp;
       <strong>Revenue:</strong> Rs ${Math.round(sales?.total_revenue??0).toLocaleString()} &nbsp;&nbsp;
       <strong>Collected:</strong> Rs ${Math.round(sales?.total_collected??0).toLocaleString()} &nbsp;&nbsp;
       <strong>Outstanding:</strong> Rs ${Math.round(sales?.total_outstanding??0).toLocaleString()}</p>
    <table><tr><th>Invoice</th><th>Customer</th><th>Date</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th></tr>
    ${(sales?.invoices??[]).map(i=>`<tr><td>${i.invoice_number}</td><td>${i.customer?.name}</td><td>${i.invoice_date}</td><td>Rs ${parseFloat(i.total).toLocaleString()}</td><td>Rs ${parseFloat(i.amount_paid).toLocaleString()}</td><td>Rs ${parseFloat(i.balance_due).toLocaleString()}</td><td>${i.status}</td></tr>`).join('')}
    </table>`;

  const buildPLHtml = () => `
    <h2>TinyCubs.lk — Profit & Loss</h2>
    <p>Period: ${dates.from} to ${dates.to}</p>
    <p><strong>Revenue:</strong> Rs ${Math.round(pl?.revenue??0).toLocaleString()}</p>
    <p><strong>Total Expenses:</strong> Rs ${Math.round(pl?.total_expenses??0).toLocaleString()}</p>
    <p><strong>Net Profit:</strong> Rs ${Math.round(pl?.net_profit??0).toLocaleString()} (${pl?.margin_pct}%)</p>
    <h3>Expense Breakdown</h3>
    <table><tr><th>Category</th><th>Amount</th></tr>
    ${Object.entries(pl?.expenses??{}).map(([k,v])=>`<tr><td>${k.replace(/_/g,' ')}</td><td>Rs ${Math.round(v).toLocaleString()}</td></tr>`).join('')}
    </table>`;

  const buildOutstandingHtml = () => `
    <h2>TinyCubs.lk — Outstanding Payments</h2>
    <p><strong>Total Outstanding:</strong> Rs ${Math.round(outst?.total_outstanding??0).toLocaleString()} (${outst?.count} invoices)</p>
    <table><tr><th>Invoice</th><th>Customer</th><th>Phone</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th><th>Overdue Days</th></tr>
    ${(outst?.invoices??[]).map(i=>`<tr><td>${i.invoice_number}</td><td>${i.customer}</td><td>${i.phone||'—'}</td><td>Rs ${parseFloat(i.total).toLocaleString()}</td><td>Rs ${parseFloat(i.amount_paid).toLocaleString()}</td><td><strong>Rs ${parseFloat(i.balance_due).toLocaleString()}</strong></td><td>${i.status}</td><td>${i.days_overdue??0}</td></tr>`).join('')}
    </table>`;

  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:600, margin:0, letterSpacing:-0.5 }}>Reports</h1>
          <p style={{ fontSize:12, color:'#8888aa', margin:'4px 0 0' }}>Download & print all business reports</p>
        </div>
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          <input type="date" value={dates.from} onChange={e=>setDates(d=>({...d,from:e.target.value}))} style={{ ...inp, width:140 }} />
          <span style={{ color:'#8888aa', fontSize:12 }}>to</span>
          <input type="date" value={dates.to} onChange={e=>setDates(d=>({...d,to:e.target.value}))} style={{ ...inp, width:140 }} />
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:20 }}>
        <ReportCard icon="📊" title="Sales Report" desc="All invoices, revenue & collection status"
          onPdf={()=>download('sales',()=>reportsApi.downloadSales(dates),`Sales-${dates.from}-${dates.to}.pdf`)}
          onPrint={()=>printPage(buildSalesHtml())} loading={loading==='sales'} />
        <ReportCard icon="💰" title="Profit & Loss" desc="Revenue vs expenses, net profit & margin"
          onPdf={()=>download('pl',()=>reportsApi.downloadPL(dates),`PL-${dates.from}-${dates.to}.pdf`)}
          onPrint={()=>printPage(buildPLHtml())} loading={loading==='pl'} />
        <ReportCard icon="⏳" title="Outstanding Payments" desc="All unpaid & partially paid invoices"
          onPdf={()=>download('out',()=>reportsApi.downloadOutstanding(),`Outstanding-Payments.pdf`)}
          onPrint={()=>printPage(buildOutstandingHtml())} loading={loading==='out'} />
        <ReportCard icon="📦" title="Inventory Report" desc="Stock levels, values & low stock items"
          onPdf={()=>download('inv',()=>reportsApi.downloadInventory(),`Inventory-Report.pdf`)}
          onPrint={()=>{}} loading={loading==='inv'} />
        <ReportCard icon="🏭" title="Production Report" desc="Job orders, workers & material usage"
          onPdf={()=>download('prod',()=>reportsApi.downloadProduction(dates),`Production-${dates.from}-${dates.to}.pdf`)}
          onPrint={()=>{}} loading={loading==='prod'} />
        <ReportCard icon="📈" title="Full Business Report" desc="All modules combined in one PDF"
          onPdf={()=>toast('Full report coming soon — download each individually for now.')}
          onPrint={()=>{}} loading={false} />
      </div>

      {/* Live previews */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        {/* Sales Summary */}
        <div style={crd}>
          <div style={hdr}>Sales Summary Preview</div>
          <div style={{ padding:16 }}>
            <StatRow label="Total Invoices"   value={sales?.total_invoices ?? '—'} />
            <StatRow label="Revenue"          value={`Rs ${Math.round(sales?.total_revenue??0).toLocaleString()}`}   color="#00d4aa" />
            <StatRow label="Collected"        value={`Rs ${Math.round(sales?.total_collected??0).toLocaleString()}`} color="#54a0ff" />
            <StatRow label="Outstanding"      value={`Rs ${Math.round(sales?.total_outstanding??0).toLocaleString()}`} color="#ffb347" />
            {sales?.by_status && Object.entries(sales.by_status).map(([st,cnt])=>(
              <StatRow key={st} label={st.charAt(0).toUpperCase()+st.slice(1)+' orders'} value={cnt} sub="" />
            ))}
          </div>
        </div>

        {/* Outstanding Summary */}
        <div style={crd}>
          <div style={hdr}>Outstanding Payments Preview</div>
          <div style={{ padding:16 }}>
            <StatRow label="Total Outstanding" value={`Rs ${Math.round(outst?.total_outstanding??0).toLocaleString()}`} color="#ff4757" />
            <StatRow label="Invoices Pending"  value={outst?.count ?? '—'} />
            {(outst?.invoices??[]).slice(0,5).map(i=>(
              <div key={i.invoice_number} style={{ display:'flex', justifyContent:'space-between', padding:'7px 0', borderBottom:'1px solid rgba(255,255,255,0.05)', fontSize:12 }}>
                <div>
                  <span style={{ fontFamily:'monospace', fontSize:10, color:'#8888aa' }}>#{i.invoice_number}</span>
                  <span style={{ marginLeft:8 }}>{i.customer}</span>
                </div>
                <span style={{ color:'#ff4757', fontWeight:600 }}>Rs {parseFloat(i.balance_due).toLocaleString()}</span>
              </div>
            ))}
            {(outst?.invoices??[]).length > 5 && (
              <div style={{ fontSize:11, color:'#8888aa', marginTop:8, textAlign:'center' }}>
                + {outst.invoices.length - 5} more — download PDF for full list
              </div>
            )}
          </div>
        </div>

        {/* Inventory Summary */}
        <div style={crd}>
          <div style={hdr}>Inventory Summary Preview</div>
          <div style={{ padding:16 }}>
            <StatRow label="Total SKUs"       value={inv?.total_skus ?? '—'} />
            <StatRow label="Total Stock Value" value={`Rs ${Math.round(inv?.total_value??0).toLocaleString()}`} color="#00d4aa" />
            <StatRow label="Low Stock Items"   value={inv?.low_stock  ?? '—'} color="#ffb347" />
            <StatRow label="Out of Stock"      value={inv?.out_of_stock ?? '—'} color="#ff4757" />
            <div style={{ marginTop:10 }}>
              <div style={{ fontSize:11, color:'#8888aa', marginBottom:6 }}>Critical Items (lowest stock first)</div>
              {(inv?.products??[]).filter(p=>p.stock_qty<=p.low_stock_threshold).slice(0,4).map(p=>(
                <div key={p.sku} style={{ display:'flex', justifyContent:'space-between', padding:'5px 0', fontSize:11, borderBottom:'1px solid rgba(255,255,255,0.04)' }}>
                  <span style={{ fontFamily:'monospace', color:'#8888aa' }}>{p.sku}</span>
                  <span style={{ color: p.stock_qty<=0?'#ff4757':'#ffb347', fontWeight:600 }}>{p.stock_qty} left</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Production Summary */}
        <div style={crd}>
          <div style={hdr}>Production Summary Preview</div>
          <div style={{ padding:16 }}>
            <StatRow label="Total Job Orders" value={prod?.jobs?.length ?? '—'} />
            <StatRow label="Total Units"       value={prod?.total_units ?? '—'} />
            {prod?.by_status && Object.entries(prod.by_status).map(([st,cnt])=>(
              <StatRow key={st} label={st.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase())} value={cnt} />
            ))}
            {prod?.by_worker && Object.entries(prod.by_worker).length > 0 && (
              <div style={{ marginTop:10 }}>
                <div style={{ fontSize:11, color:'#8888aa', marginBottom:6 }}>By Worker</div>
                {Object.entries(prod.by_worker).map(([name,cnt])=>(
                  <div key={name} style={{ display:'flex', justifyContent:'space-between', fontSize:11, padding:'4px 0' }}>
                    <span>{name||'Unassigned'}</span><span style={{ color:'#54a0ff' }}>{cnt} jobs</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const crd    = { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, overflow:'hidden' };
const hdr    = { padding:'12px 16px', borderBottom:'1px solid rgba(255,255,255,0.06)', fontSize:13, fontWeight:500 };
const inp    = { background:'#16213e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'7px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%', boxSizing:'border-box' };
const btnPdf = { padding:'5px 12px', borderRadius:6, border:'none', background:'#e94560', color:'white', fontSize:11, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnPrint={ padding:'5px 12px', borderRadius:6, background:'rgba(255,255,255,0.07)', color:'#e8e8f0', border:'1px solid rgba(255,255,255,0.1)', fontSize:11, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
