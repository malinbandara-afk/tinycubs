import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { jobOrdersApi, workersApi, productsApi, invoicesApi } from '../services/api';
import toast from 'react-hot-toast';

export default function JobOrderForm() {
  const navigate = useNavigate();
  const qc       = useQueryClient();

  const [form, setForm] = useState({
    title: '', description: '', worker_id: '',
    invoice_id: '', quantity: 1,
    due_date: '', notes: '',
    items: [{ product_id: '', description: '', quantity: 1 }],
  });

  const { data: wData } = useQuery({ queryKey:['workers'], queryFn: () => workersApi.list().then(r=>r.data) });
  const { data: pData } = useQuery({ queryKey:['products-list'], queryFn: () => productsApi.list({ paginate:'false', is_active:true }).then(r=>r.data) });
  const { data: iData } = useQuery({ queryKey:['invoices-open'], queryFn: () => invoicesApi.list({ status:'sent', per_page:50 }).then(r=>r.data) });

  const workers  = Array.isArray(wData) ? wData : wData?.data ?? [];
  const products = Array.isArray(pData) ? pData : pData?.data ?? [];
  const invoices = iData?.data ?? [];

  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const updateItem = (idx, field, val) => {
    const items = [...form.items];
    items[idx] = { ...items[idx], [field]: val };
    if (field === 'product_id' && val) {
      const p = products.find(p => p.id == val);
      if (p) items[idx].description = `${p.name} — ${p.size} / ${p.color}`;
    }
    setForm(f => ({ ...f, items }));
  };

  const saveMut = useMutation({
    mutationFn: () => jobOrdersApi.create(form),
    onSuccess: (res) => {
      toast.success('Job order created!');
      qc.invalidateQueries({ queryKey:['job-orders'] });
      navigate('/production');
    },
    onError: (e) => toast.error(e.response?.data?.message || 'Failed to create job order'),
  });

  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:600, margin:0 }}>New Job Order</h1>
          <p style={{ fontSize:12, color:'#8888aa', margin:'4px 0 0' }}>Create a production job for workers</p>
        </div>
        <button onClick={()=>navigate('/production')} style={btnSec}>← Back</button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.3fr 1fr', gap:16 }}>
        {/* Left */}
        <div>
          <div style={{ ...crd, marginBottom:16 }}>
            <div style={hdr}>Job Details</div>
            <div style={{ padding:16 }}>
              <div style={fg}>
                <label style={lbl}>Job Title *</label>
                <input value={form.title} onChange={e=>set('title',e.target.value)} required placeholder="e.g. T-Shirt Print Bulk Order" style={inp} />
              </div>
              <div style={fg}>
                <label style={lbl}>Description</label>
                <textarea value={form.description} onChange={e=>set('description',e.target.value)} rows={2} placeholder="Colour, design notes, special instructions..." style={{ ...inp, resize:'vertical' }} />
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                <div style={fg}>
                  <label style={lbl}>Total Quantity *</label>
                  <input type="number" value={form.quantity} min={1} onChange={e=>set('quantity',e.target.value)} style={inp} />
                </div>
                <div style={fg}>
                  <label style={lbl}>Due Date</label>
                  <input type="date" value={form.due_date} onChange={e=>set('due_date',e.target.value)} style={inp} />
                </div>
              </div>
              <div style={fg}>
                <label style={lbl}>Notes</label>
                <textarea value={form.notes} onChange={e=>set('notes',e.target.value)} rows={2} style={{ ...inp, resize:'vertical' }} />
              </div>
            </div>
          </div>

          {/* Items */}
          <div style={crd}>
            <div style={{ ...hdr, justifyContent:'space-between' }}>
              <span>Items to Produce</span>
              <button type="button" onClick={()=>setForm(f=>({...f,items:[...f.items,{product_id:'',description:'',quantity:1}]}))} style={{ ...btnSec, padding:'3px 10px', fontSize:11 }}>+ Add Item</button>
            </div>
            <div style={{ padding:16 }}>
              {form.items.map((item,idx)=>(
                <div key={idx} style={{ display:'grid', gridTemplateColumns:'1fr 2fr 80px 28px', gap:8, marginBottom:10, alignItems:'start' }}>
                  <div>
                    {idx===0 && <label style={lbl}>Product</label>}
                    <select value={item.product_id} onChange={e=>updateItem(idx,'product_id',e.target.value)} style={sel}>
                      <option value="">— none —</option>
                      {products.map(p=><option key={p.id} value={p.id}>{p.name} ({p.size}/{p.color})</option>)}
                    </select>
                  </div>
                  <div>
                    {idx===0 && <label style={lbl}>Description *</label>}
                    <input value={item.description} onChange={e=>updateItem(idx,'description',e.target.value)} required placeholder="What to produce" style={inp} />
                  </div>
                  <div>
                    {idx===0 && <label style={lbl}>Qty</label>}
                    <input type="number" value={item.quantity} min={1} onChange={e=>updateItem(idx,'quantity',e.target.value)} style={inp} />
                  </div>
                  <div style={{ paddingTop: idx===0 ? 20 : 0 }}>
                    {form.items.length>1 && (
                      <button type="button" onClick={()=>setForm(f=>({...f,items:f.items.filter((_,i)=>i!==idx)}))} style={{ background:'none', border:'none', color:'#ff4757', cursor:'pointer', fontSize:14 }}>✕</button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right */}
        <div>
          <div style={{ ...crd, marginBottom:16 }}>
            <div style={hdr}>Assignment</div>
            <div style={{ padding:16 }}>
              <div style={fg}>
                <label style={lbl}>Assign to Worker</label>
                <select value={form.worker_id} onChange={e=>set('worker_id',e.target.value)} style={sel}>
                  <option value="">— Unassigned —</option>
                  {workers.filter(w=>w.is_active).map(w=>(
                    <option key={w.id} value={w.id}>{w.name}{w.specialty?` (${w.specialty})`:''}</option>
                  ))}
                </select>
              </div>
              <div style={fg}>
                <label style={lbl}>Linked Invoice (optional)</label>
                <select value={form.invoice_id} onChange={e=>set('invoice_id',e.target.value)} style={sel}>
                  <option value="">— No linked invoice —</option>
                  {invoices.map(inv=>(
                    <option key={inv.id} value={inv.id}>#{inv.invoice_number} — {inv.customer?.name}</option>
                  ))}
                </select>
                <div style={{ fontSize:10, color:'#8888aa', marginTop:4 }}>Link to a sales order for tracking</div>
              </div>
            </div>
          </div>

          {/* Workers list */}
          <div style={crd}>
            <div style={hdr}>Available Workers</div>
            <div style={{ padding:'8px 0' }}>
              {workers.length===0 && <div style={{ padding:'12px 16px', fontSize:12, color:'#8888aa' }}>No workers added yet.</div>}
              {workers.map(w=>(
                <div key={w.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 16px', borderBottom:'1px solid rgba(255,255,255,0.04)', cursor:'pointer' }}
                  onClick={()=>set('worker_id', form.worker_id==w.id?'':w.id)}
                >
                  <div style={{
                    width:30, height:30, borderRadius:'50%',
                    background: form.worker_id==w.id ? 'rgba(233,69,96,0.2)' : 'rgba(84,160,255,0.15)',
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:11, fontWeight:600,
                    color: form.worker_id==w.id ? '#e94560' : '#54a0ff',
                    border: form.worker_id==w.id ? '2px solid #e94560' : '2px solid transparent',
                    transition:'all 0.15s',
                  }}>
                    {w.name.charAt(0)}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:12, fontWeight:500 }}>{w.name}</div>
                    {w.specialty && <div style={{ fontSize:10, color:'#8888aa' }}>{w.specialty}</div>}
                  </div>
                  {!w.is_active && <span style={{ fontSize:9, color:'#555', background:'rgba(255,255,255,0.05)', padding:'1px 6px', borderRadius:10 }}>Inactive</span>}
                  {form.worker_id==w.id && <span style={{ fontSize:16, color:'#e94560' }}>✓</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:20 }}>
        <button onClick={()=>navigate('/production')} style={btnSec}>Cancel</button>
        <button onClick={()=>saveMut.mutate()} disabled={saveMut.isPending||!form.title} style={btnPri}>
          {saveMut.isPending ? 'Creating...' : 'Create Job Order'}
        </button>
      </div>
    </div>
  );
}

const crd  = { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, overflow:'hidden' };
const hdr  = { padding:'12px 16px', borderBottom:'1px solid rgba(255,255,255,0.06)', fontSize:13, fontWeight:500, display:'flex', alignItems:'center', justifyContent:'space-between' };
const fg   = { marginBottom:12 };
const lbl  = { display:'block', fontSize:11, color:'#8888aa', marginBottom:4, fontWeight:500 };
const inp  = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%', boxSizing:'border-box' };
const sel  = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%' };
const btnPri = { padding:'9px 20px', borderRadius:7, border:'none', background:'#e94560', color:'white', fontSize:12, fontWeight:500, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSec = { padding:'9px 16px', borderRadius:7, background:'rgba(255,255,255,0.07)', color:'#e8e8f0', border:'1px solid rgba(255,255,255,0.1)', fontSize:12, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
