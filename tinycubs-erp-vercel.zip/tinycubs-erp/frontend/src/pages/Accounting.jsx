import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { expensesApi, reportsApi } from '../services/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from 'recharts';
import toast from 'react-hot-toast';

const EXP_CATEGORIES = ['cost_of_goods','salaries','rent','utilities','marketing','transport','equipment','other'];
const PAY_METHODS    = ['cash','bank_transfer','online','cheque'];

function ExpenseModal({ onClose, onSave }) {
  const [form, setForm] = useState({ title:'', category:'cost_of_goods', amount:'', payment_method:'cash', expense_date: new Date().toISOString().slice(0,10), notes:'' });
  const mut = useMutation({
    mutationFn: () => expensesApi.create(form),
    onSuccess: () => { toast.success('Expense recorded!'); onSave(); onClose(); },
    onError:   () => toast.error('Failed to save expense'),
  });
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  return (
    <div style={overlay}>
      <div style={modal}>
        <h3 style={{ margin:'0 0 16px', fontSize:15 }}>Record Expense</h3>
        <div style={fg}><label style={lbl}>Title *</label><input value={form.title} onChange={e=>set('title',e.target.value)} required placeholder="e.g. Fabric purchase" style={inp} /></div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
          <div style={fg}>
            <label style={lbl}>Category</label>
            <select value={form.category} onChange={e=>set('category',e.target.value)} style={sel}>
              {EXP_CATEGORIES.map(c=><option key={c} value={c}>{c.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase())}</option>)}
            </select>
          </div>
          <div style={fg}><label style={lbl}>Amount (Rs) *</label><input type="number" value={form.amount} min={0} onChange={e=>set('amount',e.target.value)} required style={inp} /></div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
          <div style={fg}>
            <label style={lbl}>Payment Method</label>
            <select value={form.payment_method} onChange={e=>set('payment_method',e.target.value)} style={sel}>
              {PAY_METHODS.map(m=><option key={m} value={m}>{m.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase())}</option>)}
            </select>
          </div>
          <div style={fg}><label style={lbl}>Date *</label><input type="date" value={form.expense_date} onChange={e=>set('expense_date',e.target.value)} required style={inp} /></div>
        </div>
        <div style={fg}><label style={lbl}>Notes</label><textarea value={form.notes} onChange={e=>set('notes',e.target.value)} rows={2} style={{ ...inp, resize:'vertical' }} /></div>
        <div style={{ display:'flex', gap:8, marginTop:8 }}>
          <button onClick={onClose} style={btnSec}>Cancel</button>
          <button onClick={()=>mut.mutate()} disabled={!form.title||!form.amount||mut.isPending} style={btnPri}>{mut.isPending?'Saving...':'Save Expense'}</button>
        </div>
      </div>
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:'#16213e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:8, padding:'8px 12px', fontSize:12 }}>
      <div style={{ color:'#8888aa', marginBottom:4 }}>{label}</div>
      {payload.map(p=>(
        <div key={p.name} style={{ color:p.color }}>Rs {Math.round(p.value).toLocaleString()}</div>
      ))}
    </div>
  );
};

export default function Accounting() {
  const qc = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [dateFrom, setDateFrom]   = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0,10));
  const [dateTo,   setDateTo]     = useState(new Date().toISOString().slice(0,10));
  const [expPage,  setExpPage]    = useState(1);

  const { data: pl } = useQuery({
    queryKey: ['pl', dateFrom, dateTo],
    queryFn: () => reportsApi.profitLoss({ date_from:dateFrom, date_to:dateTo }).then(r=>r.data),
  });

  const { data: salesChart } = useQuery({
    queryKey: ['chart-daily', dateFrom, dateTo],
    queryFn: () => import('../services/api').then(m=>m.default.get('/dashboard/chart',{params:{period:'daily'}})).then(r=>r.data),
  });

  const { data: expData, refetch } = useQuery({
    queryKey: ['expenses', expPage, dateFrom, dateTo],
    queryFn: () => expensesApi.list({ page:expPage, per_page:15, date_from:dateFrom, date_to:dateTo }).then(r=>r.data),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => expensesApi.delete(id),
    onSuccess: () => { toast.success('Expense deleted'); refetch(); },
  });

  const expenses    = expData?.data ?? [];
  const revenue     = parseFloat(pl?.revenue || 0);
  const totalExp    = parseFloat(pl?.total_expenses || 0);
  const netProfit   = parseFloat(pl?.net_profit || 0);
  const margin      = parseFloat(pl?.margin_pct || 0);

  const expBreakdown = pl?.expenses
    ? Object.entries(pl.expenses).map(([cat,total])=>({
        name: cat.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase()),
        total: parseFloat(total),
      })).sort((a,b)=>b.total-a.total)
    : [];

  const chartData = (salesChart || []).slice(-14);

  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:600, margin:0, letterSpacing:-0.5 }}>Accounting & Finance</h1>
          <p style={{ fontSize:12, color:'#8888aa', margin:'4px 0 0' }}>P&L, cash flow & expense tracking</p>
        </div>
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          <input type="date" value={dateFrom} onChange={e=>setDateFrom(e.target.value)} style={{ ...inp, width:140 }} />
          <span style={{ color:'#8888aa', fontSize:12 }}>to</span>
          <input type="date" value={dateTo} onChange={e=>setDateTo(e.target.value)} style={{ ...inp, width:140 }} />
          <button onClick={()=>setShowModal(true)} style={btnPri}>+ Add Expense</button>
        </div>
      </div>

      {/* P&L Summary Cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:20 }}>
        {[
          { label:'Total Revenue',  val:`Rs ${Math.round(revenue).toLocaleString()}`,     color:'#00d4aa', border:'#00d4aa' },
          { label:'Total Expenses', val:`Rs ${Math.round(totalExp).toLocaleString()}`,    color:'#ff4757', border:'#ff4757' },
          { label:'Net Profit',     val:`Rs ${Math.round(netProfit).toLocaleString()}`,   color:netProfit>=0?'#54a0ff':'#ff4757', border:netProfit>=0?'#54a0ff':'#ff4757' },
          { label:'Profit Margin',  val:`${margin.toFixed(1)}%`,                          color:'#a29bfe', border:'#a29bfe' },
        ].map(s=>(
          <div key={s.label} style={{ background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderTop:`3px solid ${s.border}`, borderRadius:12, padding:16 }}>
            <div style={{ fontSize:10, color:'#8888aa', marginBottom:6, textTransform:'uppercase', letterSpacing:0.5 }}>{s.label}</div>
            <div style={{ fontSize:22, fontWeight:700, color:s.color }}>{s.val}</div>
          </div>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.6fr 1fr', gap:16, marginBottom:16 }}>
        {/* Revenue Chart */}
        <div style={crd}>
          <div style={hdr}>Daily Revenue — Last 14 Days</div>
          <div style={{ padding:'16px', height:200 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top:0, right:0, bottom:0, left:0 }}>
                <XAxis dataKey="period" tick={{ fill:'#555566', fontSize:10 }} tickFormatter={d=>d?.slice(5)} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip content={<CustomTooltip />} cursor={{ fill:'rgba(255,255,255,0.04)' }} />
                <Bar dataKey="revenue" fill="#e94560" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Expense Breakdown */}
        <div style={crd}>
          <div style={hdr}>Expense Breakdown</div>
          <div style={{ padding:16 }}>
            {expBreakdown.length === 0
              ? <div style={{ fontSize:12, color:'#8888aa' }}>No expenses this period.</div>
              : expBreakdown.map(e=>(
                <div key={e.name} style={{ marginBottom:10 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:4 }}>
                    <span>{e.name}</span><span style={{ color:'#ff4757', fontWeight:500 }}>Rs {Math.round(e.total).toLocaleString()}</span>
                  </div>
                  <div style={{ height:4, background:'rgba(255,255,255,0.06)', borderRadius:10, overflow:'hidden' }}>
                    <div style={{ height:'100%', width:`${totalExp?Math.min(100,(e.total/totalExp)*100):0}%`, background:'#ff4757', borderRadius:10 }} />
                  </div>
                </div>
              ))
            }
          </div>
        </div>
      </div>

      {/* Expenses Table */}
      <div style={crd}>
        <div style={{ ...hdr, justifyContent:'space-between' }}>
          <span>Expense Records</span>
          <span style={{ fontSize:11, color:'#8888aa' }}>{expData?.total ?? 0} entries</span>
        </div>
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
            <thead>
              <tr>{['Date','Title','Category','Method','Amount',''].map(h=><th key={h} style={th}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {expenses.length===0 ? (
                <tr><td colSpan={6} style={{ textAlign:'center', padding:28, color:'#8888aa' }}>No expenses found for this period.</td></tr>
              ) : expenses.map(e=>(
                <tr key={e.id}>
                  <td style={td}>{e.expense_date}</td>
                  <td style={td}><div style={{ fontWeight:500 }}>{e.title}</div>{e.notes&&<div style={{ fontSize:10, color:'#8888aa' }}>{e.notes}</div>}</td>
                  <td style={td}><span style={{ fontSize:10, background:'rgba(255,71,87,0.1)', color:'#ff4757', padding:'2px 8px', borderRadius:10 }}>{e.category.replace(/_/g,' ')}</span></td>
                  <td style={td}>{e.payment_method.replace(/_/g,' ')}</td>
                  <td style={{ ...td, color:'#ff4757', fontWeight:600 }}>Rs {parseFloat(e.amount).toLocaleString()}</td>
                  <td style={td}><button onClick={()=>{ if(confirm('Delete this expense?')) deleteMut.mutate(e.id); }} style={{ background:'none', border:'none', color:'#555', cursor:'pointer', fontSize:13 }}>✕</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {expData?.last_page > 1 && (
          <div style={{ padding:'12px 16px', borderTop:'1px solid rgba(255,255,255,0.06)', display:'flex', gap:8 }}>
            <button onClick={()=>setExpPage(p=>Math.max(1,p-1))} disabled={expPage===1} style={btnSm}>← Prev</button>
            <span style={{ fontSize:12, color:'#8888aa', alignSelf:'center' }}>Page {expPage} of {expData.last_page}</span>
            <button onClick={()=>setExpPage(p=>p+1)} disabled={expPage===expData.last_page} style={btnSm}>Next →</button>
          </div>
        )}
      </div>

      {showModal && <ExpenseModal onClose={()=>setShowModal(false)} onSave={()=>qc.invalidateQueries({queryKey:['expenses']})} />}
    </div>
  );
}

const overlay = { position:'fixed', inset:0, background:'rgba(0,0,0,0.75)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:200 };
const modal   = { background:'#16213e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:12, padding:24, width:440 };
const crd     = { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, overflow:'hidden' };
const hdr     = { padding:'12px 16px', borderBottom:'1px solid rgba(255,255,255,0.06)', fontSize:13, fontWeight:500, display:'flex', alignItems:'center' };
const fg      = { marginBottom:12 };
const lbl     = { display:'block', fontSize:11, color:'#8888aa', marginBottom:4, fontWeight:500 };
const inp     = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%', boxSizing:'border-box' };
const sel     = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%' };
const th      = { padding:'9px 12px', textAlign:'left', fontSize:10, fontWeight:600, textTransform:'uppercase', letterSpacing:'0.8px', color:'#555566', borderBottom:'1px solid rgba(255,255,255,0.06)' };
const td      = { padding:'10px 12px', borderBottom:'1px solid rgba(255,255,255,0.04)', verticalAlign:'middle', fontSize:12 };
const btnPri  = { padding:'8px 16px', borderRadius:7, border:'none', background:'#e94560', color:'white', fontSize:12, fontWeight:500, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSec  = { padding:'8px 14px', borderRadius:7, background:'rgba(255,255,255,0.07)', color:'#e8e8f0', border:'1px solid rgba(255,255,255,0.1)', fontSize:12, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSm   = { padding:'5px 12px', borderRadius:6, background:'transparent', color:'#8888aa', border:'1px solid rgba(255,255,255,0.1)', fontSize:11, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
