import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [email, setEmail]       = useState('admin@tinycubs.lk');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const { login }               = useAuthStore();
  const navigate                = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#1a1a2e',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "'Sora', sans-serif",
    }}>
      <div style={{
        background: '#16213e',
        border: '1px solid rgba(255,255,255,0.08)',
        borderRadius: 16,
        padding: '40px 36px',
        width: 360,
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 56, height: 56,
            background: 'linear-gradient(135deg, #e94560, #c0392b)',
            borderRadius: 14,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 28, margin: '0 auto 12px',
          }}>🧸</div>
          <div style={{ fontSize: 22, fontWeight: 600, color: '#e8e8f0' }}>
            Tiny<span style={{ color: '#e94560' }}>Cubs</span>.lk
          </div>
          <div style={{ fontSize: 12, color: '#8888aa', marginTop: 4 }}>ERP System</div>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 11, color: '#8888aa', marginBottom: 6, fontWeight: 500 }}>
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              style={{
                width: '100%', padding: '10px 14px',
                background: '#1a1a2e', border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: 8, color: '#e8e8f0', fontSize: 13,
                fontFamily: "'Sora', sans-serif", outline: 'none',
                boxSizing: 'border-box',
              }}
            />
          </div>

          <div style={{ marginBottom: 24 }}>
            <label style={{ display: 'block', fontSize: 11, color: '#8888aa', marginBottom: 6, fontWeight: 500 }}>
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              placeholder="Enter your password"
              style={{
                width: '100%', padding: '10px 14px',
                background: '#1a1a2e', border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: 8, color: '#e8e8f0', fontSize: 13,
                fontFamily: "'Sora', sans-serif", outline: 'none',
                boxSizing: 'border-box',
              }}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%', padding: '11px',
              background: loading ? '#555' : '#e94560',
              border: 'none', borderRadius: 8,
              color: 'white', fontSize: 13, fontWeight: 600,
              fontFamily: "'Sora', sans-serif",
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'background 0.15s',
            }}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <div style={{
          marginTop: 24,
          padding: '12px 14px',
          background: 'rgba(84,160,255,0.08)',
          border: '1px solid rgba(84,160,255,0.2)',
          borderRadius: 8,
          fontSize: 11,
          color: '#8888aa',
          lineHeight: 1.7,
        }}>
          <strong style={{ color: '#54a0ff' }}>Default logins:</strong><br />
          admin@tinycubs.lk · Admin@1234<br />
          sales@tinycubs.lk · Sales@1234
        </div>

        <div style={{ textAlign: 'center', marginTop: 20, fontSize: 11, color: '#555' }}>
          TinyCubs ERP v1.0 · Powered by Laravel + React
        </div>
      </div>
    </div>
  );
}
