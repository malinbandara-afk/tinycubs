export { Barcode as default } from './remaining_pages';
