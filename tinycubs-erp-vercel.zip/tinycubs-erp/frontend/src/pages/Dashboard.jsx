export { Dashboard as default } from './remaining_pages';
