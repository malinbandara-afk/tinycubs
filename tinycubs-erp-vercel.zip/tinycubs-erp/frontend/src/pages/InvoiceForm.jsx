import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { invoicesApi, customersApi, productsApi, downloadBlob } from '../services/api';
import toast from 'react-hot-toast';

export default function InvoiceForm() {
  const { id }        = useParams();
  const [params]      = useSearchParams();
  const navigate      = useNavigate();
  const qc            = useQueryClient();
  const isEdit        = Boolean(id);
  const type          = params.get('type') || 'invoice';

  const [form, setForm] = useState({
    customer_id:  '',
    type,
    invoice_date: new Date().toISOString().slice(0, 10),
    due_date:     '',
    discount:     0,
    notes:        '',
    items:        [{ description: '', product_id: '', quantity: 1, unit_price: 0 }],
  });
  const [payModal,  setPayModal]  = useState(false);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('cash');
  const [saving,    setSaving]    = useState(false);

  // Load existing invoice
  const { data: invoice } = useQuery({
    queryKey: ['invoice', id],
    queryFn: () => invoicesApi.get(id).then(r => r.data),
    enabled:  isEdit,
  });

  useEffect(() => {
    if (invoice) {
      setForm({
        customer_id:  invoice.customer_id,
        type:         invoice.type,
        invoice_date: invoice.invoice_date,
        due_date:     invoice.due_date || '',
        discount:     invoice.discount,
        notes:        invoice.notes || '',
        items: invoice.items.map(i => ({
          description: i.description,
          product_id:  i.product_id || '',
          quantity:    i.quantity,
          unit_price:  i.unit_price,
        })),
      });
    }
  }, [invoice]);

  const { data: customersData } = useQuery({
    queryKey: ['customers-list'],
    queryFn: () => customersApi.list({ paginate: 'false' }).then(r => r.data),
  });
  const { data: productsData } = useQuery({
    queryKey: ['products-list'],
    queryFn: () => productsApi.list({ paginate: 'false', is_active: true }).then(r => r.data),
  });

  const customers = Array.isArray(customersData) ? customersData : customersData?.data ?? [];
  const products  = Array.isArray(productsData)  ? productsData  : productsData?.data  ?? [];

  // Line item helpers
  const updateItem = (idx, field, value) => {
    const items = [...form.items];
    items[idx] = { ...items[idx], [field]: value };

    // Auto-fill price from product
    if (field === 'product_id' && value) {
      const p = products.find(p => p.id == value);
      if (p) {
        items[idx].description = `${p.name} — ${p.size} / ${p.color}`;
        items[idx].unit_price  = p.selling_price;
      }
    }
    setForm(f => ({ ...f, items }));
  };

  const addItem    = () => setForm(f => ({ ...f, items: [...f.items, { description: '', product_id: '', quantity: 1, unit_price: 0 }] }));
  const removeItem = (idx) => setForm(f => ({ ...f, items: f.items.filter((_, i) => i !== idx) }));

  const subtotal = form.items.reduce((s, i) => s + (i.quantity * i.unit_price), 0);
  const total    = Math.max(0, subtotal - (parseFloat(form.discount) || 0));

  // Save
  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, items: form.items.filter(i => i.description) };
      const res = isEdit
        ? await invoicesApi.update(id, payload)
        : await invoicesApi.create(payload);
      toast.success(isEdit ? 'Invoice updated!' : 'Invoice created!');
      qc.invalidateQueries({ queryKey: ['invoices'] });
      navigate(`/sales/${res.data.id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  // Record payment
  const handlePayment = async () => {
    try {
      await invoicesApi.addPayment(id, {
        amount:       parseFloat(payAmount),
        method:       payMethod,
        payment_date: new Date().toISOString().slice(0, 10),
      });
      toast.success('Payment recorded!');
      qc.invalidateQueries({ queryKey: ['invoice', id] });
      qc.invalidateQueries({ queryKey: ['invoices'] });
      setPayModal(false);
      setPayAmount('');
    } catch { toast.error('Payment failed'); }
  };

  const handlePdf = async () => {
    const res = await invoicesApi.pdf(id);
    downloadBlob(res, `TinyCubs-${invoice?.invoice_number}.pdf`);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 600, margin: 0 }}>
            {isEdit ? `Invoice #${invoice?.invoice_number}` : `New ${type.charAt(0).toUpperCase() + type.slice(1)}`}
          </h1>
          <p style={{ fontSize: 12, color: '#8888aa', margin: '4px 0 0' }}>
            {isEdit ? `Status: ${invoice?.status}` : 'Fill in the details below'}
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {isEdit && invoice?.status !== 'paid' && (
            <button onClick={() => setPayModal(true)} style={styles.btnSuccess}>💵 Record Payment</button>
          )}
          {isEdit && (
            <button onClick={handlePdf} style={styles.btnSecondary}>🖨 PDF</button>
          )}
          <button onClick={() => navigate('/sales')} style={styles.btnSecondary}>← Back</button>
        </div>
      </div>

      <form onSubmit={handleSave}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          {/* Customer */}
          <div style={styles.card}>
            <div style={styles.cardHeader}>Customer</div>
            <div style={{ padding: 16 }}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Select Customer</label>
                <select value={form.customer_id} onChange={e => setForm(f => ({ ...f, customer_id: e.target.value }))} required style={styles.select}>
                  <option value="">— Choose customer —</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>{c.name} {c.phone ? `· ${c.phone}` : ''}</option>
                  ))}
                </select>
              </div>
              <div style={styles.formRow}>
                <div style={styles.formGroup}>
                  <label style={styles.label}>Invoice Date</label>
                  <input type="date" value={form.invoice_date} onChange={e => setForm(f => ({ ...f, invoice_date: e.target.value }))} required style={styles.input} />
                </div>
                <div style={styles.formGroup}>
                  <label style={styles.label}>Due Date</label>
                  <input type="date" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} style={styles.input} />
                </div>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Notes</label>
                <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} style={{ ...styles.input, resize: 'vertical' }} />
              </div>
            </div>
          </div>

          {/* Summary */}
          <div style={styles.card}>
            <div style={styles.cardHeader}>Summary</div>
            <div style={{ padding: 16 }}>
              {invoice && (
                <div style={{ marginBottom: 12 }}>
                  {[
                    { label: 'Total', value: `Rs ${parseFloat(invoice.total).toLocaleString()}`, color: '#e8e8f0' },
                    { label: 'Paid',  value: `Rs ${parseFloat(invoice.amount_paid).toLocaleString()}`, color: '#00d4aa' },
                    { label: 'Balance', value: `Rs ${parseFloat(invoice.balance_due).toLocaleString()}`, color: parseFloat(invoice.balance_due) > 0 ? '#ff4757' : '#00d4aa' },
                  ].map(s => (
                    <div key={s.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                      <span style={{ fontSize: 12, color: '#8888aa' }}>{s.label}</span>
                      <span style={{ fontSize: 13, fontWeight: 600, color: s.color }}>{s.value}</span>
                    </div>
                  ))}
                </div>
              )}
              {!isEdit && (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}>
                    <span style={{ fontSize: 12, color: '#8888aa' }}>Subtotal</span>
                    <span style={{ fontSize: 12 }}>Rs {subtotal.toLocaleString()}</span>
                  </div>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Discount (Rs)</label>
                    <input type="number" value={form.discount} min={0} onChange={e => setForm(f => ({ ...f, discount: e.target.value }))} style={styles.input} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderTop: '1px solid rgba(255,255,255,0.1)', marginTop: 4 }}>
                    <span style={{ fontSize: 13, fontWeight: 600 }}>Total</span>
                    <span style={{ fontSize: 16, fontWeight: 700, color: '#e94560' }}>Rs {total.toLocaleString()}</span>
                  </div>
                </div>
              )}

              {/* Payment history */}
              {invoice?.payments?.length > 0 && (
                <div style={{ marginTop: 12 }}>
                  <div style={{ fontSize: 11, color: '#8888aa', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 }}>Payments</div>
                  {invoice.payments.map(p => (
                    <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, padding: '4px 0', color: '#8888aa' }}>
                      <span>{p.payment_date} · {p.method.replace('_', ' ')}</span>
                      <span style={{ color: '#00d4aa' }}>+ Rs {parseFloat(p.amount).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Line Items */}
        <div style={{ ...styles.card, marginBottom: 16 }}>
          <div style={{ ...styles.cardHeader, justifyContent: 'space-between' }}>
            <span>Line Items</span>
            <button type="button" onClick={addItem} style={{ ...styles.btnSecondary, padding: '4px 12px', fontSize: 11 }}>+ Add Item</button>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr>
                  {['Product (optional)', 'Description', 'Qty', 'Unit Price', 'Total', ''].map(h => (
                    <th key={h} style={styles.th}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {form.items.map((item, idx) => (
                  <tr key={idx}>
                    <td style={styles.td}>
                      <select value={item.product_id} onChange={e => updateItem(idx, 'product_id', e.target.value)} style={{ ...styles.select, width: 160 }}>
                        <option value="">— none —</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name} ({p.size}/{p.color}) — Stock: {p.stock_qty}</option>)}
                      </select>
                    </td>
                    <td style={styles.td}>
                      <input value={item.description} onChange={e => updateItem(idx, 'description', e.target.value)} required placeholder="Description" style={{ ...styles.input, width: '100%' }} />
                    </td>
                    <td style={styles.td}>
                      <input type="number" value={item.quantity} min={1} onChange={e => updateItem(idx, 'quantity', parseInt(e.target.value) || 1)} style={{ ...styles.input, width: 60 }} />
                    </td>
                    <td style={styles.td}>
                      <input type="number" value={item.unit_price} min={0} step={0.01} onChange={e => updateItem(idx, 'unit_price', parseFloat(e.target.value) || 0)} style={{ ...styles.input, width: 100 }} />
                    </td>
                    <td style={{ ...styles.td, fontWeight: 600 }}>
                      Rs {(item.quantity * item.unit_price).toLocaleString()}
                    </td>
                    <td style={styles.td}>
                      {form.items.length > 1 && (
                        <button type="button" onClick={() => removeItem(idx)} style={{ background: 'none', border: 'none', color: '#ff4757', cursor: 'pointer', fontSize: 14 }}>✕</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {!isEdit && (
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
            <button type="button" onClick={() => navigate('/sales')} style={styles.btnSecondary}>Cancel</button>
            <button type="submit" disabled={saving} style={styles.btnPrimary}>
              {saving ? 'Saving...' : `Create ${type.charAt(0).toUpperCase() + type.slice(1)}`}
            </button>
          </div>
        )}
      </form>

      {/* Payment Modal */}
      {payModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100,
        }}>
          <div style={{ background: '#16213e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, padding: 24, width: 320 }}>
            <h3 style={{ margin: '0 0 16px', fontSize: 15 }}>Record Payment</h3>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, color: '#8888aa', marginBottom: 4 }}>Balance Due</div>
              <div style={{ fontSize: 18, fontWeight: 700, color: '#ff4757' }}>Rs {parseFloat(invoice?.balance_due || 0).toLocaleString()}</div>
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Amount (Rs)</label>
              <input type="number" value={payAmount} onChange={e => setPayAmount(e.target.value)} max={invoice?.balance_due} style={styles.input} autoFocus />
            </div>
            <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
              {[25, 50, 60, 75, 100].map(pct => (
                <button key={pct} type="button" onClick={() => setPayAmount(Math.round(invoice?.balance_due * pct / 100))} style={{ ...styles.btnSecondary, padding: '3px 8px', fontSize: 10 }}>
                  {pct}%
                </button>
              ))}
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Payment Method</label>
              <select value={payMethod} onChange={e => setPayMethod(e.target.value)} style={styles.select}>
                <option value="cash">Cash</option>
                <option value="bank_transfer">Bank Transfer</option>
                <option value="online">Online</option>
                <option value="cheque">Cheque</option>
              </select>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
              <button onClick={() => setPayModal(false)} style={{ ...styles.btnSecondary, flex: 1 }}>Cancel</button>
              <button onClick={handlePayment} disabled={!payAmount} style={{ ...styles.btnPrimary, flex: 1 }}>Confirm Payment</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  card:         { background: '#16213e', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12, overflow: 'hidden', marginBottom: 0 },
  cardHeader:   { padding: '12px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)', fontSize: 13, fontWeight: 500, display: 'flex', alignItems: 'center' },
  formGroup:    { marginBottom: 12 },
  formRow:      { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 },
  label:        { display: 'block', fontSize: 11, color: '#8888aa', marginBottom: 4, fontWeight: 500 },
  input:        { background: '#1a1a2e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 7, color: '#e8e8f0', padding: '8px 12px', fontSize: 12, fontFamily: "'Sora', sans-serif", outline: 'none', width: '100%', boxSizing: 'border-box' },
  select:       { background: '#1a1a2e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 7, color: '#e8e8f0', padding: '8px 12px', fontSize: 12, fontFamily: "'Sora', sans-serif", outline: 'none', width: '100%' },
  th:           { padding: '8px 12px', textAlign: 'left', fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.8px', color: '#555566', borderBottom: '1px solid rgba(255,255,255,0.06)' },
  td:           { padding: '8px 12px', borderBottom: '1px solid rgba(255,255,255,0.04)', verticalAlign: 'middle' },
  btnPrimary:   { padding: '8px 18px', borderRadius: 7, border: 'none', background: '#e94560', color: 'white', fontSize: 12, fontWeight: 500, cursor: 'pointer', fontFamily: "'Sora', sans-serif" },
  btnSecondary: { padding: '8px 14px', borderRadius: 7, background: 'rgba(255,255,255,0.07)', color: '#e8e8f0', border: '1px solid rgba(255,255,255,0.1)', fontSize: 12, cursor: 'pointer', fontFamily: "'Sora', sans-serif" },
  btnSuccess:   { padding: '8px 14px', borderRadius: 7, background: 'rgba(0,212,170,0.15)', color: '#00d4aa', border: '1px solid rgba(0,212,170,0.3)', fontSize: 12, cursor: 'pointer', fontFamily: "'Sora', sans-serif" },
};
