export { Integrations as default } from './remaining_pages';
