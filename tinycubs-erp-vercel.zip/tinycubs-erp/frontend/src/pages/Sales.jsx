import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { invoicesApi, downloadBlob } from '../services/api';
import toast from 'react-hot-toast';

const STATUS_COLORS = {
  paid:      { bg: 'rgba(0,212,170,0.15)',   color: '#00d4aa' },
  partial:   { bg: 'rgba(255,179,71,0.15)',  color: '#ffb347' },
  sent:      { bg: 'rgba(255,71,87,0.15)',   color: '#ff4757' },
  draft:     { bg: 'rgba(136,136,170,0.15)', color: '#8888aa' },
  cancelled: { bg: 'rgba(136,136,170,0.15)', color: '#555' },
};

const SOURCE_ICON = { manual: '🖊', woocommerce: '🛒', facebook: '📘' };

export default function Sales() {
  const navigate     = useNavigate();
  const qc           = useQueryClient();
  const [search, setSearch]   = useState('');
  const [status, setStatus]   = useState('');
  const [page, setPage]       = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['invoices', search, status, page],
    queryFn: () => invoicesApi.list({ search, status, page, per_page: 20 }).then(r => r.data),
  });

  const whatsappMut = useMutation({
    mutationFn: (id) => invoicesApi.sendWhatsApp(id),
    onSuccess: () => toast.success('Invoice sent via WhatsApp!'),
    onError:   () => toast.error('WhatsApp send failed. Check integration settings.'),
  });

  const handlePdf = async (id, number) => {
    try {
      const res = await invoicesApi.pdf(id);
      downloadBlob(res, `TinyCubs-${number}.pdf`);
    } catch { toast.error('PDF generation failed'); }
  };

  const invoices = data?.data ?? [];

  const stats = {
    total:       data?.total ?? 0,
    paid:        invoices.filter(i => i.status === 'paid').length,
    outstanding: invoices.filter(i => ['sent','partial'].includes(i.status)).reduce((s,i) => s + parseFloat(i.balance_due), 0),
  };

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 600, margin: 0, letterSpacing: -0.5 }}>Sales</h1>
          <p style={{ fontSize: 12, color: '#8888aa', margin: '4px 0 0' }}>Invoices, quotations & payments</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => navigate('/sales/new?type=quotation')} style={styles.btnSecondary}>
            📋 New Quotation
          </button>
          <button onClick={() => navigate('/sales/new')} style={styles.btnPrimary}>
            + New Invoice
          </button>
        </div>
      </div>

      {/* Mini Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 16 }}>
        {[
          { label: 'Total This Month', value: `Rs ${(data?.meta?.total_revenue ?? 0).toLocaleString()}`, color: '#e94560' },
          { label: 'Collected',        value: `Rs ${(data?.meta?.collected ?? 0).toLocaleString()}`,     color: '#00d4aa' },
          { label: 'Outstanding',      value: `Rs ${Math.round(stats.outstanding).toLocaleString()}`,     color: '#ffb347' },
          { label: 'Total Invoices',   value: data?.total ?? 0,                                            color: '#54a0ff' },
        ].map(s => (
          <div key={s.label} style={styles.statCard}>
            <div style={{ fontSize: 10, color: '#8888aa', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>{s.label}</div>
            <div style={{ fontSize: 18, fontWeight: 600, color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 14, alignItems: 'center' }}>
        <input
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(1); }}
          placeholder="Search invoice, customer, phone..."
          style={styles.input}
        />
        {['', 'paid', 'partial', 'sent', 'draft', 'cancelled'].map(s => (
          <button key={s} onClick={() => { setStatus(s); setPage(1); }} style={{
            ...styles.filterBtn,
            ...(status === s ? { borderColor: '#e94560', color: '#e94560', background: 'rgba(233,69,96,0.1)' } : {}),
          }}>
            {s === '' ? 'All' : s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {/* Table */}
      <div style={styles.card}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead>
              <tr>
                {['Invoice', 'Customer', 'Items', 'Total', 'Paid', 'Balance', 'Status', 'Source', 'Actions'].map(h => (
                  <th key={h} style={styles.th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={9} style={{ textAlign: 'center', padding: 32, color: '#8888aa' }}>Loading...</td></tr>
              ) : invoices.length === 0 ? (
                <tr><td colSpan={9} style={{ textAlign: 'center', padding: 32, color: '#8888aa' }}>No invoices found</td></tr>
              ) : invoices.map(inv => (
                <tr key={inv.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/sales/${inv.id}`)}>
                  <td style={styles.td}>
                    <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#8888aa' }}>#{inv.invoice_number}</span>
                  </td>
                  <td style={styles.td}>
                    <div style={{ fontSize: 12 }}>{inv.customer?.name}</div>
                    <div style={{ fontSize: 10, color: '#8888aa' }}>{inv.customer?.phone}</div>
                  </td>
                  <td style={styles.td}>{inv.items?.length ?? '—'} item(s)</td>
                  <td style={{ ...styles.td, fontWeight: 500 }}>Rs {parseFloat(inv.total).toLocaleString()}</td>
                  <td style={{ ...styles.td, color: '#00d4aa' }}>
                    {parseFloat(inv.amount_paid) > 0 ? `Rs ${parseFloat(inv.amount_paid).toLocaleString()}` : '—'}
                  </td>
                  <td style={{ ...styles.td, color: parseFloat(inv.balance_due) > 0 ? '#ff4757' : '#8888aa' }}>
                    {parseFloat(inv.balance_due) > 0 ? `Rs ${parseFloat(inv.balance_due).toLocaleString()}` : '—'}
                  </td>
                  <td style={styles.td}>
                    <span style={{
                      padding: '3px 10px', borderRadius: 20, fontSize: 10, fontWeight: 600,
                      background: STATUS_COLORS[inv.status]?.bg,
                      color: STATUS_COLORS[inv.status]?.color,
                    }}>
                      {inv.status === 'partial'
                        ? `Partial ${Math.round((inv.amount_paid / inv.total) * 100)}%`
                        : inv.status.charAt(0).toUpperCase() + inv.status.slice(1)}
                    </span>
                  </td>
                  <td style={styles.td}>{SOURCE_ICON[inv.source] ?? '🖊'}</td>
                  <td style={styles.td} onClick={e => e.stopPropagation()}>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button onClick={() => handlePdf(inv.id, inv.invoice_number)} style={styles.btnSmall}>
                        🖨 PDF
                      </button>
                      {inv.status !== 'paid' && (
                        <button
                          onClick={() => whatsappMut.mutate(inv.id)}
                          disabled={whatsappMut.isPending}
                          style={{ ...styles.btnSmall, color: '#00d4aa', borderColor: 'rgba(0,212,170,0.3)' }}
                        >
                          💬 WA
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {data?.last_page > 1 && (
          <div style={{ padding: '12px 16px', borderTop: '1px solid rgba(255,255,255,0.06)', display: 'flex', gap: 8, alignItems: 'center' }}>
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} style={styles.btnSmall}>←</button>
            <span style={{ fontSize: 12, color: '#8888aa' }}>Page {page} of {data?.last_page}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={page === data?.last_page} style={styles.btnSmall}>→</button>
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  btnPrimary: {
    padding: '8px 16px', borderRadius: 7, border: 'none',
    background: '#e94560', color: 'white', fontSize: 12,
    fontWeight: 500, cursor: 'pointer', fontFamily: "'Sora', sans-serif",
  },
  btnSecondary: {
    padding: '8px 16px', borderRadius: 7,
    background: 'rgba(255,255,255,0.07)', color: '#e8e8f0',
    border: '1px solid rgba(255,255,255,0.1)', fontSize: 12,
    cursor: 'pointer', fontFamily: "'Sora', sans-serif",
  },
  btnSmall: {
    padding: '4px 10px', borderRadius: 6,
    background: 'transparent', color: '#8888aa',
    border: '1px solid rgba(255,255,255,0.1)', fontSize: 11,
    cursor: 'pointer', fontFamily: "'Sora', sans-serif",
  },
  filterBtn: {
    padding: '5px 12px', borderRadius: 20,
    background: 'transparent', color: '#8888aa',
    border: '1px solid rgba(255,255,255,0.1)', fontSize: 11,
    cursor: 'pointer', fontFamily: "'Sora', sans-serif",
    whiteSpace: 'nowrap',
  },
  card: {
    background: '#16213e',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 12,
    overflow: 'hidden',
  },
  statCard: {
    background: '#16213e',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 10, padding: 12,
  },
  input: {
    background: '#16213e',
    border: '1px solid rgba(255,255,255,0.1)',
    borderRadius: 7, color: '#e8e8f0',
    padding: '7px 12px', fontSize: 12,
    fontFamily: "'Sora', sans-serif",
    outline: 'none', width: 260,
  },
  th: {
    padding: '9px 12px', textAlign: 'left',
    fontSize: 10, fontWeight: 600,
    textTransform: 'uppercase', letterSpacing: '0.8px',
    color: '#555566',
    borderBottom: '1px solid rgba(255,255,255,0.06)',
  },
  td: {
    padding: '10px 12px',
    borderBottom: '1px solid rgba(255,255,255,0.04)',
    verticalAlign: 'middle',
    fontSize: 12,
  },
};
