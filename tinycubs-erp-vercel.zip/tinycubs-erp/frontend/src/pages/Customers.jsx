export { Customers as default } from './remaining_pages';
