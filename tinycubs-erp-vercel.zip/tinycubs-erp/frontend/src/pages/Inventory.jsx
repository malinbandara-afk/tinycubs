import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { productsApi } from '../services/api';
import toast from 'react-hot-toast';

const SIZES   = ['S','M','L','XL','XXL','2-3Y','4-5Y','6-7Y','0-3M','3-6M','6-12M'];
const COLORS  = ['White','Black','Blue','Red','Yellow','Green','Pink','Grey','Navy','Multicolor'];

function StockBadge({ qty, threshold }) {
  if (qty <= 0)          return <span style={badge('#ff4757','rgba(255,71,87,0.15)')}>Out of Stock</span>;
  if (qty <= threshold)  return <span style={badge('#ffb347','rgba(255,179,71,0.15)')}>Low: {qty}</span>;
  return <span style={badge('#00d4aa','rgba(0,212,170,0.15)')}>{qty} in stock</span>;
}
const badge = (color, bg) => ({
  padding: '3px 10px', borderRadius: 20, fontSize: 10, fontWeight: 600, color, background: bg,
});

function StockModal({ product, onClose, onSave }) {
  const [type, setType]   = useState('in');
  const [qty, setQty]     = useState('');
  const [notes, setNotes] = useState('');
  const mut = useMutation({
    mutationFn: () => productsApi.adjustStock(product.id, { type, quantity: parseInt(qty), notes }),
    onSuccess: () => { toast.success(`Stock ${type === 'in' ? 'added' : 'removed'}!`); onSave(); onClose(); },
    onError:   () => toast.error('Stock update failed'),
  });
  return (
    <div style={overlay}>
      <div style={modal}>
        <h3 style={{ margin: '0 0 4px', fontSize: 15 }}>Adjust Stock</h3>
        <p style={{ fontSize: 12, color: '#8888aa', margin: '0 0 16px' }}>{product.name} — {product.size} / {product.color}</p>
        <div style={{ fontSize: 12, marginBottom: 16 }}>
          Current stock: <strong style={{ color: '#54a0ff', fontSize: 16 }}>{product.stock_qty}</strong>
        </div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
          {['in','out','adjustment'].map(t => (
            <button key={t} onClick={() => setType(t)} style={{
              flex: 1, padding: '8px 0', borderRadius: 7, border: '1px solid',
              fontSize: 12, cursor: 'pointer', fontFamily: "'Sora',sans-serif",
              borderColor: type === t ? (t==='in'?'#00d4aa':t==='out'?'#ff4757':'#ffb347') : 'rgba(255,255,255,0.1)',
              background:  type === t ? (t==='in'?'rgba(0,212,170,0.15)':t==='out'?'rgba(255,71,87,0.15)':'rgba(255,179,71,0.15)') : 'transparent',
              color:       type === t ? (t==='in'?'#00d4aa':t==='out'?'#ff4757':'#ffb347') : '#8888aa',
            }}>{t.charAt(0).toUpperCase()+t.slice(1)}</button>
          ))}
        </div>
        <div style={fg}>
          <label style={lbl}>Quantity</label>
          <input type="number" value={qty} min={1} onChange={e => setQty(e.target.value)} style={inp} autoFocus />
        </div>
        <div style={fg}>
          <label style={lbl}>Reference / Notes</label>
          <input value={notes} onChange={e => setNotes(e.target.value)} placeholder="e.g. Purchase order #123" style={inp} />
        </div>
        <div style={{ display:'flex', gap:8, marginTop:16 }}>
          <button onClick={onClose} style={btnSec}>Cancel</button>
          <button onClick={() => mut.mutate()} disabled={!qty || mut.isPending} style={btnPri}>
            {mut.isPending ? 'Saving...' : 'Confirm'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Inventory() {
  const navigate  = useNavigate();
  const qc        = useQueryClient();
  const [search,  setSearch]  = useState('');
  const [catId,   setCatId]   = useState('');
  const [size,    setSize]    = useState('');
  const [color,   setColor]   = useState('');
  const [lowOnly, setLowOnly] = useState(false);
  const [page,    setPage]    = useState(1);
  const [stockModal, setStockModal] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['products', search, catId, size, color, lowOnly, page],
    queryFn: () => productsApi.list({ search, category_id: catId, size, color, low_stock: lowOnly || undefined, page, per_page: 25 }).then(r => r.data),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => productsApi.delete(id),
    onSuccess: () => { toast.success('Product deleted'); qc.invalidateQueries({queryKey:['products']}); },
    onError: (e) => toast.error(e.response?.data?.message || 'Cannot delete'),
  });

  const products = data?.data ?? [];
  const totalValue = products.reduce((s, p) => s + p.stock_qty * p.cost_price, 0);

  return (
    <div>
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:600, margin:0, letterSpacing:-0.5 }}>Inventory</h1>
          <p style={{ fontSize:12, color:'#8888aa', margin:'4px 0 0' }}>Products, stock levels & movements</p>
        </div>
        <button onClick={() => navigate('/inventory/new')} style={btnPri}>+ Add Product</button>
      </div>

      {/* Stats row */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        {[
          { label:'Total SKUs',    val: data?.total ?? 0,                    color:'#54a0ff' },
          { label:'Stock Value',   val:`Rs ${Math.round(totalValue).toLocaleString()}`, color:'#00d4aa' },
          { label:'Low Stock',     val: products.filter(p=>p.stock_qty>0&&p.stock_qty<=p.low_stock_threshold).length, color:'#ffb347' },
          { label:'Out of Stock',  val: products.filter(p=>p.stock_qty<=0).length, color:'#ff4757' },
        ].map(s=>(
          <div key={s.label} style={statCard}>
            <div style={{ fontSize:10, color:'#8888aa', marginBottom:4, textTransform:'uppercase', letterSpacing:0.5 }}>{s.label}</div>
            <div style={{ fontSize:20, fontWeight:600, color:s.color }}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display:'flex', gap:8, marginBottom:14, flexWrap:'wrap', alignItems:'center' }}>
        <input value={search} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Search name, SKU, barcode..." style={{ ...inp, width:220 }} />
        <select value={size} onChange={e=>{setSize(e.target.value);setPage(1);}} style={{ ...sel, width:110 }}>
          <option value="">All Sizes</option>
          {SIZES.map(s=><option key={s}>{s}</option>)}
        </select>
        <select value={color} onChange={e=>{setColor(e.target.value);setPage(1);}} style={{ ...sel, width:110 }}>
          <option value="">All Colors</option>
          {COLORS.map(c=><option key={c}>{c}</option>)}
        </select>
        <button onClick={()=>{setLowOnly(l=>!l);setPage(1);}} style={{
          ...btnSec, fontSize:11,
          ...(lowOnly?{borderColor:'#ffb347',color:'#ffb347',background:'rgba(255,179,71,0.1)'}:{}),
        }}>⚠ Low Stock Only</button>
      </div>

      {/* Table */}
      <div style={card}>
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
            <thead>
              <tr>
                {['SKU / Barcode','Product','Category','Size','Color','Cost','Price','Stock','Actions'].map(h=>(
                  <th key={h} style={th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={9} style={{ textAlign:'center', padding:32, color:'#8888aa' }}>Loading products...</td></tr>
              ) : products.length === 0 ? (
                <tr><td colSpan={9} style={{ textAlign:'center', padding:32, color:'#8888aa' }}>No products found</td></tr>
              ) : products.map(p=>(
                <tr key={p.id}>
                  <td style={td}>
                    <div style={{ fontFamily:'monospace', fontSize:11, color:'#8888aa' }}>{p.sku}</div>
                    {p.barcode && <div style={{ fontFamily:'monospace', fontSize:9, color:'#555' }}>{p.barcode}</div>}
                  </td>
                  <td style={td}>
                    <div style={{ fontWeight:500 }}>{p.name}</div>
                    {p.notes && <div style={{ fontSize:10, color:'#8888aa' }}>{p.notes}</div>}
                  </td>
                  <td style={td}><span style={{ fontSize:10, background:'rgba(84,160,255,0.12)', color:'#54a0ff', padding:'2px 8px', borderRadius:10 }}>{p.category?.name}</span></td>
                  <td style={td}>{p.size}</td>
                  <td style={td}>
                    <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                      {p.color_hex && <div style={{ width:10, height:10, borderRadius:'50%', background:p.color_hex, border:'1px solid rgba(255,255,255,0.2)', flexShrink:0 }} />}
                      {p.color}
                    </div>
                  </td>
                  <td style={td}>Rs {parseFloat(p.cost_price).toLocaleString()}</td>
                  <td style={{ ...td, fontWeight:500 }}>Rs {parseFloat(p.selling_price).toLocaleString()}</td>
                  <td style={td}><StockBadge qty={p.stock_qty} threshold={p.low_stock_threshold} /></td>
                  <td style={td}>
                    <div style={{ display:'flex', gap:4 }}>
                      <button onClick={()=>setStockModal(p)} style={{ ...btnSm, color:'#00d4aa', borderColor:'rgba(0,212,170,0.3)' }}>± Stock</button>
                      <button onClick={()=>navigate(`/inventory/${p.id}`)} style={btnSm}>Edit</button>
                      <button onClick={()=>navigate(`/barcode?product=${p.id}`)} style={btnSm}>▦</button>
                      <button onClick={()=>{ if(confirm(`Delete ${p.name}?`)) deleteMut.mutate(p.id); }} style={{ ...btnSm, color:'#ff4757', borderColor:'rgba(255,71,87,0.3)' }}>✕</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {data?.last_page > 1 && (
          <div style={{ padding:'12px 16px', borderTop:'1px solid rgba(255,255,255,0.06)', display:'flex', gap:8, alignItems:'center' }}>
            <button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={page===1} style={btnSm}>← Prev</button>
            <span style={{ fontSize:12, color:'#8888aa' }}>Page {page} of {data.last_page} ({data.total} products)</span>
            <button onClick={()=>setPage(p=>p+1)} disabled={page===data.last_page} style={btnSm}>Next →</button>
          </div>
        )}
      </div>

      {stockModal && (
        <StockModal product={stockModal} onClose={()=>setStockModal(null)} onSave={()=>qc.invalidateQueries({queryKey:['products']})} />
      )}
    </div>
  );
}

// shared styles
const overlay = { position:'fixed', inset:0, background:'rgba(0,0,0,0.75)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:200 };
const modal   = { background:'#16213e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:12, padding:24, width:340 };
const card    = { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, overflow:'hidden' };
const statCard= { background:'#16213e', border:'1px solid rgba(255,255,255,0.08)', borderRadius:10, padding:12 };
const inp     = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'8px 12px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none', width:'100%', boxSizing:'border-box' };
const sel     = { background:'#1a1a2e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:7, color:'#e8e8f0', padding:'7px 10px', fontSize:12, fontFamily:"'Sora',sans-serif", outline:'none' };
const fg      = { marginBottom:12 };
const lbl     = { display:'block', fontSize:11, color:'#8888aa', marginBottom:4, fontWeight:500 };
const th      = { padding:'9px 12px', textAlign:'left', fontSize:10, fontWeight:600, textTransform:'uppercase', letterSpacing:'0.8px', color:'#555566', borderBottom:'1px solid rgba(255,255,255,0.06)' };
const td      = { padding:'10px 12px', borderBottom:'1px solid rgba(255,255,255,0.04)', verticalAlign:'middle', fontSize:12 };
const btnPri  = { padding:'8px 16px', borderRadius:7, border:'none', background:'#e94560', color:'white', fontSize:12, fontWeight:500, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSec  = { padding:'8px 14px', borderRadius:7, background:'rgba(255,255,255,0.07)', color:'#e8e8f0', border:'1px solid rgba(255,255,255,0.1)', fontSize:12, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
const btnSm   = { padding:'4px 10px', borderRadius:6, background:'transparent', color:'#8888aa', border:'1px solid rgba(255,255,255,0.1)', fontSize:11, cursor:'pointer', fontFamily:"'Sora',sans-serif" };
