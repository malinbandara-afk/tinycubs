import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const NAV = [
  { label: 'Dashboard',    path: '/dashboard',    icon: '📊', module: 'dashboard' },
  { label: 'Sales',        path: '/sales',        icon: '🛒', module: 'sales',        badge: null },
  { label: 'Customers',    path: '/customers',    icon: '👤', module: 'sales' },
  { label: 'Inventory',    path: '/inventory',    icon: '📦', module: 'inventory' },
  { label: 'Production',   path: '/production',   icon: '🏭', module: 'production' },
  { label: 'Barcode',      path: '/barcode',      icon: '▦',  module: 'inventory' },
  { label: 'Accounting',   path: '/accounting',   icon: '💰', module: 'accounting' },
  { label: 'Reports',      path: '/reports',      icon: '📄', module: 'reports' },
  { label: 'Integrations', path: '/integrations', icon: '🌐', module: 'integrations' },
  { label: 'Users',        path: '/users',        icon: '👥', module: 'users' },
];

const SECTIONS = [
  { title: 'Main',         items: ['Dashboard'] },
  { title: 'Operations',   items: ['Sales', 'Customers', 'Inventory', 'Production', 'Barcode'] },
  { title: 'Finance',      items: ['Accounting', 'Reports'] },
  { title: 'Integrations', items: ['Integrations'] },
  { title: 'System',       items: ['Users'] },
];

export default function Layout() {
  const { user, logout, can } = useAuthStore();
  const navigate              = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out');
    navigate('/login');
  };

  const visibleNav = NAV.filter(n => can(n.module));

  return (
    <div style={{
      display: 'flex',
      height: '100vh',
      background: '#1a1a2e',
      fontFamily: "'Sora', sans-serif",
      color: '#e8e8f0',
      overflow: 'hidden',
    }}>
      {/* SIDEBAR */}
      <div style={{
        width: collapsed ? 52 : 220,
        background: '#16213e',
        borderRight: '1px solid rgba(255,255,255,0.06)',
        display: 'flex',
        flexDirection: 'column',
        transition: 'width 0.2s',
        flexShrink: 0,
        overflow: 'hidden',
      }}>
        {/* Logo */}
        <div style={{
          padding: collapsed ? '16px 8px' : '16px 16px',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          height: 52,
          flexShrink: 0,
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'linear-gradient(135deg, #e94560, #c0392b)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, flexShrink: 0,
          }}>🧸</div>
          {!collapsed && (
            <span style={{ fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap' }}>
              Tiny<span style={{ color: '#e94560' }}>Cubs</span>
              <span style={{ color: '#8888aa', fontWeight: 300 }}> ERP</span>
            </span>
          )}
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
          {SECTIONS.map(section => {
            const sectionItems = visibleNav.filter(n => section.items.includes(n.label));
            if (!sectionItems.length) return null;
            return (
              <div key={section.title}>
                {!collapsed && (
                  <div style={{
                    padding: '12px 16px 4px',
                    fontSize: 10,
                    fontWeight: 600,
                    textTransform: 'uppercase',
                    letterSpacing: '1px',
                    color: '#555566',
                  }}>{section.title}</div>
                )}
                {sectionItems.map(item => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    style={({ isActive }) => ({
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      padding: collapsed ? '9px 14px' : '9px 16px',
                      margin: '1px 8px',
                      borderRadius: 6,
                      textDecoration: 'none',
                      fontSize: 12.5,
                      color: isActive ? '#e94560' : '#8888aa',
                      background: isActive ? 'rgba(233,69,96,0.12)' : 'transparent',
                      borderLeft: isActive ? '3px solid #e94560' : '3px solid transparent',
                      fontWeight: isActive ? 500 : 400,
                      transition: 'all 0.15s',
                      whiteSpace: 'nowrap',
                    })}
                  >
                    <span style={{ fontSize: 15, width: 18, textAlign: 'center', flexShrink: 0 }}>{item.icon}</span>
                    {!collapsed && item.label}
                  </NavLink>
                ))}
              </div>
            );
          })}
        </nav>

        {/* User + Collapse */}
        <div style={{
          borderTop: '1px solid rgba(255,255,255,0.06)',
          padding: collapsed ? '12px 8px' : '12px 16px',
          flexShrink: 0,
        }}>
          {!collapsed && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <div style={{
                width: 30, height: 30, borderRadius: '50%',
                background: 'rgba(233,69,96,0.2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, color: '#e94560', fontWeight: 600, flexShrink: 0,
              }}>
                {user?.name?.charAt(0)}
              </div>
              <div style={{ overflow: 'hidden' }}>
                <div style={{ fontSize: 12, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {user?.name}
                </div>
                <div style={{ fontSize: 10, color: '#8888aa', textTransform: 'capitalize' }}>{user?.role}</div>
              </div>
            </div>
          )}
          <div style={{ display: 'flex', gap: 4 }}>
            <button onClick={handleLogout} style={{
              flex: 1,
              padding: '6px 0',
              background: 'rgba(255,71,87,0.1)',
              border: '1px solid rgba(255,71,87,0.2)',
              borderRadius: 6,
              color: '#ff4757',
              fontSize: 11,
              cursor: 'pointer',
              fontFamily: "'Sora', sans-serif",
            }}>
              {collapsed ? '⏻' : '⏻ Logout'}
            </button>
            <button onClick={() => setCollapsed(c => !c)} style={{
              padding: '6px 8px',
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: 6,
              color: '#8888aa',
              fontSize: 12,
              cursor: 'pointer',
            }}>
              {collapsed ? '→' : '←'}
            </button>
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Top bar */}
        <div style={{
          height: 52,
          background: '#16213e',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
          display: 'flex',
          alignItems: 'center',
          padding: '0 20px',
          gap: 12,
          flexShrink: 0,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 8, height: 8, background: '#00d4aa', borderRadius: '50%' }}></div>
            <span style={{ fontSize: 11, color: '#00d4aa' }}>Live</span>
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 11, color: '#8888aa' }}>🇱🇰 LKR</span>
            <span style={{
              background: '#e94560',
              color: 'white',
              borderRadius: 20,
              fontSize: 10,
              fontWeight: 600,
              padding: '2px 8px',
              textTransform: 'capitalize',
            }}>{user?.role}</span>
          </div>
        </div>

        {/* Page content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
          <Outlet />
        </div>
      </div>
    </div>
  );
}
