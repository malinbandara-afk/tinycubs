// TinyCubs ERP — Mock Data for Live Demo (Vercel)
// When VITE_API_URL is not set, all API calls return this mock data.
// Replace with real backend URL in Vercel environment variables.

export const MOCK_USER = {
  id: 1, name: 'Admin User', email: 'admin@tinycubs.lk',
  role: 'admin', is_active: true,
};

export const MOCK_DASHBOARD = {
  today:              { revenue: 84500, orders: 24, expenses: 12300 },
  month:              { revenue: 1245800 },
  cash_in_hand:       38200,
  outstanding:        210000,
  outstanding_count:  7,
  production:         { pending: 5, in_progress: 3, completed: 12 },
  out_of_stock_count: 2,
  low_stock: [
    { id:1, name:'Baby Romper Blue', sku:'TC-BAB-BLU-0M', size:'0-3M', color:'Blue',   stock_qty:3,  low_stock_threshold:10, category:{ name:'Baby Clothes' } },
    { id:2, name:'Kids Tee Yellow',  sku:'TC-KID-YEL-3Y', size:'2-3Y', color:'Yellow', stock_qty:6,  low_stock_threshold:10, category:{ name:'Kids Clothing' } },
    { id:3, name:'Custom Print Tee', sku:'TC-TSH-BLK-M',  size:'M',    color:'Black',  stock_qty:8,  low_stock_threshold:10, category:{ name:'T-Shirts' } },
    { id:4, name:'Infant Bodysuit',  sku:'TC-BAB-WHT-0M', size:'0-3M', color:'White',  stock_qty:2,  low_stock_threshold:10, category:{ name:'Baby Clothes' } },
  ],
  recent_invoices: [
    { id:1, invoice_number:'INV-2026-0042', customer:{ name:'Nimal Perera' },    total:'25000', status:'paid',    source:'manual' },
    { id:2, invoice_number:'INV-2026-0041', customer:{ name:'Ayasha Silva' },    total:'18500', status:'partial', source:'manual' },
    { id:3, invoice_number:'WC-0044',       customer:{ name:'Online Customer' }, total:'4800',  status:'paid',    source:'woocommerce' },
    { id:4, invoice_number:'INV-2026-0040', customer:{ name:'Lanka Prints Co.'}, total:'112500',status:'partial', source:'manual' },
    { id:5, invoice_number:'INV-2026-0039', customer:{ name:'Dinesh Kumara' },   total:'3800',  status:'sent',    source:'manual' },
  ],
  expense_breakdown: { salaries:85000, cost_of_goods:250000, rent:25000, utilities:8500 },
  payment_methods:   { cash:42000, bank_transfer:33000, online:9200 },
};

export const MOCK_CHART = [
  { period:'2025-11', revenue:820000, collected:780000, orders:142 },
  { period:'2025-12', revenue:1050000, collected:980000, orders:168 },
  { period:'2026-01', revenue:890000, collected:850000, orders:155 },
  { period:'2026-02', revenue:1100000, collected:1060000, orders:177 },
  { period:'2026-03', revenue:1080000, collected:1020000, orders:172 },
  { period:'2026-04', revenue:1245800, collected:1190000, orders:187 },
];

export const MOCK_INVOICES = {
  data: [
    { id:1, invoice_number:'INV-2026-0042', customer:{ name:'Nimal Perera', phone:'+94771234567' },    items:[{},{} ], total:'25000',  amount_paid:'25000',  balance_due:'0',     status:'paid',    source:'manual',      invoice_date:'2026-04-18', due_date:null },
    { id:2, invoice_number:'INV-2026-0041', customer:{ name:'Ayasha Silva', phone:'+94779876543' },    items:[{},{},{} ], total:'18500', amount_paid:'9250',   balance_due:'9250',  status:'partial', source:'manual',      invoice_date:'2026-04-17', due_date:'2026-04-30' },
    { id:3, invoice_number:'INV-2026-0040', customer:{ name:'Lanka Prints Co.', phone:'+94112223344' }, items:[{}], total:'112500', amount_paid:'67500',  balance_due:'45000', status:'partial', source:'manual',      invoice_date:'2026-04-15', due_date:'2026-04-25' },
    { id:4, invoice_number:'INV-2026-0039', customer:{ name:'Dinesh Kumara', phone:'+94771112233' },   items:[{},{}], total:'3800',  amount_paid:'0',      balance_due:'3800',  status:'sent',    source:'manual',      invoice_date:'2026-04-14', due_date:'2026-04-21' },
    { id:5, invoice_number:'WC-0044',       customer:{ name:'Online Customer', phone:null },           items:[{}],   total:'4800',  amount_paid:'4800',   balance_due:'0',     status:'paid',    source:'woocommerce', invoice_date:'2026-04-18', due_date:null },
    { id:6, invoice_number:'QT-2026-0010',  customer:{ name:'Sampath Textiles', phone:'+94112345678' },items:[{},{},{},{}], total:'250000', amount_paid:'0', balance_due:'250000', status:'draft', source:'manual',     invoice_date:'2026-04-18', due_date:null },
  ],
  total: 6, last_page: 1, current_page: 1,
  meta: { total_revenue:1415600, collected:1102550, outstanding:299050 },
};

export const MOCK_PRODUCTS = {
  data: [
    { id:1, name:'Custom Print T-Shirt', sku:'TC-TSH-WHT-L',  size:'L',    color:'White',  color_hex:'#f5f5f5', cost_price:'350', selling_price:'750',  stock_qty:8,  low_stock_threshold:10, is_active:true, barcode:'TC-TSH-WHT-L',  woocommerce_id:'101', sync_to_woocommerce:true, sync_to_facebook:false, notes:'', category:{ id:1, name:'T-Shirts' },       category_id:1 },
    { id:2, name:'Plain T-Shirt',        sku:'TC-TSH-BLK-M',  size:'M',    color:'Black',  color_hex:'#222222', cost_price:'280', selling_price:'650',  stock_qty:64, low_stock_threshold:10, is_active:true, barcode:'TC-TSH-BLK-M',  woocommerce_id:'102', sync_to_woocommerce:true, sync_to_facebook:true,  notes:'', category:{ id:1, name:'T-Shirts' },       category_id:1 },
    { id:3, name:'Baby Romper',          sku:'TC-BAB-BLU-0M', size:'0-3M', color:'Blue',   color_hex:'#4a9eff', cost_price:'420', selling_price:'950',  stock_qty:3,  low_stock_threshold:10, is_active:true, barcode:'TC-BAB-BLU-0M', woocommerce_id:'201', sync_to_woocommerce:true, sync_to_facebook:false, notes:'', category:{ id:2, name:'Baby Clothes' },    category_id:2 },
    { id:4, name:'Kids T-Shirt',         sku:'TC-KID-YEL-3Y', size:'2-3Y', color:'Yellow', color_hex:'#ffcc00', cost_price:'380', selling_price:'850',  stock_qty:6,  low_stock_threshold:10, is_active:true, barcode:'TC-KID-YEL-3Y', woocommerce_id:'301', sync_to_woocommerce:true, sync_to_facebook:false, notes:'', category:{ id:3, name:'Kids Clothing' },   category_id:3 },
    { id:5, name:'Infant Bodysuit',      sku:'TC-BAB-WHT-0M', size:'0-3M', color:'White',  color_hex:'#f5f5f5', cost_price:'390', selling_price:'900',  stock_qty:2,  low_stock_threshold:10, is_active:true, barcode:'TC-BAB-WHT-0M', woocommerce_id:'202', sync_to_woocommerce:true, sync_to_facebook:false, notes:'', category:{ id:2, name:'Baby Clothes' },    category_id:2 },
    { id:6, name:'Girls Frock',          sku:'TC-KID-PNK-4Y', size:'4-5Y', color:'Pink',   color_hex:'#fd79a8', cost_price:'450', selling_price:'1100', stock_qty:22, low_stock_threshold:10, is_active:true, barcode:'TC-KID-PNK-4Y', woocommerce_id:'302', sync_to_woocommerce:true, sync_to_facebook:true,  notes:'', category:{ id:3, name:'Kids Clothing' },   category_id:3 },
    { id:7, name:'Custom Print T-Shirt', sku:'TC-TSH-RED-S',  size:'S',    color:'Red',    color_hex:'#e74c3c', cost_price:'350', selling_price:'750',  stock_qty:35, low_stock_threshold:10, is_active:true, barcode:'TC-TSH-RED-S',  woocommerce_id:'103', sync_to_woocommerce:true, sync_to_facebook:false, notes:'', category:{ id:1, name:'T-Shirts' },       category_id:1 },
    { id:8, name:'Baby Cap Set',         sku:'TC-BAB-GRN-OS', size:'0-3M', color:'Green',  color_hex:'#2ecc71', cost_price:'220', selling_price:'550',  stock_qty:18, low_stock_threshold:10, is_active:true, barcode:'TC-BAB-GRN-OS', woocommerce_id:'203', sync_to_woocommerce:true, sync_to_facebook:false, notes:'', category:{ id:2, name:'Baby Clothes' },    category_id:2 },
  ],
  total: 8, last_page: 1, current_page: 1,
};

export const MOCK_CUSTOMERS = {
  data: [
    { id:1, name:'Nimal Perera',     phone:'+94771234567', email:'nimal@email.com',  company:'',              type:'retail',    total_purchases:'125000' },
    { id:2, name:'Ayasha Silva',     phone:'+94779876543', email:'ayasha@gmail.com', company:'',              type:'retail',    total_purchases:'48500' },
    { id:3, name:'Lanka Prints Co.', phone:'+94112223344', email:'info@lankaprints.lk', company:'Lanka Prints Co.', type:'wholesale', total_purchases:'450000' },
    { id:4, name:'Dinesh Kumara',    phone:'+94771112233', email:'',                 company:'',              type:'retail',    total_purchases:'3800' },
    { id:5, name:'Sampath Textiles', phone:'+94112345678', email:'purchase@sampath.lk', company:'Sampath Textiles', type:'wholesale', total_purchases:'820000' },
  ],
  total: 5, last_page: 1,
};

export const MOCK_JOB_ORDERS = {
  data: [
    { id:1, job_number:'J-2026-0018', title:'T-Shirt Print Bulk',   description:'White + Black, L/M/S', worker:{ id:1, name:'Kasun R.' },    quantity:50, due_date:'2026-04-20', progress_pct:65, status:'in_progress', items:[{ description:'Custom Print × 50', quantity:50, product:{ name:'Custom Print T-Shirt' } }] },
    { id:2, job_number:'J-2026-0017', title:'Kids Romper Set',       description:'Multi-color 0-3M, 3-6M', worker:{ id:2, name:'Amaya P.' },  quantity:30, due_date:'2026-04-19', progress_pct:80, status:'in_progress', items:[{ description:'Baby Romper × 30', quantity:30, product:{ name:'Baby Romper' } }] },
    { id:3, job_number:'J-2026-0016', title:'Custom Logo Print',     description:'Black, L',               worker:{ id:3, name:'Nuwan S.' },  quantity:25, due_date:'2026-04-22', progress_pct:10, status:'pending',     items:[{ description:'Logo T-Shirt × 25', quantity:25, product:null }] },
    { id:4, job_number:'J-2026-0015', title:'Girls Frock Collection', description:'Pink, 4-5Y',            worker:{ id:1, name:'Kasun R.' },  quantity:20, due_date:'2026-04-16', progress_pct:100,status:'completed',    items:[{ description:'Girls Frock × 20', quantity:20, product:{ name:'Girls Frock' } }] },
    { id:5, job_number:'J-2026-0014', title:'Infant Bodysuit Batch', description:'White, 0-3M',            worker:{ id:2, name:'Amaya P.' },  quantity:40, due_date:'2026-04-15', progress_pct:100,status:'completed',    items:[{ description:'Infant Bodysuit × 40', quantity:40, product:{ name:'Infant Bodysuit' } }] },
  ],
  total: 5, last_page: 1,
};

export const MOCK_WORKERS = [
  { id:1, name:'Kasun R.',  phone:'+94771000011', specialty:'Screen Printing', is_active:true },
  { id:2, name:'Amaya P.',  phone:'+94771000012', specialty:'Sewing & Stitching', is_active:true },
  { id:3, name:'Nuwan S.',  phone:'+94771000013', specialty:'Vinyl Printing', is_active:true },
];

export const MOCK_CATEGORIES = [
  { id:1, name:'T-Shirts',      slug:'t-shirts' },
  { id:2, name:'Baby Clothes',  slug:'baby-clothes' },
  { id:3, name:'Kids Clothing', slug:'kids-clothing' },
  { id:4, name:'Rompers',       slug:'rompers' },
];

export const MOCK_PL = {
  period:         { from:'2026-04-01', to:'2026-04-18' },
  revenue:        1245800,
  expenses:       { cost_of_goods:250000, salaries:85000, rent:25000, utilities:8500, marketing:12000 },
  total_expenses: 380500,
  net_profit:     865300,
  margin_pct:     69.5,
};

export const MOCK_SALES_REPORT = {
  period:            { from:'2026-04-01', to:'2026-04-18' },
  total_invoices:    187,
  total_revenue:     1245800,
  total_collected:   1102550,
  total_outstanding: 143250,
  by_status:         { paid:142, partial:28, sent:12, draft:5 },
  by_source:         { manual:980000, woocommerce:235800, facebook:30000 },
  invoices:          MOCK_INVOICES.data,
};

export const MOCK_INVENTORY_REPORT = {
  products:      [], // filled from MOCK_PRODUCTS
  total_skus:    8,
  total_value:   485600,
  low_stock:     4,
  out_of_stock:  0,
};

export const MOCK_USERS = [
  { id:1, name:'Admin User',  email:'admin@tinycubs.lk',    role:'admin',      is_active:true, last_login_at:'2026-04-18' },
  { id:2, name:'Sanduni K.',  email:'sales@tinycubs.lk',    role:'sales',      is_active:true, last_login_at:'2026-04-18' },
  { id:3, name:'Ruwani J.',   email:'accounts@tinycubs.lk', role:'accounts',   is_active:true, last_login_at:'2026-04-17' },
  { id:4, name:'Kasun P.',    email:'ops@tinycubs.lk',      role:'operations', is_active:true, last_login_at:'2026-04-18' },
];

export const MOCK_EXPENSES = {
  data: [
    { id:1, title:'Blank T-Shirts Batch',   category:'cost_of_goods', amount:'18500', payment_method:'bank_transfer', expense_date:'2026-04-18', notes:'100 pcs from supplier' },
    { id:2, title:'Worker Salaries — April', category:'salaries',      amount:'85000', payment_method:'bank_transfer', expense_date:'2026-04-15', notes:'' },
    { id:3, title:'April Rent',              category:'rent',          amount:'25000', payment_method:'bank_transfer', expense_date:'2026-04-01', notes:'Workshop rent' },
    { id:4, title:'Electricity Bill',        category:'utilities',     amount:'8500',  payment_method:'bank_transfer', expense_date:'2026-04-17', notes:'' },
    { id:5, title:'Facebook Ads',            category:'marketing',     amount:'12000', payment_method:'online',        expense_date:'2026-04-10', notes:'April campaign' },
  ],
  total: 5, last_page: 1,
};

export const IS_DEMO = !import.meta.env.VITE_API_URL || import.meta.env.VITE_API_URL === '';
