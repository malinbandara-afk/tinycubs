// TinyCubs ERP — API Service
// Auto-switches between mock data (demo) and real backend based on VITE_API_URL env var.
// Vercel: set VITE_API_URL=https://your-laravel-backend.com in Project → Settings → Environment Variables

import axios from 'axios';
import {
  IS_DEMO, MOCK_USER, MOCK_DASHBOARD, MOCK_CHART, MOCK_INVOICES,
  MOCK_PRODUCTS, MOCK_CUSTOMERS, MOCK_JOB_ORDERS, MOCK_WORKERS,
  MOCK_CATEGORIES, MOCK_PL, MOCK_SALES_REPORT, MOCK_INVENTORY_REPORT,
  MOCK_USERS, MOCK_EXPENSES,
} from './mockData.js';

const api = axios.create({
  baseURL: (import.meta.env.VITE_API_URL || '') + '/api',
  headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('erp_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401 && !IS_DEMO) {
      localStorage.removeItem('erp_token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

const mock = (data, delay = 250) =>
  new Promise((res) => setTimeout(() => res({ data }), delay));

const mockPage = (items, params = {}) => {
  const page    = parseInt(params.page) || 1;
  const perPage = parseInt(params.per_page) || 20;
  const search  = (params.search || '').toLowerCase();
  let filtered  = items;
  if (search) filtered = items.filter((i) => JSON.stringify(i).toLowerCase().includes(search));
  const start = (page - 1) * perPage;
  return mock({
    data: filtered.slice(start, start + perPage),
    total: filtered.length,
    current_page: page,
    last_page: Math.max(1, Math.ceil(filtered.length / perPage)),
  });
};

// ─── Auth ─────────────────────────────────────────────────────
export const authApi = {
  login: (data) => {
    if (IS_DEMO) {
      const valid = [
        { email:'admin@tinycubs.lk',    password:'Admin@1234', role:'admin' },
        { email:'sales@tinycubs.lk',    password:'Sales@1234', role:'sales' },
        { email:'accounts@tinycubs.lk', password:'Accts@1234', role:'accounts' },
        { email:'ops@tinycubs.lk',      password:'Ops@12345',  role:'operations' },
      ];
      const match = valid.find((l) => l.email === data.email && l.password === data.password);
      if (match) {
        const user = MOCK_USERS.find((u) => u.email === match.email) || MOCK_USER;
        return mock({ token: 'demo-' + match.role, user });
      }
      return Promise.reject({ response: { data: { message: 'Invalid credentials. Try admin@tinycubs.lk / Admin@1234' } } });
    }
    return api.post('/login', data);
  },
  logout: () => IS_DEMO ? mock({ ok: true }) : api.post('/logout'),
  me:     () => IS_DEMO ? mock(MOCK_USER)     : api.get('/me'),
};

// ─── Dashboard ────────────────────────────────────────────────
export const dashboardApi = {
  get:   () => IS_DEMO ? mock(MOCK_DASHBOARD) : api.get('/dashboard'),
  chart: () => IS_DEMO ? mock(MOCK_CHART)     : api.get('/dashboard/chart', { params: { period:'monthly' } }),
};

// ─── Customers ────────────────────────────────────────────────
export const customersApi = {
  list:     (p)    => IS_DEMO ? mockPage(MOCK_CUSTOMERS.data, p)                                             : api.get('/customers', { params: p }),
  get:      (id)   => IS_DEMO ? mock(MOCK_CUSTOMERS.data.find((c) => c.id == id))                           : api.get(`/customers/${id}`),
  create:   (d)    => IS_DEMO ? mock({ ...d, id: Date.now(), total_purchases: 0 })                          : api.post('/customers', d),
  update:   (id,d) => IS_DEMO ? mock({ ...d, id })                                                          : api.put(`/customers/${id}`, d),
  delete:   (id)   => IS_DEMO ? mock({ ok:true })                                                           : api.delete(`/customers/${id}`),
  invoices: (id)   => IS_DEMO ? mock(MOCK_INVOICES.data.filter((i) => i.customer?.id == id))                : api.get(`/customers/${id}/invoices`),
};

// ─── Products ─────────────────────────────────────────────────
export const productsApi = {
  list: (p) => {
    if (!IS_DEMO) return api.get('/products', { params: p });
    let items = [...MOCK_PRODUCTS.data];
    if (p?.size)      items = items.filter((i) => i.size  === p.size);
    if (p?.color)     items = items.filter((i) => i.color === p.color);
    if (p?.low_stock) items = items.filter((i) => i.stock_qty <= i.low_stock_threshold);
    if (p?.paginate === 'false') return mock(items);
    return mockPage(items, p);
  },
  get:           (id)    => IS_DEMO ? mock(MOCK_PRODUCTS.data.find((p) => p.id == id))                                          : api.get(`/products/${id}`),
  create:        (d)     => IS_DEMO ? mock({ ...d, id:Date.now(), sku:`TC-NEW-${Date.now()}`, barcode:`TC-NEW-${Date.now()}` })  : api.post('/products', d),
  update:        (id,d)  => IS_DEMO ? mock({ ...(MOCK_PRODUCTS.data.find((p)=>p.id==id)||{}), ...d })                           : api.put(`/products/${id}`, d),
  delete:        (id)    => IS_DEMO ? mock({ ok:true })                                                                          : api.delete(`/products/${id}`),
  findByBarcode: (code)  => IS_DEMO ? mock(MOCK_PRODUCTS.data.find((p)=>p.sku===code||p.barcode===code))                         : api.get(`/products/search/barcode/${code}`),
  lowStock:      ()      => IS_DEMO ? mock(MOCK_PRODUCTS.data.filter((p)=>p.stock_qty<=p.low_stock_threshold))                   : api.get('/products/low-stock'),
  adjustStock:   (id,d)  => IS_DEMO ? mock({ ok:true })                                                                          : api.post(`/products/${id}/stock`, d),
  movements:     (id)    => IS_DEMO ? mock([])                                                                                    : api.get(`/products/${id}/movements`),
};

// ─── Invoices ─────────────────────────────────────────────────
let _invoices = [...MOCK_INVOICES.data];

export const invoicesApi = {
  list: (p) => {
    if (!IS_DEMO) return api.get('/invoices', { params: p });
    let items = [..._invoices];
    if (p?.status) items = items.filter((i) => i.status === p.status);
    return mockPage(items, p);
  },
  get:        (id)   => IS_DEMO ? mock(_invoices.find((i)=>i.id==id)||MOCK_INVOICES.data[0])                   : api.get(`/invoices/${id}`),
  create:     (d)    => {
    if (!IS_DEMO) return api.post('/invoices', d);
    const inv = { ...d, id:Date.now(), invoice_number:`INV-2026-${String(Date.now()).slice(-4)}`, amount_paid:'0', balance_due:String(d.total||0), status:'draft', customer: MOCK_CUSTOMERS.data.find((c)=>c.id==d.customer_id)||{ name:'Customer' }, items:d.items||[], payments:[] };
    _invoices.unshift(inv);
    return mock(inv);
  },
  update:     (id,d) => IS_DEMO ? mock({ ...(_invoices.find((i)=>i.id==id)||{}), ...d })                       : api.put(`/invoices/${id}`, d),
  delete:     (id)   => IS_DEMO ? mock({ ok:true })                                                             : api.delete(`/invoices/${id}`),
  pdf:        (id)   => IS_DEMO ? Promise.reject(new Error('PDF requires Laravel backend'))                     : api.get(`/invoices/${id}/pdf`, { responseType:'blob' }),
  sendWhatsApp:(id)  => IS_DEMO ? mock({ success:true, provider:'demo' })                                       : api.post(`/invoices/${id}/send-whatsapp`),
  convert:    (id)   => IS_DEMO ? mock({})                                                                       : api.post(`/invoices/${id}/convert`),
  addPayment: (id,d) => IS_DEMO ? mock({ ...d, id:Date.now() })                                                 : api.post(`/invoices/${id}/payments`, d),
  payments:   (id)   => IS_DEMO ? mock([])                                                                       : api.get(`/invoices/${id}/payments`),
};

// ─── Expenses ─────────────────────────────────────────────────
let _expenses = [...MOCK_EXPENSES.data];

export const expensesApi = {
  list:   (p)    => IS_DEMO ? mockPage(_expenses, p)                                                           : api.get('/expenses', { params: p }),
  create: (d)    => { if (!IS_DEMO) return api.post('/expenses', d); const e={...d,id:Date.now()}; _expenses.unshift(e); return mock(e); },
  update: (id,d) => IS_DEMO ? mock({ ...d, id })                                                               : api.put(`/expenses/${id}`, d),
  delete: (id)   => { _expenses=_expenses.filter((e)=>e.id!=id); return IS_DEMO ? mock({ ok:true }) : api.delete(`/expenses/${id}`); },
};

// ─── Job Orders ───────────────────────────────────────────────
let _jobs = [...MOCK_JOB_ORDERS.data];

export const jobOrdersApi = {
  list: (p) => {
    if (!IS_DEMO) return api.get('/job-orders', { params: p });
    let items = [..._jobs];
    if (p?.status) items = items.filter((j) => j.status === p.status);
    return mockPage(items, p);
  },
  get:            (id)   => IS_DEMO ? mock(_jobs.find((j)=>j.id==id))                                         : api.get(`/job-orders/${id}`),
  create:         (d)    => {
    if (!IS_DEMO) return api.post('/job-orders', d);
    const job = { ...d, id:Date.now(), job_number:`J-2026-${String(Date.now()).slice(-4)}`, progress_pct:0, status:'pending', worker:MOCK_WORKERS.find((w)=>w.id==d.worker_id)||null, items:d.items||[] };
    _jobs.unshift(job); return mock(job);
  },
  update:         (id,d) => IS_DEMO ? mock({ ...(_jobs.find((j)=>j.id==id)||{}), ...d })                      : api.put(`/job-orders/${id}`, d),
  updateStatus:   (id,d) => { if (IS_DEMO) { const j=_jobs.find((x)=>x.id==id); if(j) j.status=d.status; return mock(j); } return api.patch(`/job-orders/${id}/status`, d); },
  updateProgress: (id,d) => { if (IS_DEMO) { const j=_jobs.find((x)=>x.id==id); if(j) j.progress_pct=d.progress; return mock(j); } return api.patch(`/job-orders/${id}/progress`, d); },
  addMaterial:    (id,d) => IS_DEMO ? mock({ ...d, id:Date.now() })                                           : api.post(`/job-orders/${id}/materials`, d),
};

// ─── Workers & Materials ──────────────────────────────────────
export const workersApi   = { list:()=>IS_DEMO?mock(MOCK_WORKERS):api.get('/workers'), create:(d)=>IS_DEMO?mock({...d,id:Date.now()}):api.post('/workers',d) };
export const materialsApi = { list:()=>IS_DEMO?mock([]):api.get('/materials'),         create:(d)=>IS_DEMO?mock({...d,id:Date.now()}):api.post('/materials',d) };

// ─── Barcodes ─────────────────────────────────────────────────
export const barcodesApi = {
  generate: (d)    => IS_DEMO ? mock({ barcode:`TC-${Date.now()}` })                                          : api.post('/barcodes/generate', d),
  print:    (id)   => IS_DEMO ? Promise.reject(new Error('PDF requires backend'))                              : api.get(`/barcodes/${id}/print`, { responseType:'blob' }),
  scan:     (code) => {
    if (IS_DEMO) {
      const p = MOCK_PRODUCTS.data.find((x)=>x.sku===code||x.barcode===code);
      if (p) return mock({ product:p, in_stock:p.stock_qty, status:p.stock_qty>p.low_stock_threshold?'good':p.stock_qty>0?'low':'out_of_stock' });
      return Promise.reject({ response:{ data:{ message:'Product not found: '+code } } });
    }
    return api.get(`/barcodes/scan/${code}`);
  },
};

// ─── Reports ──────────────────────────────────────────────────
export const reportsApi = {
  sales:       (p) => IS_DEMO ? mock(MOCK_SALES_REPORT) : api.get('/reports/sales', { params:p }),
  profitLoss:  (p) => IS_DEMO ? mock(MOCK_PL)           : api.get('/reports/profit-loss', { params:p }),
  outstanding: ()  => IS_DEMO ? mock({ invoices:MOCK_INVOICES.data.filter((i)=>['sent','partial'].includes(i.status)).map((i)=>({ invoice_number:i.invoice_number, customer:i.customer?.name, phone:i.customer?.phone||'—', total:i.total, amount_paid:i.amount_paid, balance_due:i.balance_due, status:i.status, days_overdue:2 })), total_outstanding:54050, count:3 }) : api.get('/reports/outstanding'),
  inventory:   ()  => IS_DEMO ? mock({ ...MOCK_INVENTORY_REPORT, products:MOCK_PRODUCTS.data.map((p)=>({ ...p, stock_value:p.stock_qty*parseFloat(p.cost_price) })) }) : api.get('/reports/inventory'),
  production:  (p) => IS_DEMO ? mock({ jobs:MOCK_JOB_ORDERS.data, total_units:165, by_status:{ pending:1, in_progress:2, completed:2 }, by_worker:{ 'Kasun R.':2, 'Amaya P.':2, 'Nuwan S.':1 } }) : api.get('/reports/production', { params:p }),
  downloadSales:       () => Promise.reject(new Error('PDF download requires the Laravel backend. Add VITE_API_URL to Vercel environment variables.')),
  downloadPL:          () => Promise.reject(new Error('PDF download requires the Laravel backend. Add VITE_API_URL to Vercel environment variables.')),
  downloadOutstanding: () => Promise.reject(new Error('PDF download requires the Laravel backend. Add VITE_API_URL to Vercel environment variables.')),
  downloadInventory:   () => Promise.reject(new Error('PDF download requires the Laravel backend. Add VITE_API_URL to Vercel environment variables.')),
  downloadProduction:  () => Promise.reject(new Error('PDF download requires the Laravel backend. Add VITE_API_URL to Vercel environment variables.')),
};

// ─── WooCommerce ──────────────────────────────────────────────
export const wooApi = {
  status:       () => IS_DEMO ? mock({ connected:false, message:'Demo mode' }) : api.get('/woocommerce/status'),
  syncProducts: () => IS_DEMO ? mock({ message:'Connect backend to sync' })    : api.post('/woocommerce/sync/products'),
  syncOrders:   () => IS_DEMO ? mock({ imported:0 })                           : api.post('/woocommerce/sync/orders'),
};

// ─── Settings & Users ─────────────────────────────────────────
export const settingsApi = { get:()=>IS_DEMO?mock({ company_name:'TinyCubs.lk', currency_symbol:'Rs', currency:'LKR' }):api.get('/settings'), update:(d)=>IS_DEMO?mock(d):api.put('/settings',d) };
export const usersApi    = { list:()=>IS_DEMO?mock(MOCK_USERS):api.get('/users') };

// ─── Download helper ──────────────────────────────────────────
export function downloadBlob(response, filename) {
  const url  = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href  = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

export default api;
