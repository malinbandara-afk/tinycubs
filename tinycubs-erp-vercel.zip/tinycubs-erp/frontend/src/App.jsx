// TinyCubs ERP — Main App Entry
import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './store/authStore';

// Layout
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';

// Pages
import Dashboard    from './pages/Dashboard';
import Sales        from './pages/Sales';
import InvoiceForm  from './pages/InvoiceForm';
import Inventory    from './pages/Inventory';
import ProductForm  from './pages/ProductForm';
import Production   from './pages/Production';
import JobOrderForm from './pages/JobOrderForm';
import Barcode      from './pages/Barcode';
import Accounting   from './pages/Accounting';
import Reports      from './pages/Reports';
import Integrations from './pages/Integrations';
import Users        from './pages/Users';
import Customers    from './pages/Customers';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30_000 },
  },
});

function PrivateRoute({ children, module }) {
  const { user, can } = useAuthStore();
  if (!user) return <Navigate to="/login" replace />;
  if (module && !can(module)) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { user, token, fetchMe } = useAuthStore();

  useEffect(() => {
    if (token && !user) fetchMe();
  }, [token]);

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            style: { background: '#1a1a2e', color: '#e8e8f0', border: '1px solid rgba(255,255,255,0.1)' },
            success: { iconTheme: { primary: '#00d4aa', secondary: '#1a1a2e' } },
            error:   { iconTheme: { primary: '#ff4757', secondary: '#1a1a2e' } },
          }}
        />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard"    element={<Dashboard />} />
            <Route path="sales"        element={<PrivateRoute module="sales"><Sales /></PrivateRoute>} />
            <Route path="sales/new"    element={<PrivateRoute module="sales"><InvoiceForm /></PrivateRoute>} />
            <Route path="sales/:id"    element={<PrivateRoute module="sales"><InvoiceForm /></PrivateRoute>} />
            <Route path="customers"    element={<PrivateRoute module="sales"><Customers /></PrivateRoute>} />
            <Route path="inventory"    element={<PrivateRoute module="inventory"><Inventory /></PrivateRoute>} />
            <Route path="inventory/new" element={<PrivateRoute module="inventory"><ProductForm /></PrivateRoute>} />
            <Route path="inventory/:id" element={<PrivateRoute module="inventory"><ProductForm /></PrivateRoute>} />
            <Route path="production"   element={<PrivateRoute module="production"><Production /></PrivateRoute>} />
            <Route path="production/new" element={<PrivateRoute module="production"><JobOrderForm /></PrivateRoute>} />
            <Route path="barcode"      element={<PrivateRoute module="inventory"><Barcode /></PrivateRoute>} />
            <Route path="accounting"   element={<PrivateRoute module="accounting"><Accounting /></PrivateRoute>} />
            <Route path="reports"      element={<PrivateRoute module="reports"><Reports /></PrivateRoute>} />
            <Route path="integrations" element={<PrivateRoute module="integrations"><Integrations /></PrivateRoute>} />
            <Route path="users"        element={<PrivateRoute module="users"><Users /></PrivateRoute>} />
          </Route>
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
