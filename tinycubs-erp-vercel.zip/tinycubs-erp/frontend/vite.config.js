// vite.config.js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor:   ['react', 'react-dom', 'react-router-dom'],
          query:    ['@tanstack/react-query'],
          charts:   ['recharts'],
          forms:    ['react-hook-form'],
        },
      },
    },
  },
});

// ──────────────────────────────────────────────────────────────
// tailwind.config.js
// ──────────────────────────────────────────────────────────────
// module.exports = {
//   content: ['./src/**/*.{js,jsx,ts,tsx}', './index.html'],
//   theme: {
//     extend: {
//       colors: {
//         primary:  '#1a1a2e',
//         surface:  '#16213e',
//         accent:   '#e94560',
//         success:  '#00d4aa',
//         warning:  '#ffb347',
//         danger:   '#ff4757',
//         info:     '#54a0ff',
//       },
//       fontFamily: {
//         sans: ['Sora', 'sans-serif'],
//         mono: ['DM Mono', 'monospace'],
//       },
//     },
//   },
//   plugins: [],
// };

// ──────────────────────────────────────────────────────────────
// frontend/index.html
// ──────────────────────────────────────────────────────────────
// <!DOCTYPE html>
// <html lang="en">
// <head>
//   <meta charset="UTF-8" />
//   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
//   <title>TinyCubs ERP</title>
//   <link rel="icon" href="/favicon.ico" />
//   <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
// </head>
// <body>
//   <div id="root"></div>
//   <script type="module" src="/src/main.jsx"></script>
// </body>
// </html>

// ──────────────────────────────────────────────────────────────
// frontend/src/main.jsx
// ──────────────────────────────────────────────────────────────
// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import App from './App.jsx';
// import './index.css';
// ReactDOM.createRoot(document.getElementById('root')).render(
//   <React.StrictMode><App /></React.StrictMode>
// );

// ──────────────────────────────────────────────────────────────
// frontend/src/index.css — Global reset + font import
// ──────────────────────────────────────────────────────────────
// * { box-sizing: border-box; margin: 0; padding: 0; }
// body { background: #1a1a2e; color: #e8e8f0; font-family: 'Sora', sans-serif; }
// ::-webkit-scrollbar { width: 5px; height: 5px; }
// ::-webkit-scrollbar-track { background: transparent; }
// ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 3px; }
// input, select, textarea, button { font-family: inherit; }
// a { color: inherit; text-decoration: none; }
