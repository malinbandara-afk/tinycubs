# TinyCubs.lk ERP System

Full-stack ERP for T-shirt printing + kids clothing brand.

## Tech Stack
- **Backend**: Laravel 11 (PHP 8.2+)
- **Frontend**: React 18 + Vite + Tailwind CSS
- **Database**: MySQL 8
- **Auth**: Laravel Sanctum (API tokens)
- **PDF**: Laravel DomPDF
- **Barcode**: milon/barcode
- **Queue**: Laravel Jobs (for WhatsApp/sync)

## Modules
1. Sales (invoices, quotations, partial payments)
2. Inventory (products, SKUs, stock in/out)
3. Production (job orders, workers, materials)
4. Barcode (generate, print, scan)
5. Accounting (income, expenses, P&L)
6. Reports (PDF + print)
7. WooCommerce integration
8. Facebook / WhatsApp integration
9. User roles & permissions
10. Dashboard

## Quick Start

### Requirements
- PHP 8.2+, Composer
- Node.js 18+, npm
- MySQL 8

### Backend Setup
```bash
cd backend
composer install
cp .env.example .env
php artisan key:generate
# Edit .env with your DB credentials
php artisan migrate --seed
php artisan serve
```

### Frontend Setup
```bash
cd frontend
npm install
cp .env.example .env
# Edit VITE_API_URL=http://localhost:8000
npm run dev
```

### Default Login
- Email: admin@tinycubs.lk
- Password: password
- Role: Admin

## Hosting (Recommended for Sri Lanka)
- **Budget**: Hostinger VPS (Rs ~3,500/mo) or Dialog Cloud
- **Mid**: DigitalOcean Droplet $12/mo (~Rs 3,800)
- **Domain**: tinycubs.lk → point A record to server IP
- **SSL**: Let's Encrypt (free, auto via Certbot)

## WooCommerce Setup
1. Install WooCommerce on tinycubs.lk WordPress
2. Go to WooCommerce → Settings → Advanced → REST API
3. Create key with Read/Write permissions
4. Paste Consumer Key + Secret into ERP Settings → Integrations

## WhatsApp Setup
1. Sign up at Meta for Developers → WhatsApp Business API
2. Or use Twilio WhatsApp sandbox (easier for testing)
3. Add credentials to ERP Settings → Integrations
